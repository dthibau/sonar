-- Drop columns created by ddl-auto=update
alter table cms_page drop column lastUpdater;
alter table cms_page drop column seoDescription;
alter table cms_page drop column seoKeywords;
alter table cms_page drop column seoTitle;
alter table cms_page drop column sousTitre;
alter table cms_page drop column urlStatique;
alter table cms_page drop column parentPage_id;



