alter table cms_page modify gabarit_id bigint(20);


