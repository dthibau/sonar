alter table formation change column for_origine for_origine varchar(255);
alter table formation change column for_libelle for_libelle varchar(255);
alter table formation change column for_elearning for_elearning tinyint(4) ;
alter table formation change column for_eligible_cpf for_eligible_cpf tinyint(4);

alter table formation change column for_remarques for_remarques longtext;
alter table formation add column bloc_intra longtext;
alter table formation add column bloc_certification longtext;
alter table formation add column bloc_cpf longtext;

delete from formation_filiere where id_formation not in (select id_formation from formation);

alter table formation change column for_reference for_reference varchar(10);
alter table formation add constraint UC_reference UNIQUE (for_reference);
