
-- WPL85G
delete from formation_filiere where id_formation=27859;
delete from formation_session where id_formation=27859;
delete from event where formation_id_formation = 27859;
delete from formation where id_formation=27859;

-- M10971
delete from formation_partenaire_formation_session where formation_partenaire_id in (select id from formation_partenaire where formation_id_formation=335181);
delete from formation_partenaire where formation_id_formation=335181;
delete from formation_filiere where id_formation=335181;
delete from formation_session where id_formation=335181;
delete from formation where id_formation=335181;

-- F247G
delete from formation_filiere where id_formation=700863;
delete from event where formation_id_formation = 700863;
delete from formation where id_formation=700863;

-- M10755
delete from formation_filiere where id_formation=1191;
delete from formation_partenaire_formation_session where formation_partenaire_id in (select id from formation_partenaire where formation_id_formation=1191);
delete from formation_session where id_formation=1191;
delete from event where formation_id_formation = 1191;
delete from formation_partenaire where formation_id_formation = 1191;
delete from formation where id_formation=1191;

-- M20409
delete from formation_filiere where id_formation=315952;
delete from formation_partenaire_formation_session where formation_partenaire_id in (select id from formation_partenaire where formation_id_formation=315952);
delete from formation_session where id_formation=315952;
delete from event where formation_id_formation = 315952;
delete from formation_partenaire where formation_id_formation = 315952;
delete from formation where id_formation=315952;

-- M10972
delete from formation_filiere where id_formation=335148;
delete from formation_partenaire_formation_session where formation_partenaire_id in (select id from formation_partenaire where formation_id_formation=335148);
delete from formation_session where id_formation=335148;
delete from event where formation_id_formation = 335148;
delete from formation_partenaire where formation_id_formation = 335148;
delete from competence where formation_id_formation = 335148;
delete from formation where id_formation=335148;

-- DOLF
delete from formation_filiere where id_formation=700619;
delete from formation_partenaire_formation_session where formation_partenaire_id in (select id from formation_partenaire where formation_id_formation=700619);
delete from formation_session where id_formation=700619;
delete from event where formation_id_formation = 700619;
delete from formation_partenaire where formation_id_formation = 700619;
delete from competence where formation_id_formation = 700619;
delete from formation where id_formation=700619;




