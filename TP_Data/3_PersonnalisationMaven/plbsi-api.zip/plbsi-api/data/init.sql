insert into cms_gabarit (id,libelle,description) values (1,'Template 1','Bla-bla1');
insert into cms_gabarit (id,libelle,description) values (2,'Template 2','Bla-bla2');

insert into cms_menu (id,libelle,indice,parent_id,published) values (1,'Infos pratiques',1,null,true);
insert into cms_menu (id,libelle,indice,parent_id,published) values (2,'Financement',2,null,true);
insert into cms_menu (id,libelle,indice,parent_id,published) values (3,'A propos',3,null,false);
insert into cms_menu (id,libelle,indice,parent_id,published) values (4,'Autres',4,null,false);



insert into cms_menu (id,libelle,indice,parent_id,published) values (8,'Sous-menu 1',41,4,true);
insert into cms_menu (id,libelle,indice,parent_id,published) values (9,'Sous-menu 2',42,4,false);


insert into cms_page (id,reference,titre,rang,gabarit_id,menu_id,published,statique) values (1,'MOD','Modalités d''inscription',1,1,1,false,false);
insert into cms_page (id,reference,titre,rang,gabarit_id,menu_id,published,statique) values (2,'FAC','Facturation et convention de formation',2,2,1,false,false);
insert into cms_page (id,reference,titre,rang,gabarit_id,parent_page_id,published,statique) values (3,'MOD2','Inscription détail',1,2,1,false,false);
