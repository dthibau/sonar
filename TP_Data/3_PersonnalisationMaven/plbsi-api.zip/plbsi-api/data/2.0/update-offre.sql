alter table filiere MODIFY fil_color varchar(10);
