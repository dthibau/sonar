mysqldump -h plb-rec-private.plb.fr -u app_plbsi_rec -r dump-plbsi.sql -p plbconsult_rec
