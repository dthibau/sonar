insert into partenaire (id,nom) values (82,'GKN-Distant');


