alter table formation drop column archived_date;


create table session_lieu (id bigint not null, codePostal integer, numero varchar(255), rue varchar(255), ville varchar(255), nom varchar(255), latitude float, longitude float, partenaire_id integer, primary key (id));

ALTER TABLE formation_session CHANGE COLUMN forsess_date_debut forsess_date_debut TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;
alter table formation_session add column session_lieu_id bigint;
alter table formation_session add constraint FK7dyptt04p1l788pytsbkpw4ll foreign key (session_lieu_id) references session_lieu (id);
alter table session_lieu add constraint FKbhpw5bi46ydb4346inl02ue6 foreign key (partenaire_id) references partenaire (id);


insert into session_lieu (id,nom,numero,rue,codePostal,ville) values (1,'Levallois','3-5','rue Maurice Ravel',92300,'Levallois-Perret');
insert into session_lieu (id,nom,numero,rue,codePostal,ville) values (2,'LYON Danica','21','avenue Georges Pompidou',69003,'Lyon');
insert into session_lieu (id,nom,numero,rue,codePostal,ville) values (3,'MARSEILLE Prado','180','avenue du Prado',13008,'Marseille');
insert into session_lieu (id,nom,numero,rue,codePostal,ville) values (4,'TOULOUSE','78','Allée Jean Jaurès',31000,'Toulouse');


-- Toutes les sessions PLB sont sur Levallois
update formation_session set session_lieu_id=1 where id_session not in (select sessions_id_session from formation_partenaire_formation_session);



