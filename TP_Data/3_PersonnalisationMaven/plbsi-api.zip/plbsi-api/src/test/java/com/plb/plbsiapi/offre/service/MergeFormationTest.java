package com.plb.plbsiapi.offre.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.model.FormationPartenaire;
import com.plb.plbsiapi.offre.model.Partenaire;
import com.plb.plbsiapi.offre.model.Session;
import com.plb.plbsiapi.offre.model.SessionLieu;
import com.plb.plbsiapi.offre.resource.views.SessionDto;

public class MergeFormationTest {

	static int YEAR = 2022;
	static String PARTENAIRE_NOM = "Partenaire";
	static String LEVALLOIS = "Levallois";
	static String LYON = "Lyon";

	List<SessionDto> newSessions; // 4 sessions, 3PLB et 1 partenaire
	List<SessionDto> noSessions; // Aucune sessions

	Formation formation;
	List<FormationPartenaire> formationPartenaires = new ArrayList<>();
	Partenaire partenaire;

	SessionLieu plbLevallois, plbLyon;
	Session levalloisSession1;

	@Test
	public void mergeSessionWithEmptySessions() {

		formation = new Formation();
		FormationPartenaire fp = new FormationPartenaire(formation);
		fp.setPartenaire(partenaire);
		formationPartenaires.add(fp);
		formation.setFormationsPartenaire(formationPartenaires);

		MergeFormationService mergeFormationService = new MergeFormationService();

		String modif = mergeFormationService.mergeSessions(formation, newSessions, YEAR);

		// Vérification 4 sessions ajoutées
		assertThat(modif).hasSizeGreaterThanOrEqualTo(1).hasLineCount(4);
	}

	@Test
	public void mergeSessionWithOneRemovedSession() {
		formation = new Formation();
		FormationPartenaire fp = new FormationPartenaire(formation);
		fp.setPartenaire(partenaire);
		formationPartenaires.add(fp);
		formation.setFormationsPartenaire(formationPartenaires);

		Session removeSession = new Session();
		removeSession.setDebut(LocalDate.of(YEAR, 9, 25));
		removeSession.setFin(LocalDate.of(YEAR, 9, 27));
		removeSession.setSessionLieu(plbLevallois);

		formation.getSessions().add(removeSession);

		MergeFormationService mergeFormationService = new MergeFormationService();

		String modif = mergeFormationService.mergeSessions(formation, newSessions, YEAR);

		// Vérification 4 sessions ajoutées et 1 supprimée
		assertThat(modif).hasSizeGreaterThanOrEqualTo(1).hasLineCount(5);

	}
	
	@Test
	public void mergeRemoveAllSession() {
		formation = new Formation();
		FormationPartenaire fp = new FormationPartenaire(formation);
		fp.setPartenaire(partenaire);
		formationPartenaires.add(fp);
		formation.setFormationsPartenaire(formationPartenaires);

		Session removeSession = new Session();
		removeSession.setDebut(LocalDate.of(YEAR, 9, 25));
		removeSession.setFin(LocalDate.of(YEAR, 9, 27));
		removeSession.setSessionLieu(plbLevallois);

		formation.getSessions().add(removeSession);	

		MergeFormationService mergeFormationService = new MergeFormationService();

		String modif = mergeFormationService.mergeSessions(formation, noSessions, YEAR);

		// Vérification 1 session supprimée
		assertThat(modif).hasSizeGreaterThanOrEqualTo(1).hasLineCount(1);

	}
	
	@Test
	public void mergeWithUnchangedSession() {
		formation = new Formation();
		FormationPartenaire fp = new FormationPartenaire(formation);
		fp.setPartenaire(partenaire);
		formationPartenaires.add(fp);
		formation.setFormationsPartenaire(formationPartenaires);

		Session keepSession = new Session();
		keepSession.setDebut(levalloisSession1.getDebut());
		keepSession.setFin(levalloisSession1.getFin());
		keepSession.setSessionLieu(plbLevallois);

		formation.getSessions().add(keepSession);
		
		

		MergeFormationService mergeFormationService = new MergeFormationService();

		String modif = mergeFormationService.mergeSessions(formation, newSessions, YEAR);

		// Vérification 3 sessions ajoutées 
		assertThat(modif).hasSizeGreaterThanOrEqualTo(1).hasLineCount(3);

	}

	@Test
	public void mergeWithFinChangedSession() {
		formation = new Formation();
		FormationPartenaire fp = new FormationPartenaire(formation);
		fp.setPartenaire(partenaire);
		formationPartenaires.add(fp);
		formation.setFormationsPartenaire(formationPartenaires);

		Session keepSession = new Session();
		keepSession.setDebut(levalloisSession1.getDebut());
		keepSession.setFin(levalloisSession1.getFin().plusDays(1));
		keepSession.setSessionLieu(plbLevallois);

		formation.getSessions().add(keepSession);
		
		

		MergeFormationService mergeFormationService = new MergeFormationService();

		String modif = mergeFormationService.mergeSessions(formation, newSessions, YEAR);

		// Vérification 3 sessions ajoutées + 1 supprimée
		assertThat(modif).hasSizeGreaterThanOrEqualTo(1).hasLineCount(4);

	}
	@BeforeEach
	private void _initSessions() {

		newSessions = new ArrayList<SessionDto>();

		partenaire = new Partenaire();
		partenaire.setId(1);
		partenaire.setNom(PARTENAIRE_NOM);

		plbLevallois = new SessionLieu();
		plbLevallois.setId(1L);
		plbLevallois.setNom(LEVALLOIS);
		plbLyon = new SessionLieu();
		plbLyon.setId(2L);
		plbLyon.setNom(LYON);

		levalloisSession1 = new Session();
		levalloisSession1.setDebut(LocalDate.of(YEAR, 1, 12));
		levalloisSession1.setFin(LocalDate.of(YEAR, 1, 14));
		levalloisSession1.setSessionLieu(plbLevallois);
		Session levalloisSession2 = new Session();
		levalloisSession2.setDebut(LocalDate.of(YEAR, 12, 29));
		levalloisSession2.setFin(LocalDate.of(YEAR + 1, 1, 3));
		levalloisSession2.setSessionLieu(plbLevallois);
		List<Session> levalloisSessions = new ArrayList<>();
		levalloisSessions.add(levalloisSession1);
		levalloisSessions.add(levalloisSession2);
		List<Session> lyonSessions = new ArrayList<>();
		Session lyonSession1 = new Session();
		lyonSession1.setDebut(LocalDate.of(YEAR, 1, 12));
		lyonSession1.setFin(LocalDate.of(YEAR, 1, 14));
		lyonSession1.setSessionLieu(plbLyon);
		lyonSessions.add(lyonSession1);
		Session partenaireSession1 = new Session();
		partenaireSession1.setDebut(LocalDate.of(YEAR, 12, 29));
		partenaireSession1.setFin(LocalDate.of(YEAR + 1, 1, 3));
		partenaireSession1.setSessionLieu(null);

		FormationPartenaire fp = new FormationPartenaire();
		fp.setPartenaire(partenaire);

		fp.getSessions().add(partenaireSession1);

		newSessions.add(new SessionDto(plbLevallois, levalloisSessions, YEAR));
		newSessions.add(new SessionDto(plbLyon, lyonSessions, YEAR));
		newSessions.add(new SessionDto(null, fp, YEAR));
		
		FormationPartenaire emptyFp = new FormationPartenaire();
		emptyFp.setPartenaire(partenaire);

		
		noSessions = new ArrayList<>();
		noSessions.add(new SessionDto(plbLevallois, new ArrayList<>(), YEAR));
		noSessions.add(new SessionDto(plbLyon, new ArrayList<>(), YEAR));
		noSessions.add(new SessionDto(null, emptyFp, YEAR));

	}
}
