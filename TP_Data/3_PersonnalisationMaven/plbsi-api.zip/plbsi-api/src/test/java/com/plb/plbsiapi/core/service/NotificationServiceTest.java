package com.plb.plbsiapi.core.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;

import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.offre.event.FormationModificationEvent;
import com.plb.plbsiapi.offre.model.Categorie;
import com.plb.plbsiapi.offre.model.Filiere;
import com.plb.plbsiapi.offre.model.Formation;

@SpringBootTest
public class NotificationServiceTest {

	
	@Autowired
	NotificationService notificationService;
	
	@SpyBean
	JavaMailSender javaMailSender;
	
	@Value("${plbsi.mail-enabled}")
	boolean mailEnabled;
	
	Account account;
	Formation formation;
	
	@BeforeEach
	public void setUp() {
		account = new Account();
		account.setEmail("dummy@plb.fr");
		account.setPrenom("David");
		account.setNom("Thibau");

		Filiere filiere = new Filiere();
		filiere.setUrl("/filiere");
		Categorie categorie = new Categorie();
		categorie.setFiliere(filiere);
		
		formation = new Formation();
		formation.setCurrentManager(account);
		formation.setReference("REF");
		formation.setLibelle("Libellé formation");
		formation.setUrl("/formation/id.php");
		formation.setCategorie(categorie);
		

		
		doNothing().when(javaMailSender).send(Mockito.any(MimeMessage.class));
	}
	
	@Test
	public void testMailerSend() throws MailException, FileNotFoundException, MessagingException, InterruptedException {
				
		FormationModificationEvent event = new FormationModificationEvent(account, formation, "bla-bla");
		
		notificationService.notifyEvent(event);
		
		Thread.sleep(1000);
		
		if ( mailEnabled ) {
			verify(javaMailSender).send(Mockito.any(MimeMessage.class));
		}
			
	}
	
	@Test
	public void testFormationModificationTemplate() throws MailException, MessagingException, IOException {
				
		FormationModificationEvent event = new FormationModificationEvent(account, formation, "bla-bla");
		
		MimeMessage message = notificationService.buildMail(account, event);
		
		assertThat(message.getContent().toString()).contains(formation.getLibelle())
													.contains(account.getNomComplet());
			
	}
}
