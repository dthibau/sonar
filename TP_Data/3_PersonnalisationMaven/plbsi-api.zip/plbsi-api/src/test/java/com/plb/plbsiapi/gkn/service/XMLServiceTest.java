package com.plb.plbsiapi.gkn.service;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.plb.plbsiapi.partenaire.gkn.GKNProperties;
import com.plb.plbsiapi.partenaire.gkn.model.GKNCourse;
import com.plb.plbsiapi.partenaire.gkn.model.GKNEvent;
import com.plb.plbsiapi.partenaire.gkn.service.XMLService;
import com.plb.plbsiapi.partenaire.gkn22.model.GKN22Course;
import com.plb.plbsiapi.partenaire.gkn22.model.GKN22Event;

@SpringBootTest
public class XMLServiceTest {

	XMLService xmlService;

	@BeforeEach
	public void before() throws IOException {
		GKNProperties gknProperties = new GKNProperties();
		xmlService = new XMLService(gknProperties);

	}
	@Test
	public void testParseTarifsFile() throws JAXBException {
		File f = new File("src/test/resources/testCourses.xml");
		List<GKNCourse> courses = xmlService.parseTarifs(f);
		
		assertFalse(courses.isEmpty());

	}
	@Test
	public void testParseEventsFile() throws JAXBException {
		File f = new File("src/test/resources/testEvents.xml");
		List<GKNEvent> events = xmlService.parseEvents(f);
		
		assertFalse(events.isEmpty());
		assertFalse(events.get(0).getSessions().getDates().isEmpty());


	}
	
	@Test
	public void testParseTarifs22File() throws JAXBException {
		File f = new File("src/test/resources/testCourses22.xml");
		List<GKN22Course> courses = xmlService.parseTarifs22(f);
		
		assertFalse(courses.isEmpty());

	}
	@Test
	public void testParseEvents22File() throws JAXBException {
		File f = new File("src/test/resources/testEvents22.xml");
		List<GKN22Event> events = xmlService.parseEvents22(f);
		
		assertFalse(events.isEmpty());
		assertTrue(events.get(0).getStartdate()!=null);


	}


	
}
