package com.plb.plbsiapi.offre.resource;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.model.Role;
import com.plb.plbsiapi.core.repository.AccountRepository;
import com.plb.plbsiapi.core.service.CoreService;
import com.plb.plbsiapi.offre.model.Categorie;
import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.model.Session;
import com.plb.plbsiapi.offre.model.SessionLieu;
import com.plb.plbsiapi.offre.repository.CategorieRepository;
import com.plb.plbsiapi.offre.repository.FormationRepository;
import com.plb.plbsiapi.offre.resource.views.FormationViews;
import com.plb.plbsiapi.offre.resource.views.MonthSessionDto;
import com.plb.plbsiapi.offre.resource.views.SessionDto;
import com.plb.plbsiapi.offre.service.SearchService;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
public class UpdateFormationResourceTest {

	@Autowired
	WebApplicationContext context;

	private MockMvc mvc;
		
	@Autowired
	FormationRepository formationRepository;
	
	@Autowired
	CategorieRepository categorieRepository;
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	private ObjectMapper jacksonObjectMapper;
	
	@Autowired
	private SearchService searchService;
	
	Formation formation;
	Categorie categorie;
	Account manager;
	
	@MockBean
	CoreService coreService;

	@BeforeEach
	public void setup() {
		mvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
		
		formation = formationRepository.findAll(PageRequest.of(0, 1)).toList().get(0);
		formation = searchService.get(formation.getIdFormation());

		
		manager = accountRepository.findAllActive().stream().filter(f -> f.getRoleList().contains(Role.MANAGER)).collect(Collectors.toList()).get(0);

		
	}

	@Test
	@WithMockUser
	public void updateFields_should_return_202_and_check_updates() throws Exception {
		// Remove les champs non impliqués
		jacksonObjectMapper.disable(MapperFeature.DEFAULT_VIEW_INCLUSION);
		String content = jacksonObjectMapper
			      .writerWithView(FormationViews.Detail.class)
			      .writeValueAsString(formation);

		mvc.perform(patch("/api/offre/formations").content(content).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted())
		.andExpect(jsonPath("$.message").isEmpty());
		
		formation.setLibelle("NEW");
		formation.setReference("NEW");
		formation.setVisible("yes");
			
		mvc.perform(patch("/api/offre/formations").content(content).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted())
		.andExpect(jsonPath("$.message").value(containsString("Libellé")))
		.andExpect(jsonPath("$.message").value(containsString("Référence")))
		.andExpect(jsonPath("$.message").value(containsString("Visible")));
;
	}
	@Test
	@WithMockUser
	public void updateStatut_should_return_202_and_check_updates() throws Exception {
		
		when(coreService.getLoggedAccount()).thenReturn(manager);
		String newStatut = ""+System.currentTimeMillis();
		// Juste Update Statut
		String content = "{\"idFormation\":"+formation.getIdFormation()+",\"statut\":\""+ newStatut +"\"}";
		mvc.perform(patch("/api/offre/formations/statut").content(content).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		mvc.perform(get("/api/offre/formations/"+formation.getIdFormation()).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.statut").value(is(newStatut)))
		.andExpect(jsonPath("$.currentManager").isEmpty());
		
		// Statut + currentManager
		newStatut = ""+System.currentTimeMillis();
		
		content = "{\"idFormation\":"+formation.getIdFormation()+",\"statut\":\""+ System.currentTimeMillis() +
				"\",\"currentManager\": {\"id\":" + manager.getId() + "}" +
				"}";
		mvc.perform(patch("/api/offre/formations/statut").content(content).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		mvc.perform(get("/api/offre/formations/"+formation.getIdFormation()).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.statut").value(is(newStatut)))
		.andExpect(jsonPath("$.currentManager").isNotEmpty());
		
		// On est sur qu'il y a un currentManager et on veut vérifier que l'on peut l'effacer
		content = "{\"idFormation\":"+formation.getIdFormation()+",\"statut\":\""+ newStatut +"\"}";
		mvc.perform(patch("/api/offre/formations/statut").content(content).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		mvc.perform(get("/api/offre/formations/"+formation.getIdFormation()).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.currentManager").isEmpty());

	}
	
	@Test
	@WithMockUser
	public void updateSessions_should_return_202_and_check_updates() throws Exception {
		
		when(coreService.getLoggedAccount()).thenReturn(manager);
		int year = LocalDate.now().getYear();
		List<SessionDto> oldSessionDtos = formation.getAllSessionsDto(year);
		boolean modified = false;
		for (SessionDto dto : oldSessionDtos ) {
			for ( MonthSessionDto ms : dto.getMonthSessions() ) {
				for (Session s : ms.getSessions() ) {
					s.setDebut(s.getDebut().plusDays(1));
					s.setFin(s.getFin().plusDays(1));
					modified = true;
					break;
				}
				if (modified)
					break;
			}
			if (modified)
				break;
		}
		if ( !modified ) {
			Session addSession = new Session();
			addSession.setDebut(LocalDate.now());
			addSession.setFin(LocalDate.now().plus(formation.getDuree(),ChronoUnit.DAYS));
			List<Session> sessions = new ArrayList<Session>();
			sessions.add(addSession);
			SessionLieu sessionLieu = new SessionLieu();
			sessionLieu.setId(1l);
			oldSessionDtos.add(new SessionDto(sessionLieu,sessions, year));
		}

		jacksonObjectMapper.disable(MapperFeature.DEFAULT_VIEW_INCLUSION);

		oldSessionDtos.stream().forEach(dto -> {
			dto.getAllSessions().stream().forEach(s -> s.setId(0));
		});
	    String content = jacksonObjectMapper
	      .writerWithView(FormationViews.List.class)
	      .writeValueAsString(oldSessionDtos);

	    
	    MvcResult result = mvc.perform(patch("/api/offre/formations/sessions/{id}/{year}",formation.getIdFormation(),year).content(content).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted())
		.andExpect(jsonPath("$.message").hasJsonPath())
//		.andExpect(jsonPath("$.message").value(containsString("Session")))
//		.andExpect(jsonPath("$.message").value(containsString("ajout")))
		.andReturn();
		
		System.out.println(result.getResponse().getContentAsString());

		
	}
	
	@Test
	@WithMockUser
	public void sort_should_return_202_and_Check_Updates() throws Exception {
		
		categorie = formation.getCategorie();
		
		List<Formation> formations = formationRepository.findByCategorieId(categorie.getId());
		Collections.shuffle(formations);
		
		String content = jacksonObjectMapper
			      .writerWithView(FormationViews.SmallList.class)
			      .writeValueAsString(formations);
		
		mvc.perform(put("/api/offre/formations/sort/"+categorie.getId())
			.content(content).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		// Check updates
		List<Formation> updatedFormations = formationRepository.findByCategorieId(categorie.getId());

		assertThat(updatedFormations,is(formations));


	}

	@Test
	@WithMockUser
	public void updateCategoriePrincipale_should_return_202_and_Check_Updates() throws Exception {
		
		Optional<Categorie> cat = categorieRepository.findAll().stream().filter(c -> !c.equals(formation.getCategorie()) && !formation.containsFiliere(c.getFiliere())).findAny();
		categorie = cat.get();
		
		
		mvc.perform(put("/api/offre/formations/categorie/"+categorie.getId()+"/"+formation.getIdFormation())
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		// Check updates
		Formation actual = formationRepository.findById(formation.getIdFormation()).orElseThrow(() -> new Exception());

		assertThat(actual.getCategorie(),is(categorie));
		assertThat(actual.getFormationFilierePrincipale().getCategorie(),is(categorie));

	}
	
	@Test
	@WithMockUser
	public void addThenRemoveCategorieSecondaire_should_return_202_and_Check_Updates() throws Exception {
		
		Optional<Categorie> cat = categorieRepository.findAll().stream().filter(c -> !c.equals(formation.getCategorie()) && !formation.containsFiliere(c.getFiliere())).findAny();
		categorie = cat.get();
		
		
		mvc.perform(post("/api/offre/formations/secondaire/"+categorie.getId()+"/"+formation.getIdFormation())
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		// Check updates
		Formation actual = formationRepository.findById(formation.getIdFormation()).orElseThrow(() -> new Exception());

		assertThat(actual.getFormationFiliere(categorie),notNullValue());


		mvc.perform(delete("/api/offre/formations/secondaire/"+categorie.getId()+"/"+formation.getIdFormation())
				.contentType(MediaType.APPLICATION_JSON))
			.andExpect(status().isAccepted());
		
		actual = formationRepository.findById(formation.getIdFormation()).orElseThrow(() -> new Exception());

		assertThat(actual.getFormationFiliere(categorie),nullValue());
	}

	@Test
	@WithMockUser
	public void addThenRemoveAssociee_should_return_202_and_Check_Updates() throws Exception {
		
		Optional<Formation> opt = formationRepository.findAll().stream().filter(f -> !f.equals(formation) && !formation.getFormationAssociees().contains(f)).findAny();
		Formation associee = opt.get();
		
		
		mvc.perform(post("/api/offre/formations/associee/"+associee.getIdFormation()+"/"+formation.getIdFormation())
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		// Check updates
		Formation actual = searchService.get(formation.getIdFormation());
		
		assertTrue(actual.getFormationAssociees().contains(associee));


		mvc.perform(delete("/api/offre/formations/associee/"+associee.getIdFormation()+"/"+formation.getIdFormation())
				.contentType(MediaType.APPLICATION_JSON))
			.andExpect(status().isAccepted());
		
		actual = searchService.get(formation.getIdFormation());
		
		assertTrue(!actual.getFormationAssociees().contains(associee));
	}

	@Test
	@WithMockUser
	public void addThenRemoveMutualisee_should_return_202_and_Check_Updates() throws Exception {
		
		Optional<Formation> opt = formationRepository.findAll().stream().filter(f -> !f.equals(formation) ).findAny();
		Formation mutualisee = opt.get();
		List<Formation> transitives = mutualisee.getFormationMutualisees().getFormations();
		
		
		mvc.perform(post("/api/offre/formations/mutualisee/"+mutualisee.getIdFormation()+"/"+formation.getIdFormation())
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		// Check updates
		Formation actual = searchService.get(formation.getIdFormation());
		
		assertTrue(actual.getFormationMutualisees().getFormations().contains(mutualisee));
		for ( Formation t : transitives ) {
			assertTrue(actual.getFormationMutualisees().getFormations().contains(t));
		}

		mvc.perform(delete("/api/offre/formations/mutualisee/"+mutualisee.getIdFormation()+"/"+formation.getIdFormation())
				.contentType(MediaType.APPLICATION_JSON))
			.andExpect(status().isAccepted());
		
		actual = searchService.get(formation.getIdFormation());
		
		assertTrue(!actual.getFormationMutualisees().getFormations().contains(mutualisee));
	}

	@Test
	@WithMockUser
	public void updateBloc_should_return_202_and_Check_Updates() throws Exception {
		
		String content="An <b>HTML</b> Text";
		
		mvc.perform(put("/api/offre/formations/bloc/intra/"+formation.getIdFormation())
				.content(content)
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		// Check updates
		Formation actual = searchService.get(formation.getIdFormation());
		
		assertTrue(actual.getBlocIntra().equals(content));


		mvc.perform(put("/api/offre/formations/bloc/commercialisation/"+formation.getIdFormation())
				.content(content)
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		actual = searchService.get(formation.getIdFormation());
		
		assertTrue(actual.getBlocCommercialisation().equals(content));
		
		mvc.perform(put("/api/offre/formations/bloc/argumentaire/"+formation.getIdFormation())
				.content(content)
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		actual = searchService.get(formation.getIdFormation());
		
		assertTrue(actual.getBlocArgumentaire().equals(content));
		
		mvc.perform(put("/api/offre/formations/bloc/certification/"+formation.getIdFormation())
				.content(content)
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		actual = searchService.get(formation.getIdFormation());
		
		assertTrue(actual.getBlocCertification().equals(content));
		
		mvc.perform(put("/api/offre/formations/bloc/cpf/"+formation.getIdFormation())
				.content(content)
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		actual = searchService.get(formation.getIdFormation());
		
		assertTrue(actual.getBlocCpf().equals(content));
		
		mvc.perform(put("/api/offre/formations/bloc/cpf/"+formation.getIdFormation())
			.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isAccepted());
		
		actual = searchService.get(formation.getIdFormation());
		
		assertThat(actual.getBlocCpf(),nullValue());
	}

}
