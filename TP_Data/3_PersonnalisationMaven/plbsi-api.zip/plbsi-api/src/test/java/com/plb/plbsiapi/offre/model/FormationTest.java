package com.plb.plbsiapi.offre.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.plb.plbsiapi.offre.resource.views.LieuOrganisme;

public class FormationTest {

	static String PARTENAIRE_NOM="Partenaire";
	Formation formation;
	SessionLieu plbLevallois,plbLyon;
	Session levalloisSession, lyonSession, partenaireSession;

	@BeforeEach
	public void init() {
		Partenaire partenaire = new Partenaire();
		partenaire.setId(1);
		partenaire.setNom(PARTENAIRE_NOM);
		plbLevallois = new SessionLieu();
		plbLevallois.setId(1L);
		plbLyon = new SessionLieu();
		plbLyon.setId(2L);
		formation = new Formation();
		formation.setIdFormation(1);
		levalloisSession = new Session();
		levalloisSession.setSessionLieu(plbLevallois);
		levalloisSession.setId(1);
		lyonSession = new Session();
		lyonSession.setSessionLieu(plbLyon);
		lyonSession.setId(1);
		partenaireSession = new Session();
		partenaireSession.setId(3);
	
		formation.getSessions().add(levalloisSession);
		formation.getSessions().add(lyonSession);
		formation.getSessions().add(partenaireSession);
		
		FormationPartenaire fp = new FormationPartenaire();
		fp.getSessions().add(partenaireSession);
		fp.setPartenaire(partenaire);
		fp.setFormation(formation);
		
		formation.getFormationsPartenaire().add(fp);
	}
	
	@Test
	public void testSessionsPLB() {
		Map<SessionLieu,List<Session>> map = formation.getSessionsPLB();
		
		assertThat(map).containsKeys(plbLevallois, plbLyon)
		               .extractingByKey(plbLevallois).asList().contains(levalloisSession);
	}
	@Test
	public void testSessionsPLB_LieuOrganisme() {
		LieuOrganisme lieuOrganisme = new LieuOrganisme("PLB", plbLyon);
		List<Session> list = formation.getSessionsPLB(lieuOrganisme);
		
		assertThat(list).containsOnly(lyonSession);
	}
	
	@Test
	public void testSessionsPartenaire() {
		Map<LieuOrganisme,List<Session>> map = formation.getSessionsPartenaires();
		
		LieuOrganisme lieuOrganisme = new LieuOrganisme(PARTENAIRE_NOM, null);
		assertThat(map).containsKeys(lieuOrganisme)
		               .extractingByKey(lieuOrganisme).asList().contains(partenaireSession);
	}
}
