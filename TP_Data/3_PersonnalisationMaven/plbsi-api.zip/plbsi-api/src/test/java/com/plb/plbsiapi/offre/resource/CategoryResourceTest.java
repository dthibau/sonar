package com.plb.plbsiapi.offre.resource;

import static org.assertj.core.api.Assertions.fail;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.plb.plbsiapi.offre.model.Categorie;
import com.plb.plbsiapi.offre.model.CategorieConnexe;
import com.plb.plbsiapi.offre.repository.CategorieRepository;
import com.plb.plbsiapi.service.ImportGKNService;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CategoryResourceTest {

	@Autowired
	WebApplicationContext context;

	private MockMvc mvc;
	private Categorie oneCategorie;
	private CategorieConnexe firstConnexe;
	
	@MockBean
	ImportGKNService mockImportGKNService;
	
	@Autowired
	CategorieRepository categorieRepository;

	@BeforeEach
	public void setup() {
		mvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
		List<Categorie> categories = categorieRepository.findAll();
		for ( int i=0 ; i<5; i++) {
			oneCategorie = categorieRepository.fullLoad(categories.get(i).getId()).get();
			if ( oneCategorie.getCategoriesConnexes().size() > 0 ) {
				firstConnexe = oneCategorie.getCategoriesConnexes().get(0);
			}
		}
		if ( firstConnexe == null ) {
			fail("Aucune catégorie valide pour le test");
		}
	}

	@Test
	@WithMockUser
	public void getAll_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/categories").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	@Test
	@WithMockUser
	public void getConnexes_should_return_200_and_check_json() throws Exception {
		// Find an id
		mvc.perform(get("/api/offre/categories/connexes/"+oneCategorie.getId()).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id", is((int)firstConnexe.getId())))
				.andExpect(jsonPath("$[0].linkedId", is((int)firstConnexe.getLinkedId())))
				.andExpect(jsonPath("$[0].linkedLibelle", is(firstConnexe.getLinkedLibelle())))
				.andExpect(jsonPath("$[0].linkedRang", is((int)firstConnexe.getLinkedRang())));
	}
	@Test
	@WithMockUser
	public void getReferentes_should_return_200() throws Exception {
		// Find an id
		mvc.perform(get("/api/offre/categories/referentes/"+oneCategorie.getId()).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	
	

}
