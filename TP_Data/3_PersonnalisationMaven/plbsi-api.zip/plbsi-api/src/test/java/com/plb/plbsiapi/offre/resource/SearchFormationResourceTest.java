package com.plb.plbsiapi.offre.resource;

import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.condition.DisabledIfEnvironmentVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.plb.plbsiapi.offre.service.IndexingService;
import com.plb.plbsiapi.service.ImportGKNService;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@TestMethodOrder(OrderAnnotation.class)
public class SearchFormationResourceTest {

	@Autowired
	WebApplicationContext context;

	private MockMvc mvc;
	
	@MockBean
	ImportGKNService mockImportGKNService;
	
	@Autowired
	IndexingService indexingService;


	@BeforeEach
	public void setup() throws InterruptedException {
		mvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
		

	}

	@Test
	@WithMockUser
	public void getAll_should_return_200() throws Exception {
		
		mvc.perform(get("/api/offre/formations").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
		mvc.perform(get("/api/offre/formations?archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

	@Test
	@WithMockUser
	public void getAllPaged_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?page=1").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
	}

	@Test
	@WithMockUser
	public void getAllPagedSort_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?page=1&sortColumn=libelle&sortOrder=desc").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
	}

	@Test
	@Order(1)   
	@WithMockUser
    @DisabledIfEnvironmentVariable(named = "JENKINS_HOME", matches = ".*")
	public void getFullText_should_return_200() throws Exception {
		
		indexingService.initiateIndexing();

		
		mvc.perform(get("/api/offre/formations?q=java").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
		mvc.perform(get("/api/offre/formations?q=java&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}
	@Test
	@WithMockUser
    @DisabledIfEnvironmentVariable(named = "JENKINS_HOME", matches = ".*")
	public void getFullTextWithFiliere_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?q=java&filiereId=1").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?q=java&filiereId=1&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}
	
	@Test
	@WithMockUser
    @DisabledIfEnvironmentVariable(named = "JENKINS_HOME", matches = ".*")
	public void getFullTextWithExcluPLB_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?q=java&excluPLB=true").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?q=java&excluPLB=true&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

	@Test
	@WithMockUser
    @DisabledIfEnvironmentVariable(named = "JENKINS_HOME", matches = ".*")
	public void getFullTextWithPartenaire_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?q=java&partenaireId=7").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?q=java&partenaireId=7&aechived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

	@Test
	@WithMockUser
    @DisabledIfEnvironmentVariable(named = "JENKINS_HOME", matches = ".*")
	public void getFullTextPaged_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?q=java&page=1").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
	}

	@Test
	@WithMockUser
    @DisabledIfEnvironmentVariable(named = "JENKINS_HOME", matches = ".*")
	public void getFullTextPagedSort_BigSize_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?q=java&page=0&size=9999&sortColumn=libelle&sortOrder=desc").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
	}

	@Test
	@WithMockUser
    @DisabledIfEnvironmentVariable(named = "JENKINS_HOME", matches = ".*")
	public void getFullTextPagedSort_OffsetExceed_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?q=java&page=1&size=9999&sortColumn=libelle&sortOrder=desc").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	@WithMockUser
    @DisabledIfEnvironmentVariable(named = "JENKINS_HOME", matches = ".*")
	public void getFullTextPagedSort_EndPageExceed_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?q=java&page=0&size=9999&sortColumn=libelle&sortOrder=desc").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
	}

	@Test
	@WithMockUser
	public void getFiliere_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?filiereId=1").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?filiereId=1&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

	@Test
	@WithMockUser
	public void getFiliereWithSort_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?filiereId=1&sortColumn=categorieLibelle").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
	}

	@Test
	@WithMockUser
	public void getCategorie_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?categorieId=1261088").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?categorieId=1261088&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

	@Test
	@WithMockUser
	public void getCategorieFiliere_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?filiereId=1&categorieId=1261088").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?filiereId=1&categorieId=1261088&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

	@Test
	@WithMockUser
	public void getPartenaire_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?partenaireId=30").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?partenaireId=30&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

	@Test
	@WithMockUser
	public void getExcluPLB_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?excluPlb=true").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?excluPlb=true&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

	@Test
	@WithMockUser
	public void getFilierePartenaire_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?filiereId=29&partenaireId=30").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?filiereId=29&partenaireId=30&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

	@Test
	@WithMockUser
	public void getFiliereExcluPLB_should_return_200() throws Exception {
		mvc.perform(get("/api/offre/formations?filiereId=1&excluPlb=true").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				;
		mvc.perform(get("/api/offre/formations?filiereId=1&excluPlb=true&archived=true").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());

	}

}
