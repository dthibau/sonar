package com.plb.plbsiapi.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.plb.plbsiapi.NotFoundException;
import com.plb.plbsiapi.core.repository.FormationPartenaireRepository;
import com.plb.plbsiapi.offre.model.FormationPartenaire;
import com.plb.plbsiapi.offre.model.Partenaire;
import com.plb.plbsiapi.offre.repository.PartenaireRepository;
import com.plb.plbsiapi.partenaire.ImportResultDto;
import com.plb.plbsiapi.partenaire.UpdateLineDto;
import com.plb.plbsiapi.partenaire.gkn.GKNPartenaire;
import com.plb.plbsiapi.partenaire.gkn.GKNProperties;
import com.plb.plbsiapi.partenaire.gkn.model.GKNCourse;
import com.plb.plbsiapi.partenaire.gkn.model.GKNEvent;
import com.plb.plbsiapi.partenaire.gkn.service.XMLService;
import com.plb.plbsiapi.partenaire.gkn22.model.GKN22Course;
import com.plb.plbsiapi.partenaire.gkn22.model.GKN22Event;

@Service
public class ImportGKNService {

	@Autowired
	XMLService xmlService;

	@Autowired
	ImportService importService;
	
	@Autowired
	PartenaireRepository partenaireRepository;
	
	@Autowired
	FormationPartenaireRepository formationPartenaireRepository;

	@Autowired
	private GKNProperties gknProperties;

	private static final Logger logger = LoggerFactory.getLogger(ImportGKNService.class);

	public List<ImportResultDto> importGKN() throws JAXBException,NotFoundException {
		
		List<ImportResultDto> ret = new ArrayList<>();
		ImportResultDto result = null;
		for (String nomPartenaire : gknProperties.getPartenaires().keySet() ) {
			// Retreive partenaire Id
			Partenaire partenaire = partenaireRepository.findByNomIgnoreCase(nomPartenaire).orElseThrow(() -> new NotFoundException("Partenaire GKN pas trouvé dans la base !!"));
			ret.add(importGKN(partenaire));
		}
		return ret;
			
	}
	public ImportResultDto importGKN(Partenaire partenaire) throws JAXBException {

		List<GKNEvent> events = _filterEvents(gknProperties.getPartenaires().get(partenaire.getNom()),xmlService.parseEvents());

		List<GKNCourse> courses = xmlService.parseCourses();

		logger.debug("Found " + courses.size() + " cours");
		logger.debug("Found " + events.size() + " sessions");

		List<UpdateLineDto> lines = new ArrayList<>();
		for (GKNCourse course : courses) {
			UpdateLineDto line = new UpdateLineDto();
			line.setReference(course.getCode());
			line.setDuree(course.getDuree());
			line.setTarif(course.getPrix());
			line.setValid(true);

			for (GKNEvent event : events) {
				if (event.getCode().equals(course.getCode()) && event.getStartDate() != null ) {
					line.getSessions().add(event.getStartDate());
				}
			}
			lines.add(line);
		}

		return importService.importLines(partenaire, LocalDate.now(), lines);

	}


	private List<GKNEvent> _filterEvents(GKNPartenaire gknPartenaire, List<GKNEvent> events) {
		logger.debug("Before filtering sessions are " + events.size());
		List<GKNEvent> ret = new ArrayList<>();
		List<String> allowedLocations = gknPartenaire.getAllowedLocations();
		
		for (GKNEvent event : events) {
			if (allowedLocations.contains(event.getLocation()) ) {
				ret.add(event);
			}
		}
		logger.debug("After filtering sessions are " + ret.size());
		
		return ret;

	}
	
	public ImportResultDto copyGKNDistant() throws NotFoundException {
		
		ImportResultDto ret = new ImportResultDto();
		Set<String> notUpdated = new HashSet<>();
		
		Partenaire gkn = partenaireRepository.findByNomIgnoreCase("GKN").orElseThrow(() -> new NotFoundException("Partenaire GKN pas trouvé dans la base !!"));
		Partenaire gknDistant = partenaireRepository.findByNomIgnoreCase("GKN-Distant").orElseThrow(() -> new NotFoundException("Partenaire GKN-Distant pas trouvé dans la base !!"));
		
	
		List<FormationPartenaire> fpsGkn = formationPartenaireRepository.findByPartenaire(gkn);
		List<FormationPartenaire> fpsGknDistant = formationPartenaireRepository.findByPartenaire(gknDistant);

		for (FormationPartenaire fp : fpsGkn) {
			ret.countProcessed++;
			Optional<FormationPartenaire> optFound = fpsGknDistant.stream().filter(fpd -> fpd.getReference().equals(fp.getReference())).findFirst();
			if ( !optFound.isPresent() ) {
				FormationPartenaire newFp = new FormationPartenaire();
				newFp.setReference(fp.getReference());
				newFp.setUrl(fp.getUrl());
				newFp.setPrix(fp.getPrix());
				newFp.setFormation(fp.getFormation());
				newFp.setPartenaire(gknDistant);
				formationPartenaireRepository.save(newFp);
				ret.countUpdated++;
			} else {
				notUpdated.add(fp.getReference());
			}
		}
		
		return ret;
	}
	@Deprecated
	public ImportResultDto importGKN22(Partenaire partenaire) throws JAXBException {

		List<GKN22Event> events = _filterEvents22(gknProperties.getPartenaires().get(partenaire.getNom()),xmlService.parseEvents22());

		List<GKN22Course> courses = xmlService.parseCourses22();

		logger.debug("Found " + courses.size() + " cours");
		logger.debug("Found " + events.size() + " sessions");

		List<UpdateLineDto> lines = new ArrayList<>();
		for (GKN22Course course : courses) {
			UpdateLineDto line = new UpdateLineDto();
			line.setReference(course.getCode());
			line.setDuree(course.getDuree());
			line.setTarif(course.getPrix());
			line.setValid(true);

			for (GKN22Event event : events) {
				if (event.getCode().equals(course.getCode())) {
					line.getSessions().add(event.getStartdate());
				}
			}
			lines.add(line);
		}

		return importService.importLines(partenaire, LocalDate.now(), lines);

	}
	@Deprecated
	private List<GKN22Event> _filterEvents22(GKNPartenaire gknPartenaire, List<GKN22Event> events) {
		logger.debug("Before filtering sessions are " + events.size());
		List<GKN22Event> ret = new ArrayList<>();
		List<Integer> allowedLocations = gknPartenaire.getAllowedLocations22();
		List<String> allowedModality = gknPartenaire.getAllowedModality();
		for (GKN22Event event : events) {
			if (allowedLocations.contains(event.getLocationcode())
					&& allowedModality.contains(event.getModalitycode())) {
				ret.add(event);
			}
		}
		return ret;

	}
}
