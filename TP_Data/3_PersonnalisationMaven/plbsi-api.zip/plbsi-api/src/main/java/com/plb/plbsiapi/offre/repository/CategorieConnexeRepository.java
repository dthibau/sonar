package com.plb.plbsiapi.offre.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.plb.plbsiapi.offre.model.CategorieConnexe;

public interface CategorieConnexeRepository extends JpaRepository<CategorieConnexe, Long> {


	@Query("select cc from CategorieConnexe cc where cc.linkedCategorie.id = :id order by cc.baseCategorie.rang")
	public List<CategorieConnexe> findCategoriesReferentes(@Param("id") int id);

	@Query("select max(cc.order) from CategorieConnexe cc where cc.baseCategorie.id = :id")
	public Optional<Integer> findLastOrder(@Param("id") int id);
}
