package com.plb.plbsiapi.offre.service;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.plb.plbsiapi.core.model.Event;
import com.plb.plbsiapi.core.repository.AccountRepository;
import com.plb.plbsiapi.core.service.CoreService;
import com.plb.plbsiapi.core.service.EventService;
import com.plb.plbsiapi.core.service.NotificationService;
import com.plb.plbsiapi.offre.event.FormationModificationEvent;
import com.plb.plbsiapi.offre.event.FormationModificationSessionEvent;
import com.plb.plbsiapi.offre.model.Categorie;
import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.model.FormationFiliere;
import com.plb.plbsiapi.offre.model.FormationMutualisees;
import com.plb.plbsiapi.offre.repository.CategorieRepository;
import com.plb.plbsiapi.offre.repository.FormationFiliereRepository;
import com.plb.plbsiapi.offre.repository.FormationRepository;
import com.plb.plbsiapi.offre.resource.views.SessionDto;
import com.plb.plbsiapi.offre.resource.views.UpdateFormationResponse;

@Service
public class UpdateFormationService {

	@Autowired
	FormationRepository formationRepository;
	
	@Autowired
	CategorieRepository categorieRepository;

	@Autowired
	FormationFiliereRepository formationFiliereRepository;

	@Autowired
	EventService eventService;

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	CoreService coreService;

	@Autowired
	MergeFormationService mergeFormationService;
	
	@Autowired
	NotificationService notificationService;

	@Autowired
	SearchService searchService;
	
	@Autowired
	EntityManager entityManager;
	

	public UpdateFormationResponse update(Formation patch)
			throws EntityNotFoundException, MailException, FileNotFoundException, MessagingException {
		Formation formation = formationRepository.findById(patch.getIdFormation())
				.orElseThrow(() -> new EntityNotFoundException());

		String modif = mergeFormationService.mergeFormation(formation, patch);

		if (modif.length() > 0) {
			Event event = eventService.logEvent(new FormationModificationEvent(coreService.getLoggedAccount(), formation, modif));
			formation.setDateModification(new Date());
			formationRepository.save(formation);

			notificationService.notifyEvent(event);

		}
		return new UpdateFormationResponse(formation,modif);
	}
	
	public UpdateFormationResponse updateStatut(Formation patch)
			throws EntityNotFoundException, MailException, FileNotFoundException, MessagingException {
		Formation formation = formationRepository.findById(patch.getIdFormation())
				.orElseThrow(() -> new EntityNotFoundException());

		String modif = mergeFormationService.mergeStatut(formation, patch);

		if (modif.length() > 0) {
			Event event = eventService.logEvent(new FormationModificationEvent(coreService.getLoggedAccount(), formation, modif));
			formation.setDateModification(new Date());
			formationRepository.save(formation);

			notificationService.notifyEvent(event);

		}
		return new UpdateFormationResponse(formation,modif);
	}


	
	public UpdateFormationResponse updateSessions(int year, Integer id, List<SessionDto> sessionDtos)
			throws EntityNotFoundException, MailException, FileNotFoundException, MessagingException {

		Formation formation = searchService.get(id);

		String modif = mergeFormationService.mergeSessions(formation, sessionDtos, year);

		if (modif.length() > 0) {

			Event event = eventService.logEvent(new FormationModificationSessionEvent(coreService.getLoggedAccount(), formation, modif));
			formation.setDateModification(new Date());
			formationRepository.save(formation);

			notificationService.notifyEvent(event);

		}
		return new UpdateFormationResponse(formation,modif);
	}

	@Transactional
	public void sortFormation(int idCategorie, List<Formation> formations) {
		Categorie categorie = categorieRepository.findById(idCategorie).orElseThrow(() -> new EntityNotFoundException("No such categorie :"+idCategorie));
		
		for ( int i=0; i< formations.size(); i++) {
			Formation f = formationRepository.findById(formations.get(i).getIdFormation()).orElseThrow(() -> new EntityNotFoundException("No such formation"+formations.get(0).getIdFormation()));
			FormationFiliere ff = f.getFormationFiliere(categorie);
			if ( ff != null ) {
				ff.setRang(i);
			} else {
				ff = formations.get(i).addCategorieSecondaire(categorie);
				ff.setRang(i);
				entityManager.persist(ff);			
			}
			formationRepository.save(f);
		}
	}
	
	@Transactional
	public UpdateFormationResponse updateCategorie(int idCategorie, int idFormation) {
		Categorie categorie = categorieRepository.findById(idCategorie).orElseThrow(() -> new EntityNotFoundException("No such categorie :"+idCategorie));
		Formation formation = formationRepository.findById(idFormation).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idFormation));
		FormationFiliere oldCategorie = formation.getFormationFilierePrincipale();
		FormationFiliere ff = formation.addCategoriePrincipale(categorie);
		ff.setRang(formationRepository.countByCategorieId(categorie.getId()));
		entityManager.persist(ff);
		entityManager.remove(oldCategorie);
		formation.setCategorie(categorie);
		formation.removeFormationFiliere(oldCategorie.getCategorie());
		
		return new UpdateFormationResponse(formation,"Catégorie principale : " + oldCategorie.getCategorie().getLibelle() + " -> " + categorie.getLibelle());
	

	}
	
	@Transactional
	public UpdateFormationResponse addCategorieSecondaire(int idCategorie, int idFormation) {
		Categorie categorie = categorieRepository.findById(idCategorie).orElseThrow(() -> new EntityNotFoundException("No such categorie :"+idCategorie));
		Formation formation = formationRepository.findById(idFormation).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idFormation));
		FormationFiliere ff = formation.addCategorieSecondaire(categorie);
		ff.setRang(formationRepository.countByCategorieId(categorie.getId()));
		entityManager.persist(ff);
		
		return new UpdateFormationResponse(formation,"Catégorie secondaire " + categorie.getLibelle() + " ajoutée");
	

	}
	
	@Transactional
	public UpdateFormationResponse removeCategorieSecondaire(int idCategorie, int idFormation) {
		Categorie categorie = categorieRepository.findById(idCategorie).orElseThrow(() -> new EntityNotFoundException("No such categorie :"+idCategorie));
		Formation formation = formationRepository.findById(idFormation).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idFormation));
		entityManager.remove(formation.getFormationFiliere(categorie));
		formation.removeFormationFiliere(categorie);
//	
//		formationRepository.save(formation);
		
		return new UpdateFormationResponse(formation,"Catégorie secondaire " + categorie.getLibelle() + " supprimée");

	}
	
	@Transactional
	public UpdateFormationResponse addFormationAssociee(int idAssociee, int idFormation) {
		Formation associee = formationRepository.findById(idAssociee).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idAssociee));
		Formation formation = formationRepository.findById(idFormation).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idFormation));
		formation.getFormationAssociees().add(associee);
		
		formationRepository.save(formation);
		
		return new UpdateFormationResponse(formation,"Formation " + associee.getLibelle() + " associée");
	

	}
	
	@Transactional
	public UpdateFormationResponse removeFormationAssociee(int idAssociee, int idFormation) {
		Formation associee = formationRepository.findById(idAssociee).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idAssociee));
		Formation formation = formationRepository.findById(idFormation).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idFormation));
		formation.getFormationAssociees().remove(associee);
	
		formationRepository.save(formation);
		
		return new UpdateFormationResponse(formation,"Formation " + formation.getLibelle() + " désassociée");

	}

	@Transactional
	public UpdateFormationResponse addFormationMutualisee(int idMutualisee, int idFormation) {
		Formation mutualisee = formationRepository.findById(idMutualisee).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idMutualisee));
		Formation formation = formationRepository.findById(idFormation).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idFormation));
		
		StringBuilder sb = new StringBuilder();
		if (formation.getFormationMutualisees() != null) {
			if (mutualisee.getFormationMutualisees() != null) {
				sb.append("Les groupes de formations ont été fusionnés :");
				mutualisee.getFormationMutualisees().getFormations().stream().forEach(f -> {
					formation.getFormationMutualisees().addFormation(f);
					sb.append(f.getReference() + " ");
				});
				mutualisee.getFormationMutualisees().setFormations(new ArrayList<Formation>());
				entityManager.remove(mutualisee.getFormationMutualisees());
			} else {
				formation.getFormationMutualisees().addFormation(mutualisee);
				sb.append("La formation '" + mutualisee + "' a été ajoutée au groupe de formation");
			}
			formationRepository.save(formation);
		} else {
			if (mutualisee.getFormationMutualisees() != null) {
				sb.append("La formation '" + formation + "' a été ajoutée à un groupe existant :");
				mutualisee.getFormationMutualisees().getFormations().stream().forEach(f -> {
					sb.append(f.getReference() + " ");
				});
					
				mutualisee.getFormationMutualisees().addFormation(formation);
				formationRepository.save(mutualisee);
			} else {
				FormationMutualisees formationMutualisees = new FormationMutualisees();
				formationMutualisees.addFormation(mutualisee);
				formationMutualisees.addFormation(formation);
				entityManager.persist(formationMutualisees);
				sb.append("Un nouveau groupe de formation a été créé pour '" + formation + "','"+mutualisee+"'");
			}
		}
		
		return new UpdateFormationResponse(formation,sb.toString());
	
	}
	
	@Transactional
	public UpdateFormationResponse removeFormationMutualisee(int idMutualisee, int idFormation) {
		Formation mutualisee = formationRepository.findById(idMutualisee).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idMutualisee));
		Formation formation = formationRepository.findById(idFormation).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idFormation));

		formation.getFormationMutualisees().removeFormation(mutualisee);

	
		formationRepository.save(formation);
		
		return new UpdateFormationResponse(formation,"Formation " + formation.getLibelle() + " dégroupée");

	}

	@Transactional
	public void updateBloc(String bloc, int idFormation, String content) {
		Formation formation = formationRepository.findById(idFormation).orElseThrow(() -> new EntityNotFoundException("No such formation :"+idFormation));

		if ( bloc.equalsIgnoreCase("Commercialisation") ) {
			formation.setBlocCommercialisation(content);
		} else if ( bloc.equalsIgnoreCase("Intra") ) {
			formation.setBlocIntra(content);
		} else if ( bloc.equalsIgnoreCase("Argumentaire") ) {
			formation.setBlocArgumentaire(content);
		} else if ( bloc.equalsIgnoreCase("Certification") ) {
			formation.setBlocCertification(content);
		} else if ( bloc.equalsIgnoreCase("Cpf") ) {
			formation.setBlocCpf(content);
		}
		
		formationRepository.save(formation);
	}

}
