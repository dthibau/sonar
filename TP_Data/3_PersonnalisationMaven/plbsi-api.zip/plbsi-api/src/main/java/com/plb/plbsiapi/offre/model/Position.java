package com.plb.plbsiapi.offre.model;

import javax.persistence.Embeddable;

import lombok.Data;

@Embeddable
@Data 
public class Position {

	private Float latitude;
	private Float longitude;
}
