package com.plb.plbsiapi.core.resource;

import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.model.Role;
import com.plb.plbsiapi.core.repository.AccountRepository;

import java.net.URI;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping(path="/api/backoffice/accounts")
public class AccountResource {
	
	@Autowired
	AccountRepository accountRepository;
	
	@GetMapping
	public List<Account> getAll(@RequestParam(required=false) String role) {
		return accountRepository.findAll();
	}
	
	@GetMapping(path="/role")
	public List<Account> getAllFromRole(@RequestParam String role) {
		return accountRepository.findAllActive().stream().filter(f -> f.getRoleList().contains(Role.valueOf(role))).collect(Collectors.toList());
	}
	
	@PostMapping
	public ResponseEntity<Object> createAccount(@RequestBody Account account) {
		Account savedAccount = accountRepository.save(account);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(savedAccount.getId()).toUri();

		return ResponseEntity.created(location).build();
	}
	
	@PatchMapping("/{id}")
	public ResponseEntity<Object> updateAccount(@RequestBody Account account, @PathVariable long id) {
		Optional<Account> foundAccount = accountRepository.findById(id);
		if (foundAccount.isPresent()) {
			foundAccount.get().setLogin(account.getLogin());
			foundAccount.get().setEmail(account.getEmail());
			foundAccount.get().setNom(account.getNom());;
			foundAccount.get().setPrenom(account.getPrenom());
			foundAccount.get().setPassword(account.getPassword());;
			foundAccount.get().setRoles(account.getRoles());
			foundAccount.get().setTelephone(account.getTelephone());
			foundAccount.get().setDeletedDate(account.getDeletedDate());
			accountRepository.save(foundAccount.get());
		}
		
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(foundAccount.get().getId()).toUri();

		return ResponseEntity.created(location).build();
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteAccount(@PathVariable long id) {
		Optional<Account> foundAccount = accountRepository.findById(id);
		if (foundAccount.isPresent()) {
			foundAccount.get().setDeletedDate(new Date());
			accountRepository.save(foundAccount.get());
		}
		
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(foundAccount.get().getId()).toUri();

		return ResponseEntity.created(location).build();
	}
}
