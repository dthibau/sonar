package com.plb.plbsiapi.partenaire.gkn.model;

import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "event")
@XmlAccessorType(XmlAccessType.FIELD)
public class GKNEvent {

	@XmlElement(name = "eventid")
	private String eventid;
	@XmlElement(name = "code")
	private String code;
	@XmlElement(name = "location")
	private String location;
	@XmlElement(name = "sessions")
	private GKNSession sessions;

	public String getEventid() {
		return eventid;
	}

	public void setEventid(String eventid) {
		this.eventid = eventid;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public GKNSession getSessions() {
		return sessions;
	}

	public void setSessions(GKNSession sessions) {
		this.sessions = sessions;
	}

	public LocalDate getStartDate() {
		LocalDate ret = null;
		if (sessions != null) {
			for (LocalDate date : sessions.getDates()) {
				if (ret == null) {
					ret = date;
				} else if (date.isBefore(ret)) {
					ret = date;
				}
			}
		}
		return ret;

	}

}
