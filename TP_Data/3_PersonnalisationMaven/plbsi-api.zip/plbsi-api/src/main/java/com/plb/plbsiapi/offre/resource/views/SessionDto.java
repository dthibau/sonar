package com.plb.plbsiapi.offre.resource.views;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.model.FormationPartenaire;
import com.plb.plbsiapi.offre.model.Session;
import com.plb.plbsiapi.offre.model.SessionLieu;

import lombok.Data;

@Data
public class SessionDto {
	
	@JsonView({FormationViews.List.class,FormationViews.Sessions.class})
	private LieuOrganisme lieuOrganisme;
	
	@JsonView({FormationViews.List.class,FormationViews.Sessions.class})
	private MonthSessionDto[] monthSessions = new MonthSessionDto[12];

	public SessionDto() {
		super();
	}
	public SessionDto(SessionLieu lieu, List<Session> sessions, int year) {
		_initArray();
		lieuOrganisme = new LieuOrganisme("PLB", lieu);
		alimentArray(sessions, year);
	}
	
	public SessionDto(SessionLieu lieu, FormationPartenaire fp, int year) {
		_initArray();
		lieuOrganisme = new LieuOrganisme(fp.getPartenaire().getNom(),lieu);
		alimentArray(fp.getSessions(), year);
	}
	
	private void _initArray() {
		for ( int i=0; i<monthSessions.length; i++) 
			monthSessions[i] = new MonthSessionDto();
	}
	private void alimentArray(List<Session> sessions, int year) {
		for ( Session session : sessions ) {
			if ( session.getYear() == year ) {
				monthSessions[session.getMonth()].getSessions().add(session);
			}
		}
	}

	

	public List<Session> getAllSessions() {
		List<Session> ret = new ArrayList<Session>();
		
		for ( int i=0; i<monthSessions.length; i++) {
			ret.addAll(monthSessions[i].getSessions());
		}
		
		return ret;
	}
	
	
	
}
