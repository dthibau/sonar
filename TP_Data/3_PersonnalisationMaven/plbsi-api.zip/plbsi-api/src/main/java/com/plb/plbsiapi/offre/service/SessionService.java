package com.plb.plbsiapi.offre.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.model.FormationPartenaire;
import com.plb.plbsiapi.offre.model.Session;
import com.plb.plbsiapi.offre.model.SessionLieu;
import com.plb.plbsiapi.offre.repository.SessionLieuRepository;
import com.plb.plbsiapi.offre.resource.views.SessionDto;

@Service
public class SessionService {

	
	@Autowired
	SearchService searchService;
	@Autowired 
	SessionLieuRepository sessionLieuRepository;
	
	
	@Transactional(readOnly=true)
	public List<SessionDto> getPlannedSessions(Integer idFormation, int year) {
	
		Formation formation = searchService.get(idFormation);
		
		List<SessionLieu> lieuxPLB = sessionLieuRepository.findPLB();
		
		// Formation PLB pour chaque lieu
		List<SessionDto> currentSessions = new ArrayList<SessionDto>();
		lieuxPLB.forEach(sessionLieu -> {
			currentSessions.add(new SessionDto(sessionLieu, formation.getSessionsPLB(sessionLieu),year));
		});

		
		// Pas de lieu géré pour les paertenaires ... pour l'instant
		for (FormationPartenaire fp : formation.getFormationsPartenaire()) {
			currentSessions.add(new SessionDto(null,fp, year));
		}

		return currentSessions;
	}
}
