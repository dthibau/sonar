/*
 * Decompiled with CFR 0.144.
 */
package com.plb.util;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Scanner;

public class FileUtils {
    private static FileUtils fileUtils = new FileUtils();

    public static String readClassPathResource(String resource) throws FileNotFoundException {
        StringBuilder result = new StringBuilder("");
        Scanner scanner = new Scanner(fileUtils.getClass().getResourceAsStream(resource));
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            result.append(line).append("\n");
        }
        scanner.close();
        return result.toString();
    }
}

