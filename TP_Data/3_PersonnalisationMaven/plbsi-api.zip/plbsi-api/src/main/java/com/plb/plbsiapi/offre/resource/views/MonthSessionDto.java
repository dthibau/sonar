package com.plb.plbsiapi.offre.resource.views;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.model.Session;

import lombok.Data;

@Data
public class MonthSessionDto {

	@JsonView({FormationViews.List.class, FormationViews.Sessions.class})
	private List<Session> sessions = new ArrayList<Session>();


	public void addSession(Session session) {
		sessions.add(session);
	}
	
}
