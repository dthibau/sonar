package com.plb.plbsiapi.offre.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.offre.model.Partenaire;
import com.plb.plbsiapi.offre.repository.PartenaireRepository;

@RestController
@RequestMapping(path = "/api/offre/partenaires")
public class PartenaireResource {

	@Autowired
	PartenaireRepository partenaireRepository;
	
	@GetMapping
	public List<Partenaire> findAll() {
		return partenaireRepository.findAll(Sort.by(Sort.Direction.ASC, "nom"));
	}
	
}
