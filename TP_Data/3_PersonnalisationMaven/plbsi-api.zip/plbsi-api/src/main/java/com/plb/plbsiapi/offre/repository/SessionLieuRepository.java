package com.plb.plbsiapi.offre.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.plb.plbsiapi.offre.model.Partenaire;
import com.plb.plbsiapi.offre.model.SessionLieu;

public interface SessionLieuRepository extends JpaRepository<SessionLieu, Long>{

	public List<SessionLieu> findByPartenaire(Partenaire partenaire);
	
	@Query("from SessionLieu s where s.partenaire is null")
	public List<SessionLieu> findPLB();
}
