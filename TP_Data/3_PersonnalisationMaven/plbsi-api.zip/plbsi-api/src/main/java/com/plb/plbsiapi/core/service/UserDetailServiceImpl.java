package com.plb.plbsiapi.core.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.model.PlbUser;
import com.plb.plbsiapi.core.repository.AccountRepository;

@Service
public class UserDetailServiceImpl implements UserDetailsService {

	@Autowired
	AccountRepository accountRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Account account = accountRepository.findByLogin(username).orElseThrow(() -> new UsernameNotFoundException("Invalid login")) ;
			
		Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
		String[] roles = account.getRoles().split(";");
        for (String role : roles ){
            grantedAuthorities.add(new SimpleGrantedAuthority(role));
        }
        return new PlbUser(account.getLogin(), "{noop}"+account.getPassword(), grantedAuthorities,account);

	}

}
