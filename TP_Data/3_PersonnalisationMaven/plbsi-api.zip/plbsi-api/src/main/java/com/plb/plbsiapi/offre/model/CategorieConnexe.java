package com.plb.plbsiapi.offre.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.resource.views.CategorieViews;

import lombok.Data;

@Entity
@Table(name="categorie_cat")
@Data
public class CategorieConnexe {

	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id_categorie_cat")
	@JsonView(CategorieViews.Detail.class)
	private int id;
	
	@ManyToOne
	@JoinColumn(name="id_categorie")
	private Categorie baseCategorie;
	
	@ManyToOne
	@JoinColumn(name="id_categorie_assoc")
	private Categorie linkedCategorie;
	
	@Column(name="`order`")
	private int order;

	@Transient
	@JsonView(CategorieViews.Detail.class)
	public long getLinkedId() {
		return linkedCategorie.getId();
	}
	
	public void setLinkedId(Integer linkedId) {
		linkedCategorie = new Categorie();
		linkedCategorie.setId(linkedId);
	}
	
	@Transient
	@JsonView(CategorieViews.Detail.class)
	public String getLinkedLibelle() {
		return linkedCategorie.getLibelle();
	}
	@Transient
	@JsonView(CategorieViews.Detail.class)
	public int getLinkedRang() {
		return linkedCategorie.getRang();
	}

}
