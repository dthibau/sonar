package com.plb.plbsiapi.elk;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix="elk")
@Component
public class ELKConfigurationProperties {

	private String scheme;
	private String host;
	private Integer port;
	private String login;
	private String password;
	private String trustStorePath;
	
	private Map<String,String> indexes = new HashMap();
//	private String roles;
	public String getScheme() {
		return scheme;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}
	public Map<String, String> getIndexes() {
		return indexes;
	}
	public void setIndexes(Map<String, String> indexes) {
		this.indexes = indexes;
	}
	public String getTrustStorePath() {
		return trustStorePath;
	}
	public void setTrustStorePath(String crt) {
		this.trustStorePath = crt;
	}
	
	
	
}
