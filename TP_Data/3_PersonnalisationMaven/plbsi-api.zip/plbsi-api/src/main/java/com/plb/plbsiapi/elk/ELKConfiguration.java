package com.plb.plbsiapi.elk;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestClientBuilder.HttpClientConfigCallback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ELKConfiguration {

	@Autowired
	ELKConfigurationProperties elkConfigurationProperties;

	@Bean
	public RestClient restClient() throws Exception {
		final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
		credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(
				elkConfigurationProperties.getLogin(), elkConfigurationProperties.getPassword()));
		RestClientBuilder builder;
		if (elkConfigurationProperties.getScheme().equals("https")) {
			final SSLContext sslContext = _getSSLContext();

			builder = RestClient
					.builder(new HttpHost(elkConfigurationProperties.getHost(), elkConfigurationProperties.getPort(),
							elkConfigurationProperties.getScheme()))
					.setHttpClientConfigCallback(new HttpClientConfigCallback() {
						@Override
						public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpClientBuilder) {
							return httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider)
									.setSSLContext(sslContext);
						}
					});
		} else {
			builder = RestClient
					.builder(new HttpHost(elkConfigurationProperties.getHost(), elkConfigurationProperties.getPort(),
							elkConfigurationProperties.getScheme()))
					.setHttpClientConfigCallback(new HttpClientConfigCallback() {
						@Override
						public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpClientBuilder) {
							return httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
						}
					});

		}
		return builder.build();
	}

	private SSLContext _getSSLContext() throws CertificateException, IOException, KeyStoreException,
			NoSuchAlgorithmException, KeyManagementException, URISyntaxException {

//		File trustStoreFile = new File(elkConfigurationProperties.getTrustStorePath());
////		Resource trustStoreResource = new DefaultResourceLoader().getResource("classpath:"+elkConfigurationProperties.getTrustStorePath());
//		
//		KeyStore truststore = KeyStore.getInstance("pkcs12");
//		try (InputStream is = new FileInputStream(trustStoreFile)) {
//			truststore.load(is, "9lM)[dfZ".toCharArray());
//		}

		// SSLContextBuilder sslBuilder = SSLContexts.custom().loadTrustMaterial(truststore, null);
		SSLContextBuilder sslBuilder = SSLContexts.custom().loadTrustMaterial(null, new TrustStrategy()
        {
            public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException
            {
                return true;
            }
        });
		
		
		return sslBuilder.build();

	}
}
