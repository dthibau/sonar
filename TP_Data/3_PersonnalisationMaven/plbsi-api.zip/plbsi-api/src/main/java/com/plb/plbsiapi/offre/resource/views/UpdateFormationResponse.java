package com.plb.plbsiapi.offre.resource.views;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.model.Formation;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UpdateFormationResponse {
	@JsonView({FormationViews.Detail.class,FormationViews.SmallList.class})
	private Formation formation;
	@JsonView({FormationViews.Detail.class,FormationViews.SmallList.class})
	private String message;
}
