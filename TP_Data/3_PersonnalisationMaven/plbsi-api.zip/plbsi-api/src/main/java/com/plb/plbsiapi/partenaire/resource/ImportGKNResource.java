package com.plb.plbsiapi.partenaire.resource;

import java.util.List;

import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.NotFoundException;
import com.plb.plbsiapi.partenaire.ImportResultDto;
import com.plb.plbsiapi.service.ImportGKNService;

import io.swagger.v3.oas.annotations.Operation;


@RestController
@RequestMapping("/api/import")
public class ImportGKNResource {

	@Autowired
	ImportGKNService importGKNService;
	

	
	@PutMapping(path="GKN")
	 @Operation(summary = "Met à jour les tarifs et sessions de GKN et GKN-Distant",
	    description = "Les données sont récupérées à partir des 2 URLs GKN")
	public List<ImportResultDto> importGKN() throws NotFoundException, JAXBException {
		
		// Update 
		return importGKNService.importGKN();
	}
	
	@PutMapping(path="recopyGKN-Distant")
	 @Operation(summary = "Copie les formations partenaires de GKN vers GKN-distant")
	public ImportResultDto copyGKNDistant() throws NotFoundException, JAXBException {
		
		
		// Update 
		return importGKNService.copyGKNDistant();
	}
	
	
}
