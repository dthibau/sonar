package com.plb.plbsiapi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.plb.plbsiapi.partenaire.gkn.GKNProperties;

@SpringBootApplication
@EnableConfigurationProperties(GKNProperties.class)
@EnableScheduling
@EnableAsync
public class PlbsiApiApplication {
	
	private static Logger log = LoggerFactory.getLogger(PlbsiApiApplication.class);


	public static void main(String[] args) {
		ApplicationContext context = (ApplicationContext)SpringApplication.run(PlbsiApiApplication.class, args);
		System.out.println("Hello world !");
		for ( String beanName : context.getBeanDefinitionNames() ) {
			if ( context.getBean(beanName).getClass().getName().startsWith("com.plb") ) {
				log.debug("Bean " + beanName + " of " + context.getBean(beanName).getClass());
			}
		}
	}
}
