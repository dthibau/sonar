package com.plb.plbsiapi.offre.event;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.model.Role;
import com.plb.plbsiapi.offre.model.Formation;

@Entity
@DiscriminatorValue("FormationModification")
public class FormationModificationEvent extends FormationEvent {


	public FormationModificationEvent(Account account, Formation formation, String message) {
		super(account,formation, message);
		if ( formation.getCurrentManager() != null ) {
			destinataires.add(formation.getCurrentManager());
		}
	}
	
	@Override
	public List<Role> getNotifiedRoles() {		
		return new ArrayList<Role>();
	}

	@Override
	public String getNotificationSubject() {
		return "Modification de la formation " + formation.getLibelle() + " : " + account.getNomComplet();
	}

	


	
}
