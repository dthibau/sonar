package com.plb.plbsiapi.backoffice.resource;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;

import com.plb.plbsiapi.backoffice.model.Url;
import com.plb.plbsiapi.backoffice.repository.UrlRepository;

@RestController
@RequestMapping(path="/api/backoffice/urls")
public class UrlResource {

	@Autowired
	UrlRepository urlRepository;
	
	@GetMapping
	public List<Url> getAll() {
		String myDate = "2019/01/01";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		try {
			Date fromDate = sdf.parse(myDate);
			return urlRepository.findByDateGreaterThan(fromDate, this.OrderByDateDesc());
		} catch (Exception e) {
			return null;
		}
	}
	
	private Sort OrderByDateDesc() {
		return Sort.by(Sort.Direction.DESC, "Date");
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
		urlRepository.deleteById(id);
		return ResponseEntity.ok().build();
	}
	
	@PostMapping
	public ResponseEntity<Object> createUrl(@RequestBody Url url) {
		Url savedUrl = urlRepository.save(url);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(savedUrl.getId()).toUri();

		return ResponseEntity.created(location).build();
	}
}
