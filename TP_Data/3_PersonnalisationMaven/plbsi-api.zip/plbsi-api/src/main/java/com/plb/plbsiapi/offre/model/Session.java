package com.plb.plbsiapi.offre.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.resource.views.FormationViews;

import lombok.Data;

@Entity
@Table(name = "formation_session")
@Data
public class Session implements Comparable<Session> {

	public static DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id_session")
	@JsonView({FormationViews.List.class, FormationViews.Sessions.class})
	private int id;
	@Column(name = "forsess_date_debut", columnDefinition="timestamp")
	@JsonView({FormationViews.List.class, FormationViews.Sessions.class})
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private LocalDate debut;
	@Column(name = "forsess_date_fin", columnDefinition="timestamp")
	@JsonView({FormationViews.List.class, FormationViews.Sessions.class})
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private LocalDate fin;
	@Column(name = "forsess_promotion", columnDefinition="smallint")
	private int promotion;

	@ManyToOne
	@JoinColumn(name = "id_formation")
	private Formation formation;
	
	/**
	 * sessionLieu == null => PLB/Levallois
	 */
	@ManyToOne(optional=true)
	@JoinColumn(name="session_lieu_id")
	@JsonView({FormationViews.List.class, FormationViews.Sessions.class})
	private SessionLieu sessionLieu;

	public Session() {

	}

	public Session(Formation formation) {
		this.formation = formation;
	}

	@Transient
	public int getYear() {
		return debut.getYear();		
	}

	@Transient
	public int getMonth() {
		return debut.getMonthValue()-1;
	}
	@Transient
	public int getDay() {
		return debut.getDayOfMonth();
	}
	@Transient
	public int getDayFin() {
		if ( fin != null ) {
			return fin.getDayOfMonth();
		}
		return -1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Session other = (Session) obj;
		if ( id == 0 && other.id == 00 ) {
			return getFormation().equals(other.getFormation()) && getDebut().equals(other.getDebut());
		}
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Du " + df.format(debut) + " au " + df.format(fin);
	}

	@Override
	public int compareTo(Session o) {
		return getDebut().compareTo(o.getDebut()) ;
	}

}
