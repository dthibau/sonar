package com.plb.plbsiapi.partenaire.gkn22.model;

import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name = "event")
@XmlAccessorType(XmlAccessType.FIELD)
public class GKN22Event {

	@XmlElement(name = "eventid")
	private String eventid;
	@XmlElement(name = "code")
	private String code; 
	@XmlElement(name = "locationcode")
	private Integer locationcode;
	@XmlElement(name = "location")
	private String location;
	@XmlElement(name = "startdate")
	@XmlJavaTypeAdapter(DateAdapter.class)
	private LocalDate startdate;
	@XmlElement(name = "duration")
	private Integer duration;
	@XmlElement(name = "modalitycode")
	private String modalitycode;
	@XmlElement(name = "modality")
	private String modality;
	
	
	public String getEventid() {
		return eventid;
	}
	public void setEventid(String eventid) {
		this.eventid = eventid;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Integer getLocationcode() {
		return locationcode;
	}
	public void setLocationcode(Integer locationcode) {
		this.locationcode = locationcode;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public LocalDate getStartdate() {
		return startdate;
	}
	public void setStartdate(LocalDate startdate) {
		this.startdate = startdate;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getModalitycode() {
		return modalitycode;
	}
	public void setModalitycode(String modalitycode) {
		this.modalitycode = modalitycode;
	}
	public String getModality() {
		return modality;
	}
	public void setModality(String modality) {
		this.modality = modality;
	}
	
	
}
