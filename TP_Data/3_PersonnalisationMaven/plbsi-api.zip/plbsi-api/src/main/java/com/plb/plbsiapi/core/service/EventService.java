package com.plb.plbsiapi.core.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.plb.plbsiapi.core.model.Event;
import com.plb.plbsiapi.core.repository.AccountRepository;
import com.plb.plbsiapi.core.repository.EventRepository;

@Service
public class EventService {

	@Autowired
	EventRepository eventRepository;
	
	@Autowired
	AccountRepository accountRepository;
	
	@Transactional
	public Event logEvent(Event event) {
		event.getNotifiedRoles().stream().forEach(r -> {
			accountRepository.findAllActive().stream()
			.filter(a -> a.getRoleList().contains(r))
			.forEach(a -> event.getDestinataires().add(a));
		});
		eventRepository.save(event);
		
		return event;
	}
}
