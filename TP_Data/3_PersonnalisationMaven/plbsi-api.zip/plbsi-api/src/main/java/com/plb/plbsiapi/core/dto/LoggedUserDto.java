package com.plb.plbsiapi.core.dto;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.Authentication;


public class LoggedUserDto {

	public String login;
	
	public LoggedUserDto(Authentication authentication) {
		login = authentication.getName();
		authorities = authentication.getAuthorities().stream().map(g -> g.toString()).collect(Collectors.toList());
	}
	public List<String> authorities;

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public List<String> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(List<String> authorities) {
		this.authorities = authorities;
	}
	
	
}
