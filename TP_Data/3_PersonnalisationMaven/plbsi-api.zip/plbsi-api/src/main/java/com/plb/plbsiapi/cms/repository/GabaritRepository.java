package com.plb.plbsiapi.cms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.plb.plbsiapi.cms.model.Gabarit;
import com.plb.plbsiapi.cms.model.Page;
import com.plb.plbsiapi.cms.model.Menu;

@Repository
public interface GabaritRepository extends JpaRepository<Gabarit, Long> {



}
