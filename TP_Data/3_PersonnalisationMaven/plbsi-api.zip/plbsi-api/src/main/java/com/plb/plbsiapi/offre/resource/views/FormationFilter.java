package com.plb.plbsiapi.offre.resource.views;

import com.plb.plbsiapi.offre.model.Categorie;
import com.plb.plbsiapi.offre.model.Filiere;
import com.plb.plbsiapi.offre.model.Partenaire;

import io.swagger.v3.oas.annotations.Hidden;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FormationFilter {

	public String q;
	public Boolean moreResult = null;
	public Integer filiereId = null;
	public Integer categorieId = null;
	public Boolean excluPLB = null;
	public Integer partenaireId= null;
	public Boolean archived = null;
	
	@Hidden
	public boolean isFullText() {
		return q != null && q.length() > 0;
	}
	@Hidden
	public boolean isFullyFullText() {
		return (q != null && q.length() > 0) && (filiereId == null && categorieId == null && excluPLB == null && partenaireId == null);
	}
	@Hidden
	public boolean isFullyFiliere() {
		return (filiereId != null || categorieId != null) && (excluPLB == null && partenaireId == null);
	}
	@Hidden
	public boolean hasPartenaire() {
		return ((excluPLB != null && excluPLB) || partenaireId != null);
	}
	@Hidden
	public boolean isFullyPartenaire() {
		return (excluPLB != null || partenaireId != null) && (filiereId == null && categorieId == null && q == null);
	}
	@Hidden
	public boolean isBlank() {
		return !isFullText() && filiereId == null && categorieId == null && excluPLB == null && partenaireId == null; 
	}
	@Hidden
	public boolean isExcluPLB() {
		return excluPLB != null && excluPLB; 
	}
	@Hidden
	public boolean isMoreResult() {
		return moreResult != null && moreResult; 
	}
	@Hidden
	public boolean isArchived() {
		return archived != null && archived; 
	}
	@Hidden
	public Filiere getFiliere() {
		if ( filiereId == null || categorieId != null)
			return null;
		Filiere ret = new Filiere();
		ret.setId(filiereId);
		return ret;
	}
	@Hidden
	public Categorie getCategorie() {
		if ( categorieId == null )
			return null;
		Categorie ret = new Categorie();
		ret.setId(categorieId);
		return ret;
	}
	@Hidden
	public Partenaire getPartenaire() {
		if ( (excluPLB != null && excluPLB) || partenaireId == null )
			return null;
		Partenaire ret = new Partenaire();
		ret.setId(partenaireId);
		return ret;
	}

}
