package com.plb.plbsiapi.offre.resource.views;

public class FiliereViews {
	public static class List {
    }
	
	public static class Detail extends List{};
}
