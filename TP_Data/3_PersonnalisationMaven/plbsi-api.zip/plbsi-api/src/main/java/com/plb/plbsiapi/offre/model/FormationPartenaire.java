package com.plb.plbsiapi.offre.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.resource.views.FormationViews;

import lombok.Data;

@Entity
@Table(name="formation_partenaire")
@Data
public class FormationPartenaire {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonView({FormationViews.List.class, FormationViews.Detail.class })
	private int id;
	
	@ManyToOne
	private Formation formation;
	@ManyToOne
	@JsonView({FormationViews.Detail.class })
	private Partenaire partenaire;
	@OneToMany(cascade=CascadeType.ALL,orphanRemoval=true)
	@JoinTable(name="formation_partenaire_formation_session")
	private List<Session> sessions=new ArrayList<Session>();
	
	@JsonView({FormationViews.Detail.class })
	private float prix;
	@JsonView({FormationViews.Detail.class })
	@Column(name="code")
	private String reference;
	@Column(columnDefinition="text")
	@JsonView({FormationViews.List.class, FormationViews.Detail.class })
	private String url;
	
	public FormationPartenaire() {
		
	}
	@Transient
	@JsonView({FormationViews.List.class})
	public String getNom() {
		return partenaire.getNom();
	}
	public FormationPartenaire(Formation formation) {
		this.formation = formation;
	}
	public FormationPartenaire getCopy() {
		FormationPartenaire newFP = new FormationPartenaire();
		newFP.setId(this.id);
		newFP.setFormation(this.formation);
		newFP.setPartenaire(this.partenaire);
		newFP.setReference(this.reference);
		newFP.setPrix(this.prix);
		newFP.setUrl(this.url);
		
		return newFP;
	}
	
	public void addSessions(List<Session> sessions) {
		this.sessions.addAll(sessions);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FormationPartenaire other = (FormationPartenaire) obj;
		if ( id == 0 ) { // En cours d'édition
			if ( partenaire != null && reference != null ) {
				return partenaire.equals(other.getPartenaire()) && reference.equals(other.getReference());
			} else 
				return false;
		} else if (id != other.id) // Persité en base
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "FormationPartenaire [id=" + id + ", formation=" + formation + ", partenaire=" + partenaire
				+ ", sessions=" + sessions + ", prix=" + prix + ", code=" + reference + ", url=" + url + "]";
	}
	
	public String logTarifString() {
		return "prix=" + prix;
	}
	
	public String logTarifSessionString() {
		return "prix=" + prix
				+ ", sessions=" + sessions.stream().filter(s -> s.getDebut().isAfter(LocalDate.now())).collect(Collectors.toList());
	}

	
	
	
}
