package com.plb.plbsiapi.partenaire.gkn.service;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.stereotype.Service;

import com.plb.plbsiapi.partenaire.gkn.GKNProperties;
import com.plb.plbsiapi.partenaire.gkn.model.GKNCourse;
import com.plb.plbsiapi.partenaire.gkn.model.GKNCourses;
import com.plb.plbsiapi.partenaire.gkn.model.GKNEvent;
import com.plb.plbsiapi.partenaire.gkn.model.GKNEvents;
import com.plb.plbsiapi.partenaire.gkn22.model.GKN22Course;
import com.plb.plbsiapi.partenaire.gkn22.model.GKN22Courses;
import com.plb.plbsiapi.partenaire.gkn22.model.GKN22Event;
import com.plb.plbsiapi.partenaire.gkn22.model.GKN22Events;

@Service
public class XMLService {

	
	private final GKNProperties gknProperties;
	
	public XMLService(GKNProperties gknProperties) {
		this.gknProperties = gknProperties;
	}

	public List<GKNEvent> parseEvents() throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(GKNEvents.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		GKNEvents events = (GKNEvents) unmarshaller.unmarshal(gknProperties.getSessionsURL());
		return events.getEvents();
	}
	public List<GKNEvent> parseEvents(File f) throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(GKNEvents.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		GKNEvents events = (GKNEvents) unmarshaller.unmarshal(f);
		return events.getEvents();
	}

	public List<GKNCourse> parseCourses() throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(GKNCourses.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		GKNCourses courses = (GKNCourses) unmarshaller.unmarshal(gknProperties.getTarifsURL());
		return courses.getCourses();
	}

	public List<GKNCourse> parseTarifs(File f) throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(GKNCourses.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		GKNCourses courses = (GKNCourses) unmarshaller.unmarshal(f);
		return courses.getCourses();
	}
	
	@Deprecated
	public List<GKN22Event> parseEvents22() throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(GKN22Events.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		GKN22Events events = (GKN22Events) unmarshaller.unmarshal(gknProperties.getSessions22URL());
		return events.getEvents();
	}
	@Deprecated
	public List<GKN22Event> parseEvents22(File f) throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(GKN22Events.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		GKN22Events events = (GKN22Events) unmarshaller.unmarshal(f);
		return events.getEvents();
	}
	@Deprecated
	public List<GKN22Course> parseCourses22() throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(GKN22Courses.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		GKN22Courses courses = (GKN22Courses) unmarshaller.unmarshal(gknProperties.getTarifs22URL());
		return courses.getCourses();
	}
	@Deprecated
	public List<GKN22Course> parseTarifs22(File f) throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(GKN22Courses.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		GKN22Courses courses = (GKN22Courses) unmarshaller.unmarshal(f);
		return courses.getCourses();
	}

}
