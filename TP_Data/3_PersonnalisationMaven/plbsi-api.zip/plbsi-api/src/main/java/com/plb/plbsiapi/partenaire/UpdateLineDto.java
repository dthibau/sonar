package com.plb.plbsiapi.partenaire;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UpdateLineDto {

	private String SEPARATOR = ";";

	private String reference;
	private float tarif;
	private int duree;
	private boolean valid;
	private List<LocalDate> sessions = new ArrayList<LocalDate>();

	private final static Logger log = LoggerFactory.getLogger(UpdateLineDto.class);

	public UpdateLineDto() {
		
	}
	
	public UpdateLineDto(String line, int year, int offset) {
		try {
			String[] fields = line.split(SEPARATOR);
			setReference(fields[0]);
			setTarif(Float.parseFloat(fields[1].replace(" ", "")));
			setDuree(Integer.parseInt(fields[2].replace(" ", "")));
			offset = offset - 3;
			for (int i = 3; i < fields.length; i++) {
				try {
					sessions.add(LocalDate.of(year, i + offset, Integer.parseInt(fields[i].trim())));
				} catch (NumberFormatException ex) {
				}
			}
			valid = true;
		} catch (Exception ex) {
			log.error(ex.toString());
			valid = false;
		}
		log.info("Update LineDto built : " + this);
	}

	public UpdateLineDto(String line) {
		try {
			String[] fields = line.split(SEPARATOR);
			setReference(fields[0]);
			setTarif(Float.parseFloat(fields[1].replace(" ", "")));
			valid = true;
		} catch (Exception ex) {
			log.error(ex.toString());
			valid = false;
		}
		log.info("Update LineDto built : " + this);
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public float getTarif() {
		return tarif;
	}

	public void setTarif(float tarif) {
		this.tarif = tarif;
	}

	public int getDuree() {
		return duree;
	}

	public void setDuree(int duree) {
		this.duree = duree;
	}

	public List<LocalDate> getSessions() {
		return sessions;
	}

	public void setSessions(List<LocalDate> sessions) {
		this.sessions = sessions;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}

	@Override
	public String toString() {
		return "UpdateLineDto [reference=" + reference + ", tarif=" + tarif + ", duree=" + duree + ", sessions="
				+ sessions + ", valid=" + valid + "]";
	}

}
