package com.plb.plbsiapi.partenaire.gkn;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.NotEmpty;

public class GKNPartenaire {

	@NotEmpty
	private String locations;

	@Deprecated
	private String locationCodes,modalityCodes;
	
	public String getLocations() {
		return locations;
	}

	public void setLocations(String locations) {
		this.locations = locations;
	}
	
	public List<String> getAllowedLocations() {
		return Arrays.asList(locations.split(",")).stream().collect(Collectors.toList());
	}
	
	@Deprecated
	public String getLocationCodes() {
		return locationCodes;
	}
	@Deprecated
	public void setLocationCodes(String locationCodes) {
		this.locationCodes = locationCodes;
	}
	@Deprecated
	public String getModalityCodes() {
		return modalityCodes;
	}
	@Deprecated
	public void setModalityCodes(String modalityCodes) {
		this.modalityCodes = modalityCodes;
	}

	

	@Deprecated
	public List<String> getAllowedModality() {
		return Arrays.asList(modalityCodes.split(","));
	}
	@Deprecated
	public List<Integer> getAllowedLocations22() {
		return Arrays.asList(locationCodes.split(",")).stream().map(s -> Integer.parseInt(s)).collect(Collectors.toList());
	}
}
