package com.plb.plbsiapi.elk.offre.service;

import java.io.IOException;
import java.nio.file.DirectoryIteratorException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.PatternSyntaxException;

import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.plb.plbsiapi.elk.ELKConfigurationProperties;
import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.repository.FormationRepository;

@Service
public class OffreService {
	private final Logger log = LoggerFactory.getLogger(OffreService.class);

	private InvendusResult invendusResult;
	
	@Autowired
	FormationRepository formationRepository;
	
	@Autowired
	ELKConfigurationProperties elkProperties;
	
	@Autowired
	RestClient restClient;
	
	public Optional<InvendusResult> getInvendusResult() {
		return Optional.ofNullable(invendusResult);
	}

	@Scheduled(cron="${plbsi.cron-invendus}")
	public void lookForInvendus() {
		log.info("Look for invendus starting ");
		
		LocalDate limit = LocalDate.now().minus(2, ChronoUnit.YEARS);
		
		List<Formation> formations = formationRepository.findUnarchivedBefore(Date.from(limit.atStartOfDay(ZoneId.systemDefault()).toInstant()));
		
		InvendusResult newInvendusResult = new InvendusResult();
		newInvendusResult.setLastLookUp(Instant.now());
		
		for ( Formation formation : formations ) {
			
			HttpEntity entity = new NStringEntity(_getQueryBody(formation.getReference(), limit),
					ContentType.APPLICATION_JSON);
			try {
				// Recherche des inscriptions
				Request searchRequest = new Request("GET", elkProperties.getIndexes().get("inscription") + "/_search/?size=0" );
				searchRequest.setEntity(entity);
				
				Response createResponse = restClient.performRequest(searchRequest);
				
				String resultString = EntityUtils.toString(createResponse.getEntity());
//				log.debug(resultString);
				if ( resultString.indexOf("\"value\":0") != -1 ) {
					log.debug("Adding " + formation.getReference() + " to invendus");
					newInvendusResult.addFormation(formation);
				}
				
				
			} catch (PatternSyntaxException | DirectoryIteratorException | IOException e) {
				System.err.println(e);
			}
		}
		
		invendusResult = newInvendusResult;
		
		log.info("Look for invendus found " + invendusResult.getTotal() + " invendus ");
	}
	
	private String _getQueryBody(String reference, LocalDate limit) {
		String ret = "{\n\"query\": {\n\"bool\": {\n\"filter\": [\n{\n\"term\": {\n\"codeproduit.keyword\": \"" + reference + "\"\n}" +
				"},\n{\n\"range\": {\n\"datedebutsession\": {\"gte\": \"" + limit.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "\"\n}\n}\n}\n]\n}\n}\n}";
//		log.debug("Query String is "+ret);
		return ret;
	}
}
