package com.plb.plbsiapi.offre.resource.views;

public class FormationViews {
	public static class SmallList {};
	
	public static class List extends SmallList{};
	
	public static class Detail {};
	
	public static class Sessions {};
}
