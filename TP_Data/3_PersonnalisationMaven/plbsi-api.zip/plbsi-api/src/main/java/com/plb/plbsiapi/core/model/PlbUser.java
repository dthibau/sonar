package com.plb.plbsiapi.core.model;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;


public class PlbUser extends User {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private final Account account;
	
	public PlbUser(String username, String password, Collection<? extends GrantedAuthority> authorities, Account account) {
		super(username, password, authorities);
		this.account = account; 
	}


	public Account getAccount() {
		return account;
	}


	
	
	
}
