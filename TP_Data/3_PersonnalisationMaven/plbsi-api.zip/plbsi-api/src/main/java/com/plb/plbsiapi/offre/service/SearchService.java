package com.plb.plbsiapi.offre.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;

import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.Query;
import org.hibernate.Hibernate;
import org.hibernate.search.SearchFactory;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.repository.FormationRepository;
import com.plb.plbsiapi.offre.resource.views.FormationFilter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class SearchService {

	private final FormationRepository formationRepository;
	private final EntityManager em;

	private class SearchField {
		private String name;
		private float boost;

		SearchField(String name, float boost) {
			this.name = name;
			this.boost = boost;
		}
	}

	SearchField[] fields = { new SearchField("reference", 4.0f), new SearchField("libelle", 3.0f),
			new SearchField("remarques", 3.0f), new SearchField("baliseKeyWords", 2.0f),
			new SearchField("motClePrimaire", 1.0f), new SearchField("origine", 1.0f),
			new SearchField("objectifs_operationnels", 1.0f), new SearchField("objectifs_pedagogiques", 1.0f) };

	SearchField[] optionnalFields = { new SearchField("precision", 1.0f), new SearchField("contenu", 1.0f) };
	

	@Transactional(readOnly = true)
	public Formation get(int idFormation) throws EntityNotFoundException {
		Formation ret = formationRepository.findById(idFormation).orElseThrow(() -> new EntityNotFoundException(""+idFormation));
		_initializeRelations(ret);
		
		return ret;
	}
	/**
	 * Recherche SQL 
	 * @param formationFilter
	 * @param pageable
	 * @return
	 */
	@Transactional(readOnly = true)
	public Page<Formation> search(FormationFilter formationFilter, Pageable pageable) {
		Page<Formation> ret = null;
		if ( formationFilter.isBlank() ) {
			ret = formationFilter.isArchived() ? formationRepository.findAllArchived(pageable) : formationRepository.findAllUnarchived(pageable);
		} else if ( formationFilter.isFullyFiliere() ) {
			pageable = _getPageableFilierePartenaire(pageable);
			
			ret = formationFilter.isArchived() ? formationRepository.findArchivedFormationsFiliere(formationFilter.getFiliere(),
					formationFilter.getCategorie(),  pageable ) : 
						formationRepository.findUnarchivedFormationsFiliere(formationFilter.getFiliere(),
					formationFilter.getCategorie(),  pageable );
		} else if ( formationFilter.isFullyPartenaire() ) {
			if ( formationFilter.isExcluPLB() ) {
				ret = formationFilter.isArchived() ? formationRepository.findArchivedExcluPLB(pageable) : formationRepository.findUnarchivedExcluPLB(pageable);
			} else {
				pageable = _getPageableFilierePartenaire(pageable);
				ret = formationFilter.isArchived() ? formationRepository.findArchivedFormationsPartenaire(formationFilter.getPartenaire(),pageable) :
													formationRepository.findUnarchivedFormationsPartenaire(formationFilter.getPartenaire(),pageable);				
			}
		} else { // Critère filière/catégorie + partenaire/exli
			pageable = _getPageableFilierePartenaire(pageable);
			if ( formationFilter.isExcluPLB() ) {
				ret = formationFilter.isArchived() ? formationRepository.findArchivedFormationsFiliereExcluPLB(formationFilter.getFiliere(),
						formationFilter.getCategorie(), pageable) : 
							formationRepository.findUnarchivedFormationsFiliereExcluPLB(formationFilter.getFiliere(),
									formationFilter.getCategorie(), pageable);	
			} else {
				ret = formationFilter.isArchived() ? formationRepository.findArchivedFormationsFilierePartenaire(formationFilter.getFiliere(),
						formationFilter.getCategorie(), formationFilter.getPartenaire(),pageable) : 
								formationRepository.findUnarchivedFormationsFilierePartenaire(formationFilter.getFiliere(),
						formationFilter.getCategorie(), formationFilter.getPartenaire(),pageable);	
			}
		}
		
		ret.forEach(f -> _initializeRelations(f));
		return ret;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Page<Formation> fullTextSearch(FormationFilter formationFilter, Pageable pageable) throws ParseException {

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(em);

		Query luceneQuery = getLuceneQuery(fullTextEntityManager, formationFilter.q, formationFilter.isMoreResult(), formationFilter.isArchived());
	
		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(luceneQuery, Formation.class);
		int total = -1;
		List<Formation> formations = null;
		if (!formationFilter.isFullyFullText() || !pageable.getSort().isEmpty()) {
			// Tri hors Lucene, on récupère tt, on trie, on pagine tt seul comme un grand !
			List<Formation> allFormations = fullTextQuery.getResultList();
			if ( !formationFilter.isFullyFullText() ) { // Need to filter
				allFormations = _filterResults(formationFilter, allFormations);
			}
			total = allFormations.size();
			if ((int) pageable.getOffset() > allFormations.size()) {
				formations = new ArrayList<Formation>();
			} else {
				if ( !pageable.getSort().isEmpty() ) {
					// Sort
					_sort(allFormations, pageable.getSort().toList().get(0));
				}
				// And now subList
				formations = allFormations.subList((int) pageable.getOffset(),
						(int) pageable.getOffset() + pageable.getPageSize() > allFormations.size() ? 
						allFormations.size()
						: (int) pageable.getOffset() + pageable.getPageSize());
			}
		} else {
			fullTextQuery.setMaxResults(pageable.getPageSize());
			fullTextQuery.setFirstResult((int) pageable.getOffset());
			formations = fullTextQuery.getResultList();
			total = fullTextQuery.getResultSize();
		}
		formations.stream().forEach(f -> _initializeRelations(f));
		return new PageImpl<Formation>(formations, pageable, total);

	}

	private Query getLuceneQuery(FullTextEntityManager fullTextEntityManager, String searchWord, boolean moreResults, boolean archive)
			throws ParseException {
		Query luceneQuery = null;

		SearchFactory searchFactory = fullTextEntityManager.getSearchFactory();
		QueryParser parser = new QueryParser("reference", searchFactory.getAnalyzer(Formation.class));
		searchWord = searchWord.replace(":", "").replace("^", "").replace("~", "").replace(" -", " ").replace("(", "")
				.replace(")", "").replace("{", "").replace("}", "");
		StringBuffer sbf = new StringBuffer();
		String[] tokens = searchWord.split(" ");
		boolean bFirst = true;
		for (String token : tokens) {
			if (_invalidToken(token))
				continue;
			if (!moreResults) { // In this case, we use AND
				if (bFirst) {
					bFirst = false;
				} else {
					sbf.append(" AND ");
				}
				sbf.append("+(");
			}
			for (SearchField field : fields) {
				sbf.append(field.name).append(":").append(token).append("^").append(field.boost).append(" ");
			}
			if (moreResults) {
				for (SearchField field : optionnalFields) {
					sbf.append(field.name).append(":").append(token).append("^").append(field.boost).append(" ");
				}
			}
			if (!moreResults) {
				sbf.append(")");
			}
		}
		
		if ( archive ) {
			sbf.append(" +(archive:true)");
		} else {
			sbf.append(" +(archive:false)");
		}

		luceneQuery = parser.parse(sbf.toString());
		
		log.debug("Lucene Query " + luceneQuery);
		return luceneQuery;
	}

	private boolean _invalidToken(String token) {
		if (token == null || token.isEmpty())
			return true;

		return false;
	}

	private Pageable _getPageableFilierePartenaire(Pageable pageable) {
		String property = pageable.getSort().get().findFirst().get().getProperty();
		Direction direction = pageable.getSort().get().findFirst().get().getDirection();
		
		return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(direction, "formation."+property));
		
	}
	
	private void _sort(List<Formation> toSort, Order order) {
		Comparator<Formation> comparator;

		if (order.getProperty().equalsIgnoreCase("libelle")) {
			comparator = Comparator.comparing(Formation::getLibelle);
		} else if (order.getProperty().equalsIgnoreCase("duree")) {
			comparator = Comparator.comparing(Formation::getDuree);
		} else if (order.getProperty().equalsIgnoreCase("tarif") || order.getProperty().equalsIgnoreCase("prix")) {
			comparator = Comparator.comparing(Formation::getPrix);
		} else if (order.getProperty().equalsIgnoreCase("categorie")
				|| order.getProperty().equalsIgnoreCase("categorieLibelle")) {
			comparator = Comparator.comparing(Formation::getCategorieLibelle);
		} else if (order.getProperty().equalsIgnoreCase("filiere")
				|| order.getProperty().equalsIgnoreCase("filiereLibelle")) {
			comparator = Comparator.comparing(Formation::getFiliereLibelle);
		} else {
			comparator = Comparator.comparing(Formation::getStatut);
		}
		if (order.isDescending()) {
			comparator = comparator.reversed();
		}

		toSort.sort(comparator);

	}


	private List<Formation> _filterResults(FormationFilter formationFilter, List<Formation> formations) {

		List<Formation> ret = new ArrayList<Formation>();

		for (Formation f : formations) {
//			if (formationFilter.getFiliere() != null && !f.containsFiliere(formationFilter.getFiliere())) {
//				continue;
//			}
//			if (formationFilter.getCategorie() != null && !f.containsCategorie(formationFilter.getCategorie())) {
//				continue;
//			}
			if (formationFilter.hasPartenaire()) {
				Hibernate.initialize(f.getFormationsPartenaire());

				if (formationFilter.getPartenaire() != null && !f.containsPartenaire(formationFilter.getPartenaire())) {
					continue;
				}
				if (formationFilter.isExcluPLB() && !f.isExcluPLB()) {
					continue;
				}
			}

			ret.add(f);
		}
		return ret;
	}
	
	private void _initializeRelations(Formation f) {
		Hibernate.initialize(f.getSessions());
		Hibernate.initialize(f.getFormationsPartenaire());
		f.getFormationsPartenaire().stream().forEach(fp -> {
			Hibernate.initialize(fp.getSessions());
		});
		if ( f.getFormationMutualisees() != null )
			Hibernate.initialize(f.getFormationMutualisees().getFormations());
		Hibernate.initialize(f.getFormationAssociees());
	}
}
