package com.plb.plbsiapi.core.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.resource.views.FormationViews;

import lombok.Data;

@Entity
@Table(name="account")
@Data
public class Account {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonView({FormationViews.List.class,FormationViews.Detail.class})
	private long id;
	@JsonView({FormationViews.List.class})
	private String email;
	@JsonView({FormationViews.List.class})
	private String login;
	private String password;
	@Column(name="role")
	@Access(AccessType.PROPERTY)
	private String roles;
	private String nom;
	private String prenom;
	private String telephone;
	@Temporal(TemporalType.DATE)
	@Column(name="deletedDate")
	private Date deletedDate;
	
	@Transient
	private List<Role> roleList;
	
	public void setRoles(String roleString) {
		this.roles = roleString;
		String[] arrayRoles = roleString.split(";");
		this.roleList = new ArrayList<Role>(arrayRoles.length);
		for ( String role : arrayRoles ) {
			roleList.add(Role.valueOf(role));
		}		
	}
	
	@Transient
	@JsonView({FormationViews.List.class, FormationViews.Detail.class})
	public String getNomComplet() {
		return getPrenom() + " " + getNom();
	}

	@Override
	public String toString() {
		return "Account [email=" + email + ", login=" + login + ", roles=" + roles + ", nom=" + nom + ", prenom="
				+ prenom + "]";
	}
		
}
