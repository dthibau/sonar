package com.plb.plbsiapi.offre.resource.views;

public class CategorieViews {
	public static class List {
    }
	
	public static class Detail extends List{};
}
