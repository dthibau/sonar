package com.plb.plbsiapi.core.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import lombok.Data;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "eventtype", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("Event")
@Table(name="event")
@Data
public abstract class Event {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Temporal(TemporalType.TIMESTAMP)
	protected Date date;
	
	@Lob
	protected String message;
	
	@ManyToOne
	protected Account account;
	
	@ManyToMany
	protected List<Account> destinataires = new ArrayList<Account>();
	
	public Event() {
		super();
	}
	
	public Event(Account account, String message) {
		date = new Date();
		this.account = account;
		this.message = message;
	}
	
	@Transient
	public abstract String getNotificationSubject();
	
	public abstract List<Role> getNotifiedRoles();
	
	public Map<String,Object> asNotificationMap() {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		HashMap<String, Object> model = new HashMap<>();
		model.put("prenom", account.getPrenom());
        model.put("account.nomComplet", account.getNomComplet());
        model.put("message", message);
        model.put("date", df.format(date));
        StringBuffer sbf = new StringBuffer();
        destinataires.stream().forEach(a -> {
        	if ( destinataires.indexOf(a) !=0 ) {
        		sbf.append(",");
        	} 
        	sbf.append(a.getNomComplet());
        });
        model.put("destinataires", sbf.toString());
        return model;
	}
	
	public String getMessageAsHTML() {
		return message.replace("\n", "<br/>");
	}
	@Transient 
	public boolean hasDestinataires() {
		return destinataires != null && destinataires.size() > 0;
	}
	@Transient 
	public String getHistoriqueKey() {
		return "historique." + this.getClass().getSimpleName();
	}
	@Transient 
	public String getNotificationKey() {
		return "notification." + this.getClass().getSimpleName();
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Event other = (Event) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Event [id=" + id + ", date=" + date + ", message=" + message
				+ ", account=" + account + ", destinataires=" + destinataires + "]";
	}

	
}
