package com.plb.plbsiapi.offre.resource.views;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.model.SessionLieu;

import lombok.Data;

@Data
public class LieuOrganisme {
	@JsonView({FormationViews.List.class, FormationViews.Sessions.class})
	String organisme;
	@JsonView({FormationViews.List.class, FormationViews.Sessions.class})
	SessionLieu sessionLieu;
	
	public LieuOrganisme(String organisme, SessionLieu sessionLieu) {
		super();
		this.organisme = organisme;
		this.sessionLieu = sessionLieu;
	}

	@Override
	public String toString() {
		String lieu = sessionLieu != null ? " (" + sessionLieu.getNom() + ")" : "";
		return organisme + lieu;
	}
	
	/**
	 * Compatibilité avec la v1 où le lieu n'est pas renseigné.
	 * @return
	 */
//	public SessionLieu getSessionLieu() {
//		if ( organisme.equals("PLB") && sessionLieu == null ) {
//			SessionLieu sessionLieu = new SessionLieu();
//			sessionLieu.setId(1l);
//			sessionLieu.setNom("Levallois");
//			return sessionLieu;
//		} else {
//			return this.sessionLieu;
//		}
//	}
}
