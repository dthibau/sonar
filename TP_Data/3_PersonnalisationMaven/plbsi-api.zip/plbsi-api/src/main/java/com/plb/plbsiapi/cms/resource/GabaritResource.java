package com.plb.plbsiapi.cms.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.cms.model.Gabarit;
import com.plb.plbsiapi.cms.repository.GabaritRepository;

@RestController
@RequestMapping(path="/api/cms/gabarits")
public class GabaritResource {

	@Autowired
	GabaritRepository gabaritRepository;
	
	@GetMapping
	public List<Gabarit> getAll() {
		return gabaritRepository.findAll();
	}
}
