package com.plb.plbsiapi.offre.event;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Transient;

import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.model.Role;
import com.plb.plbsiapi.offre.model.Formation;

@Entity
@DiscriminatorValue("FormationModificationSession")
public class FormationModificationSessionEvent extends FormationModificationEvent {

	@Transient
	private List<Role> notifiedRoles = new ArrayList<>();
	
	public FormationModificationSessionEvent(Account account, Formation formation, String message) {
		super(account, formation, message);
		if (account.getRoleList().contains(Role.COMMERCIAL) &&  !account.getRoleList().contains(Role.MANAGER)) {
			notifiedRoles.add(Role.MANAGER);
		}
	}
	@Override
	public List<Role> getNotifiedRoles() {		
		return notifiedRoles;
	}

	@Override
	public String getNotificationSubject() {
		return "Modification des sessions de la formation " + formation.getLibelle() + " : " + account.getNomComplet();
	}
}
