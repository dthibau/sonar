package com.plb.plbsiapi.core.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.plb.plbsiapi.core.model.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

	public Optional<Account> findByLogin(String login);
	
	@Query("select a from Account a where a.deletedDate is null")
	public List<Account> findAllActive();
	
	@Query("select a from Account a where a.deletedDate is not null")
	public List<Account> findAllUnActive();
	
}
