package com.plb.plbsiapi.offre.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Min;

import org.apache.lucene.analysis.charfilter.HTMLStripCharFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.annotations.Type;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.CharFilterDef;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TokenizerDef;
import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.elk.offre.resource.views.InvendusViews;
import com.plb.plbsiapi.offre.resource.views.FormationViews;
import com.plb.plbsiapi.offre.resource.views.LieuOrganisme;
import com.plb.plbsiapi.offre.resource.views.MinimalFormationDto;
import com.plb.plbsiapi.offre.resource.views.SessionDto;
import com.plb.plbsiapi.offre.resource.views.SessionOrganismeDto;
import com.plb.plbsiapi.offre.resource.views.SessionOrganismesDto;
import com.plb.util.HTMLUtils;

import lombok.Data;

@Entity
@Table(name = "formation")
@Indexed
@AnalyzerDef(name = "htmlAnalyzer", charFilters = {
		@CharFilterDef(factory = HTMLStripCharFilterFactory.class) }, tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class))
@Data
public class Formation implements Serializable, Comparable<Formation> {

	private static final long serialVersionUID = -211404718465836235L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "formationGenerator")
	@SequenceGenerator(name = "formationGenerator", sequenceName = "formation_id", initialValue = 700000, allocationSize = 1)
	@Column(name = "id_formation")
	@JsonView({ FormationViews.SmallList.class, FormationViews.Detail.class, InvendusViews.List.class })
	private Integer idFormation;

	@Column(name = "for_reference", columnDefinition = "text")
	@JsonView({ FormationViews.SmallList.class, FormationViews.Detail.class, InvendusViews.List.class })
	@Field
	private String reference;

	@Column(name = "for_libelle", columnDefinition = "text")
	@JsonView({ FormationViews.SmallList.class, FormationViews.Detail.class, InvendusViews.List.class })
	@Field
	private String libelle;

	@Column(name = "for_duree", columnDefinition = "decimal")
	@Min(value = 1)
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	private int duree;

	@Column(name = "for_prix", columnDefinition = "decimal")
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	private float prix;

	@Column(name = "remise", columnDefinition = "varchar(3)")
	@Length(max=3)
	@JsonView({ FormationViews.Detail.class })
	String remise = "";
	
	@Column(name = "for_origine", columnDefinition = "text")
	@Field
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class  })
	private String origine;

	@Column(columnDefinition = "bit")
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class  })
	private Boolean support;
	
	@JsonView({ FormationViews.Detail.class  })
	private String distance = "Non";

	@Column(name = "for_elearning", columnDefinition = "tinyint")
	@JsonView({ FormationViews.Detail.class  })
	private Boolean elearning;
	
	@Column(name = "for_niveau")
	@JsonView({ FormationViews.Detail.class  })
	private String niveau = "Fondamental";
	
	@Column(name = "for_eligible_cpf", columnDefinition = "tinyint")
	@JsonView({ FormationViews.Detail.class  })
	private Boolean eligibleCpf;

	@JsonView({ FormationViews.Detail.class  })
	private String codeCpf;
	
	@Lob
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class  })
	private String statut;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "archivedDate")
	private Date archivedDate;

	@Transient
	@Field(name = "archive", store = Store.NO, analyze = Analyze.NO)
	public boolean isArchived() {
		return archivedDate != null;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "for_date_creation")
	@JsonView({ InvendusViews.List.class })
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dateCreation;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "for_date_derniere_modif")
	@JsonView({ FormationViews.Detail.class })
	private Date dateModification;

	@Column(name = "for_url", columnDefinition = "text")
	@JsonView({ FormationViews.Detail.class })
	private String url;

	@Column(name = "for_toplibelle", columnDefinition = "text")
	@JsonView({ FormationViews.Detail.class })
	private String libelleTop10;

	@Column(name = "for_remarques", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	@Type(type="text")
	private String blocCommercialisation = "";

	@Column(name = "argumentaire", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	@Type(type="text")
	private String blocArgumentaire = "";

	@Column(name = "bloc_intra", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	@Type(type="text")
	private String blocIntra = "";
	
	@Column(name = "bloc_certification", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	@Type(type="text")
	private String blocCertification = "";
	
	@Column(name = "bloc_cpf", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	@Type(type="text")
	private String blocCpf = "";
	

	@Transient
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	public String getRemarques() {
		StringBuffer sbf = new StringBuffer();
		if ( blocCommercialisation != null && blocCommercialisation.length() > 0 ) {
			sbf.append("<b>Commercialisation</b><br/>");
			sbf.append(blocCommercialisation);
		}
		if ( blocIntra != null && blocIntra.length() > 0 ) {
			sbf.append("<b>Intra</b><br/>");
			sbf.append(blocIntra);
		}
		if ( blocArgumentaire != null && blocArgumentaire.length() > 0 ) {
			sbf.append("<b>Argumentaire</b><br/>");
			sbf.append(blocArgumentaire);
		}
		if ( blocCertification != null && blocCertification.length() > 0 ) {
			sbf.append("<b>Certification</b><br/>");
			sbf.append(blocCertification);
		}
		if ( blocCpf!= null && blocCpf.length() > 0 ) {
			sbf.append("<b>CPF</b><br/>");
			sbf.append(blocCpf);
		}
		return sbf.toString();
	}
	@Transient
	public String getShortRemarques() {
		if (blocCommercialisation != null) {
			return HTMLUtils.getData(blocCommercialisation);
//			String remarquesData = HTMLUtils.getData(remarques);
//			return remarquesData.length() < 50 ? remarquesData : remarquesData
//					.substring(0, 46) + " ...";
		}
		return null;
	}

	@Column(name = "for_precision_libelle", columnDefinition = "text")
	@Field
	@JsonView({ FormationViews.Detail.class })
	private String sousTitre;

	@Column(name = "for_visible", columnDefinition = "enum")
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	private String visible = "non";

	@Column(columnDefinition = "bit")
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	private Boolean plbInter;
	
	@Column(name="coursPlbCataloguePartenaire")
	@Length(max = 255)
	@JsonView({ FormationViews.Detail.class })
	private String coursPlbCataloguePartenaire;
	
	@Column(name = "for_type", columnDefinition = "text")
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	private String type;

	@Column(name = "for_mot_cle_primaire")
	@Field
	@Length(max = 50)
	@JsonView({ FormationViews.Detail.class })
	private String motClePrimaire;

	@Lob
	@Column(name = "for_balise_keywords", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	private String baliseKeywords;

	@Lob
	@Column(name = "for_balise_description", columnDefinition = "mediumtext")
	@JsonView({ FormationViews.Detail.class })
	private String baliseDescription;
	
	@Column(name = "for_balise_title", columnDefinition = "mediumtext")
	@JsonView({ FormationViews.Detail.class })
	private String baliseTitle;

	@Lob
	@JsonView({ FormationViews.Detail.class })
	private String campagneAdwords;
	
	@Lob
	@Column(columnDefinition = "mediumtext")
	@JsonView({ FormationViews.Detail.class })
	private String descriptif;
	
	@Lob
	@Column(name = "for_contenu", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	private String contenu;

	@Lob
	@Column(name = "for_objectifs_operationnels", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	private String objectifs_operationnels;

	@Lob
	@Column(name = "for_objectifs", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	private String objectifs_pedagogiques;

	@Lob
	@Column(name = "for_prerequis", columnDefinition = "mediumtext")
	@JsonView({ FormationViews.Detail.class })
	private String prerequis;

	@Lob
	@Column(name = "for_participants", columnDefinition = "mediumtext")
	@JsonView({ FormationViews.Detail.class })
	private String participants;
	
	@Lob
	@Column(name = "for_travaux_pratiques", columnDefinition = "mediumtext")
	@JsonView({ FormationViews.Detail.class })
	private String travauxPratiques;
	
	@Lob
	@Column(name = "for_description", columnDefinition = "mediumtext")
	@Field
	@JsonView({ FormationViews.Detail.class })
	private String description;
	
	@Lob
	@Column(name = "moyens_pedagogiques", columnDefinition = "longtext")
	@JsonView({ FormationViews.Detail.class })
	String moyensPedagogiques = "";

	@Lob
	@Column(name = "modalites_suivi", columnDefinition = "longtext")
	@JsonView({ FormationViews.Detail.class })
	String modalitesSuivi = "";
	
	@Column(name = "for_nouveaute", columnDefinition = "enum")
	@JsonView({ FormationViews.Detail.class })
	String nouveaute = "non";
	
	@Column(name = "for_top10", columnDefinition = "tinyint")
	@JsonView({ FormationViews.Detail.class })
	private Integer top10 = 0;
	
	@Column(name = "tar_code_intra", columnDefinition = "char")
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	String tarifIntra = "";

	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	private String certification;

	@Column(name = "for_cours_officiel")
	@JsonView({ FormationViews.Detail.class })
	private String coursOfficiel;
	
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	private Boolean actionCo;

	@ManyToOne
	@JoinColumn(name = "id_categorie")
	@JsonView({ FormationViews.Detail.class })
	private Categorie categorie;

	@OneToMany(mappedBy = "formation", fetch = FetchType.EAGER)
	@OrderBy("rang ASC")
	private List<FormationFiliere> formationFilieres = new ArrayList<FormationFiliere>();

	@ManyToMany
	@JoinTable(name = "formation_formation", joinColumns = { @JoinColumn(name = "id_formation_principale", referencedColumnName = "id_formation") }, inverseJoinColumns = { @JoinColumn(name = "id_formation_suivante", referencedColumnName = "id_formation") })
	private List<Formation> formationAssociees;
	
	@OneToMany(mappedBy = "formation", cascade = CascadeType.ALL, orphanRemoval = true)
	@OrderBy("debut")
	private List<Session> sessions = new ArrayList<Session>();

	@OneToMany(mappedBy = "formation", cascade = CascadeType.ALL, orphanRemoval = true)
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class  })
	private List<FormationPartenaire> formationsPartenaire = new ArrayList<FormationPartenaire>();

	@ManyToOne(optional = true)
	private FormationMutualisees formationMutualisees;

	@ManyToOne(optional = true)
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class })
	private Account currentManager;

	@Transient
	@JsonView({ FormationViews.Detail.class})
	public List<MinimalFormationDto> getAssociees() {
		List<MinimalFormationDto> ret = new ArrayList<MinimalFormationDto>();
		if (formationAssociees != null) {
			formationAssociees.stream().forEach(f -> ret.add(new MinimalFormationDto(f)));
		}
		return ret;
	}
	
	@Transient
	@JsonView({ FormationViews.List.class, FormationViews.Detail.class})
	public List<MinimalFormationDto> getMutualisees() {
		List<MinimalFormationDto> ret = new ArrayList<MinimalFormationDto>();
		if (formationMutualisees != null) {
			for (Formation f : formationMutualisees.getFormations()) {
				if (!f.equals(this)) {
					ret.add(new MinimalFormationDto(f));
				}
			}
		}
		return ret;
	}

	@Transient
	@JsonView({ FormationViews.List.class, InvendusViews.List.class })
	public String getCategorieLibelle() {
		return getCategorie() != null ? getCategorie().getLibelle() : "";
	}

	@Transient
	@JsonView({ FormationViews.List.class })
	public List<String> getAutresCategories() {

		List<String> ret = new ArrayList<>();
		getFormationFilieres().stream().filter(f -> !f.isPrincipale())
				.forEach(f -> ret.add(f.getCategorie().getLibelle()));

		return ret;
	}

	@Transient
	@JsonView({ FormationViews.Detail.class })
	public List<Categorie> getCategoriesSecondaires() {

		List<Categorie> ret = new ArrayList<>();
		getFormationFilieres().stream().filter(f -> !f.isPrincipale())
				.forEach(f -> ret.add(f.getCategorie()));

		return ret;
	}

	@Transient
	@JsonView({ FormationViews.List.class, InvendusViews.List.class })
	public String getFiliereLibelle() {
		return getFilierePrincipale() != null ? getFilierePrincipale().getLibelle() : "";

	}

	@Transient
	@JsonView({ FormationViews.List.class })
	public List<String> getAutresFilieres() {

		List<String> ret = new ArrayList<>();
		getFormationFilieres().stream().filter(f -> !f.isPrincipale()).forEach(f -> ret.add(f.getLibelle()));

		return ret;
	}

	@Transient
	@JsonView({ FormationViews.Detail.class })
	public String getUrlPlb() {
		if (getUrl() == null || getFilierePrincipale().getUrl() == null) {
			return null;
		}
		return "http://www.plb.fr/formation/" + getFilierePrincipale().getUrl() + "/" + getUrl() + ","
				+ getFilierePrincipale().getId() + "-" + getIdFormation() + ".php";
	}

	@Transient
	@JsonIgnore
	public Filiere getFilierePrincipale() {
		return getCategorie() != null ? getCategorie().getFiliere() : null;

	}

	@Transient
	public FormationFiliere getFormationFiliere(Categorie categorie) {
		for (FormationFiliere ff : formationFilieres) {
			if (ff.getCategorie().equals(categorie)) {
				return ff;
			}
		}
		return null;
	}
	
	@Transient
	public FormationFiliere getFormationFilierePrincipale() {
		return formationFilieres.stream().filter(ff -> ff.isPrincipale()).findFirst().orElseThrow(() -> new IllegalStateException("Formation sans catégorie " + this));

	}
	
	
	public void addFormationFiliere(FormationFiliere formationFiliere) {
		this.formationFilieres.add(formationFiliere);
		formationFiliere.setFormation(this);
	}
	public FormationFiliere addCategoriePrincipale(Categorie categorie) {
		FormationFiliere formationFiliere = new FormationFiliere();
		formationFiliere.setCategorie(categorie);
		formationFiliere.setFormation(this);
		formationFiliere.setIsPrincipale("oui");
		formationFiliere.setFiliere(categorie.getFiliere());
		addFormationFiliere(formationFiliere);
		
		return formationFiliere;

	}
	public FormationFiliere addCategorieSecondaire(Categorie categorie) {
		FormationFiliere formationFiliere = new FormationFiliere();
		formationFiliere.setCategorie(categorie);
		formationFiliere.setFormation(this);
		formationFiliere.setIsPrincipale("non");
		formationFiliere.setFiliere(categorie.getFiliere());
		addFormationFiliere(formationFiliere);
		
		return formationFiliere;

	}
	public void removeFormationFiliere(Categorie categorie) {
		
		this.formationFilieres.remove(getFormationFiliere(categorie));

	}
	
	@Transient
	public boolean containsFiliere(Filiere filiere) {
		for (FormationFiliere ff : formationFilieres) {
			if (ff.getFiliere().equals(filiere)) {
				return true;
			}
		}
		return false;
	}

	@Transient
	public boolean containsCategorie(Categorie categorie) {
		for (FormationFiliere ff : formationFilieres) {
			if (ff.getCategorie() != null && ff.getCategorie().equals(categorie)) {
				return true;
			}
		}
		return false;
	}

	@Transient
	public boolean containsPartenaire(Partenaire partenaire) {
		for (FormationPartenaire fp : formationsPartenaire) {
			if (fp.getPartenaire() != null && fp.getPartenaire().equals(partenaire)) {
				return true;
			}
		}
		return false;
	}

	@Transient
	public boolean isExcluPLB() {
		return formationsPartenaire.isEmpty();
	}

	/**
	 * Année en cours
	 * 
	 * @param month
	 * @return
	 */

	@Transient
	@JsonView({ FormationViews.List.class })
	public List<SessionOrganismesDto> getNextSessionsByOrganismes() {
		return _reduceSessions(getNextSessionsOrganismeDto());
	}


	@Transient
	private List<SessionOrganismeDto> getNextSessionsOrganismeDto() {
		List<SessionOrganismeDto> ret = new ArrayList<SessionOrganismeDto>();
		Map<SessionLieu,List<Session>> sessionsPLB = getSessionsPLB();
		for ( Entry<SessionLieu,List<Session>> entry : sessionsPLB.entrySet() ) {
			LieuOrganisme lieuOrganisme = new LieuOrganisme("PLB", entry.getKey());
			for (Session s : entry.getValue()) {
				if (s.getDebut().isAfter(LocalDate.now())) {
					ret.add(new SessionOrganismeDto(lieuOrganisme, s));
				}
			}
		}

		for (FormationPartenaire fp : getFormationsPartenaire()) {
			LieuOrganisme lieuOrganisme = new LieuOrganisme(fp.getPartenaire().getNom(), null);
			for (Session s : fp.getSessions()) {
				if (s.getDebut().isAfter(LocalDate.now())) {
					ret.add(new SessionOrganismeDto(lieuOrganisme, s));
				}
			}
		}
		Collections.sort(ret);
		return ret;

	}

//	@Transient
//	private List<SessionOrganismeDto> getAllSessionsOrganismeDto() {
//		List<SessionOrganismeDto> ret = new ArrayList<SessionOrganismeDto>();
//
//		Map<SessionLieu,List<Session>> sessionsPLB = getSessionsPLB();
//		for ( Entry<SessionLieu,List<Session>> entry : sessionsPLB.entrySet() ) {
//			LieuOrganisme lieuOrganisme = new LieuOrganisme("PLB", entry.getKey());
//			for (Session s : entry.getValue()) {
//				ret.add(new SessionOrganismeDto(lieuOrganisme, s));
//			}
//		}
//		for (FormationPartenaire fp : getFormationsPartenaire()) {
//			LieuOrganisme lieuOrganisme = new LieuOrganisme(fp.getPartenaire().getNom(), null);
//			for (Session s : fp.getSessions()) {
//				ret.add(new SessionOrganismeDto(lieuOrganisme, s));
//			}
//		}
//		Collections.sort(ret);
//		return ret;
//
//	}

	private List<SessionOrganismesDto> _reduceSessions(List<SessionOrganismeDto> sods) {
		List<SessionOrganismesDto> ret = new ArrayList<SessionOrganismesDto>();

		for (SessionOrganismeDto sod : sods) {
			boolean bTrouve = false;
			for (SessionOrganismesDto sosd : ret) {
				if (sosd.getDebut().equals(sod.getSession().getDebut())) {
					bTrouve = true;
					sosd.addLieuOrganisme(sod.getLieuOrganisme());
					break;
				}
			}
			if (!bTrouve) {
				SessionOrganismesDto sosd = new SessionOrganismesDto(sod.getSession().getDebut(),sod.getSession().getFin());
				sosd.addLieuOrganisme(sod.getLieuOrganisme());
				ret.add(sosd);
			}
		}
		return ret;
	}

	public List<SessionDto> getAllSessionsDto(int year) {

		List<SessionDto> currentSessions = new ArrayList<SessionDto>();
		Map<SessionLieu,List<Session>> sessionsPLB = getSessionsPLB();
		for ( Entry<SessionLieu,List<Session>> entry : sessionsPLB.entrySet() ) {
			currentSessions.add(new SessionDto(entry.getKey(), entry.getValue(),year));
		}
		
		
		for (FormationPartenaire fp : getFormationsPartenaire()) {
			currentSessions.add(new SessionDto(null,fp, year));
		}

		return currentSessions;
	}

	@JsonIgnore
	public Map<SessionLieu,List<Session>> getSessionsPLB() {
		Map<SessionLieu,List<Session>> ret = new HashMap<>();
		for (Session session : sessions) {
			boolean bTrouve = false;
			for (FormationPartenaire fp : formationsPartenaire) {
				if (fp.getSessions().contains(session)) {
					bTrouve = true;
					break;
				}
			}
			if (!bTrouve) {
				List<Session> list = ret.get(session.getSessionLieu());
				if ( list == null ) {
					list = new ArrayList<>();
					ret.put(session.getSessionLieu(), list);
				}
				list.add(session);
			}
		}
		return ret;
	}
	@JsonIgnore
	public List<Session> getSessionsPLB(LieuOrganisme lieuOrganisme) {
		return getSessionsPLB().get(lieuOrganisme.getSessionLieu()) != null ? getSessionsPLB().get(lieuOrganisme.getSessionLieu()) : new ArrayList<>();
	}
	@JsonIgnore
	public List<Session> getSessionsPLB(SessionLieu sessionLieu) {
		return getSessionsPLB().get(sessionLieu) != null ? getSessionsPLB().get(sessionLieu) : new ArrayList<>();
	}
	
	@JsonIgnore
	public Map<LieuOrganisme,List<Session>> getSessionsPartenaires() {
		Map<LieuOrganisme,List<Session>> ret = new HashMap<>();

		for (FormationPartenaire fp : formationsPartenaire) {
			ret.put(new LieuOrganisme(fp.getPartenaire().getNom(), null), fp.getSessions());
		}
			
		return ret;
	}

	@Override
	public String toString() {
		return "Formation [idFormation=" + idFormation + ", reference=" + reference + "]";
	}

	@Override
	public int compareTo(Formation o) {
		return getLibelle().compareTo(o.getLibelle());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Formation other = (Formation) obj;
		if (idFormation == null) {
			if (other.idFormation != null)
				return false;
		} else if (!idFormation.equals(other.idFormation))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		if ( idFormation == 0 ) {
			return super.hashCode();
		}
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idFormation == null) ? 0 : idFormation.hashCode());
		return result;
	}
	
}
