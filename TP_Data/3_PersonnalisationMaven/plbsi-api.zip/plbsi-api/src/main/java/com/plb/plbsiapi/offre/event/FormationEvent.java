package com.plb.plbsiapi.offre.event;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.model.Event;
import com.plb.plbsiapi.core.model.Role;
import com.plb.plbsiapi.offre.model.Formation;

import lombok.Data;

@Entity
@DiscriminatorValue("FormationEvent")
@Data
public abstract class FormationEvent extends Event {

	@ManyToOne
	protected Formation formation;

	public FormationEvent(Account account, Formation formation, String message) {
		super(account, message);
		this.formation = formation;
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public List<Role> getNotifiedRoles() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> asNotificationMap() {
		Map<String, Object> model = super.asNotificationMap();
		model.put("formation.libelle", formation.getLibelle());
		model.put("formation.url", formation.getUrlPlb());
		return model;
	}

}
