package com.plb.plbsiapi.core.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.core.dto.LoggedUserDto;
import com.plb.plbsiapi.core.service.CoreService;
import com.plb.plbsiapi.elk.offre.KibanaConfigurationProperties;

@RestController
@RequestMapping("/api")
public class LoggedUserResource {

	@Autowired
	KibanaConfigurationProperties kibanaProperties;
	
	@Autowired 
	CoreService coreService;
	
	@GetMapping(path="/kibana")
	public KibanaConfigurationProperties getKibana() {
		return kibanaProperties;
	}
	@GetMapping(path="/loggeduser")
	public LoggedUserDto getLoggedUser() {
		
		return coreService.getLoggedUser();
	}
}
