package com.plb.plbsiapi.core.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.core.dto.LoggedUserDto;
import com.plb.plbsiapi.core.service.CoreService;

@RestController
@RequestMapping("/api")
public class LoggedUserResource {

	
	@Autowired 
	CoreService coreService;
	

	@GetMapping(path="/loggeduser")
	public LoggedUserDto getLoggedUser() {
		
		return coreService.getLoggedUser();
	}
}
