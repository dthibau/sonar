package com.plb.plbsiapi.partenaire.gkn22.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="events")
public class GKN22Events {

	private List<GKN22Event> events;

	public List<GKN22Event> getEvents() {
		return events;
	}

	@XmlElement(name = "event")
	public void setEvents(List<GKN22Event> events) {
		this.events = events;
	}
	
	
}
