package com.plb.plbsiapi.partenaire.gkn.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="events")
public class GKNEvents {

	private List<GKNEvent> events;

	public List<GKNEvent> getEvents() {
		return events;
	}

	@XmlElement(name = "event")
	public void setEvents(List<GKNEvent> events) {
		this.events = events;
	}
	
	
}
