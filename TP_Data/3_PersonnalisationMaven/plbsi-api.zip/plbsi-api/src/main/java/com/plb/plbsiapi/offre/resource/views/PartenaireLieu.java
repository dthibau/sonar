package com.plb.plbsiapi.offre.resource.views;

import java.util.List;

import com.plb.plbsiapi.offre.model.Partenaire;
import com.plb.plbsiapi.offre.model.SessionLieu;

import lombok.Data;

@Data
public class PartenaireLieu {

	private Partenaire partenaire;
	private List<SessionLieu> lieux;
	
	public PartenaireLieu(List<SessionLieu> lieux) {
		super();
		this.lieux = lieux;
	}
	public PartenaireLieu(Partenaire partenaire, List<SessionLieu> lieux) {
		super();
		this.partenaire = partenaire;
		this.lieux = lieux;
	}
	
	
}
