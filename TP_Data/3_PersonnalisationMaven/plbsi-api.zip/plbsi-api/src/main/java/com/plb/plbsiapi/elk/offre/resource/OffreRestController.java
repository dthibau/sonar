package com.plb.plbsiapi.elk.offre.resource;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.elk.offre.KibanaConfigurationProperties;
import com.plb.plbsiapi.elk.offre.resource.views.InvendusViews;
import com.plb.plbsiapi.elk.offre.service.InvendusResult;
import com.plb.plbsiapi.elk.offre.service.OffreService;
import com.plb.plbsiapi.offre.resource.views.CategorieViews;

@RestController
@RequestMapping(path = "/api/offre")
public class OffreRestController {

	InvendusResult previousResult;
	
	@Autowired
	OffreService offreService;
	
	@GetMapping(path="/invendus")
	@JsonView(InvendusViews.List.class)
	public ResponseEntity<InvendusResult> getInvendus() {
		Optional<InvendusResult> result = offreService.getInvendusResult();
		if ( result.isPresent() ) {
			previousResult = result.get();
			return ResponseEntity.ok(previousResult);
		} else if ( previousResult != null ) { 
			return ResponseEntity.ok(previousResult);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}
}
