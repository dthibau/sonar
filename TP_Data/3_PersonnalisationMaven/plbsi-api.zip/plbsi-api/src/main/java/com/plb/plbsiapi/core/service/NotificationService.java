package com.plb.plbsiapi.core.service;

import java.io.FileNotFoundException;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.model.Event;
import com.plb.plbsiapi.core.repository.AccountRepository;
import com.plb.util.FileUtils;
import com.samskivert.mustache.Mustache;
import com.samskivert.mustache.Template;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NotificationService {

	private static final String TEMPLATE_BASE = "/mail/";
	private static final String MAIL_START = "mail-start.mustache";
	private static final String MAIL_END = "mail-end.mustache";

	@Autowired
	JavaMailSender javaMailSender;
	@Autowired
	private Mustache.Compiler mustacheCompiler;

	@Value("${plbsi.mail-enabled}")
	boolean mailEnabled;

	@Value("${server.ssl.enabled:false}")
	boolean sslEnabled;

	@Value("${plbsi.host}")
	String host;

	@Value("${server.port}")
	String port;

	@Autowired
	AccountRepository accountRepository;

	@Async
	public void notifyEvent(Event event) throws MailException, FileNotFoundException, MessagingException {

		if (mailEnabled) {
			for (Account destinataire : event.getDestinataires()) {
				try {
					this.javaMailSender.send(this.buildMail(destinataire, event));
					log.info("Notifications Sent to " + destinataire);
				} catch (Exception e) {
					log.info("Unable to send Notifications to " + destinataire);
				}
			}

		} else {
			log.info("Notification Not Sent, mail is disabled");
		}
	}

	@Async
	public void forceNotifyEvent(Event event) throws MailException, FileNotFoundException, MessagingException {

		for (Account destinataire : event.getDestinataires()) {
			this.javaMailSender.send(this.buildMail(destinataire, event));
		}
		log.info("Force Notifications Sent ");
	}

	public MimeMessage buildMail(Account destinataire, Event event) throws MessagingException, FileNotFoundException {
		log.info("Building mail for " + destinataire);

		MimeMessage message = this.javaMailSender.createMimeMessage();
		MimeMessageHelper helper = null;

		helper = new MimeMessageHelper(message, false, "UTF-8");
		message.setContent((Object) this.buildBody(destinataire, event), "text/html; charset=UTF-8");
		helper.setTo(destinataire.getEmail());
		helper.setSubject(event.getNotificationSubject());
		helper.setFrom("no-reply@plb.fr");

		return message;
	}

	private String buildBody(Account destinataire, Event event) throws FileNotFoundException {
		String result = null;
		String startHtml = FileUtils.readClassPathResource(TEMPLATE_BASE + MAIL_START);
		String custom = FileUtils.readClassPathResource(TEMPLATE_BASE + event.getClass().getSimpleName() + ".mustache");
		String endHtml = FileUtils.readClassPathResource(TEMPLATE_BASE + MAIL_END);
		Map<String, Object> map = event.asNotificationMap();
		StringBuffer sbf = new StringBuffer();
		sbf.append(sslEnabled ? "https://" : "http://");
		sbf.append(host);
		sbf.append(":" + port);
		map.put("server", sbf.toString());
		map.put("destinataire", destinataire.getNomComplet());
		Template template = this.mustacheCompiler.compile(startHtml + custom + endHtml);
		result = template.execute(map);

		return result;
	}

}
