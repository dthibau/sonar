package com.plb.plbsiapi.cms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.plb.plbsiapi.cms.model.Gabarit;
import com.plb.plbsiapi.cms.model.Page;
import com.plb.plbsiapi.cms.model.Menu;

@Repository
public interface PageRepository extends JpaRepository<Page, Long> {

	public List<Page> findByMenuOrderByRang(Menu menu);
	
	public List<Page> findByGabarit(Gabarit gabarit);
	
	public List<Page> findByGabaritAndMenuOrderByRang(Gabarit gabarit, Menu menu);
	
	public List<Page> findByParentPage(Page parentPage);


}
