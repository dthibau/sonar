package com.plb.plbsiapi.offre.service;

import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.plb.plbsiapi.core.repository.AccountRepository;
import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.model.FormationPartenaire;
import com.plb.plbsiapi.offre.model.Session;
import com.plb.plbsiapi.offre.resource.views.LieuOrganisme;
import com.plb.plbsiapi.offre.resource.views.SessionDto;
import com.plb.util.Util;

@Service
public class MergeFormationService {

	@Autowired
	AccountRepository accountRepository;
	
	public String mergeFormation(Formation oldFormation, Formation newFormation) {
		StringBuffer sbf = new StringBuffer();
		if (newFormation.getReference() != null && !newFormation.getReference().equals(oldFormation.getReference())) {
			sbf.append("Référence : " + Util.nullAsString(oldFormation.getReference()) + "->" + Util.nullAsString(newFormation.getReference()) + "<br/>");
			oldFormation.setReference(newFormation.getReference());
		}
		if (newFormation.getLibelle() != null && !newFormation.getLibelle().equals(oldFormation.getLibelle())) {
			sbf.append("Libellé : " + Util.nullAsString(oldFormation.getLibelle()) + "->" + Util.nullAsString(newFormation.getLibelle()) + "<br/>");
			oldFormation.setLibelle(newFormation.getLibelle());
		}
		if (newFormation.getVisible() != null && !newFormation.getVisible().equals(oldFormation.getVisible())) {
			sbf.append("Visible : " + Util.nullAsString(oldFormation.getVisible()) + "->" + Util.nullAsString(newFormation.getVisible()) + "<br/>");
			oldFormation.setVisible(newFormation.getVisible());
		}
		if (!Util.equalsWithNull(oldFormation.getSousTitre(), newFormation.getSousTitre())) {
			sbf.append("Sous-titre : " + Util.nullAsString(oldFormation.getSousTitre()) + "->" + Util.nullAsString(newFormation.getSousTitre()) + "<br/>");
			oldFormation.setSousTitre(newFormation.getSousTitre());
		}
		if ( newFormation.getDuree() != oldFormation.getDuree() ) {
			sbf.append("Durée : " + oldFormation.getDuree() + "->" + newFormation.getDuree() + "<br/>");
			oldFormation.setDuree(newFormation.getDuree());			
		}
		if ( newFormation.getPrix() != oldFormation.getPrix() ) {
			sbf.append("Tarif : " + oldFormation.getPrix() + "->" + newFormation.getPrix() + "<br/>");
			oldFormation.setPrix(newFormation.getPrix());			
		}
		if ( !Util.equalsWithNull(oldFormation.getRemise(),newFormation.getRemise()) ) {
			sbf.append("Remise : " + Util.nullAsString(oldFormation.getRemise()) + "->" + Util.nullAsString(newFormation.getRemise()) + "<br/>");
			oldFormation.setRemise(newFormation.getRemise());			
		}
		if ( !Util.equalsWithNull(oldFormation.getTarifIntra(),newFormation.getTarifIntra()) ) {
			sbf.append("Tarif intra : " + Util.nullAsString(oldFormation.getTarifIntra()) + "->" + Util.nullAsString(newFormation.getTarifIntra()) + "<br/>");
			oldFormation.setTarifIntra(newFormation.getTarifIntra());			
		}
		if ( !Util.equalsWithNull(oldFormation.getCoursPlbCataloguePartenaire(),newFormation.getCoursPlbCataloguePartenaire()) ) {
			sbf.append("Cours PLB catalogue partenaire : " + Util.nullAsString(oldFormation.getCoursPlbCataloguePartenaire()) + "->" + Util.nullAsString(newFormation.getCoursPlbCataloguePartenaire()) + "<br/>");
			oldFormation.setCoursPlbCataloguePartenaire(newFormation.getCoursPlbCataloguePartenaire());			
		}
		if ( !Util.equalsWithNull(oldFormation.getPlbInter(), newFormation.getPlbInter()) ) {
			sbf.append("Plb Inter : " + Util.nullAsString(oldFormation.getPlbInter()) + "->" + Util.nullAsString(newFormation.getPlbInter()) + "<br/>");
			oldFormation.setPlbInter(newFormation.getPlbInter());			
		}
		if ( !Util.equalsWithNull(oldFormation.getOrigine(), newFormation.getOrigine()) ) {
			sbf.append("Origine : " + Util.nullAsString(oldFormation.getOrigine()) + "->" + Util.nullAsString(newFormation.getOrigine()) + "<br/>");
			oldFormation.setOrigine(newFormation.getOrigine());			
		}
		if ( !Util.equalsWithNull(oldFormation.getSupport(), newFormation.getSupport()) ) {
			sbf.append("Support : " + Util.nullAsString(oldFormation.getSupport()) + "->" + Util.nullAsString(newFormation.getSupport()) + "<br/>");
			oldFormation.setSupport(newFormation.getSupport());			
		}
		if ( !Util.equalsWithNull(oldFormation.getDistance(), newFormation.getDistance()) ) {
			sbf.append("Distance : " + Util.nullAsString(oldFormation.getDistance()) + "->" + Util.nullAsString(newFormation.getDistance()) + "<br/>");
			oldFormation.setDistance(newFormation.getDistance());			
		}
		if ( !Util.equalsWithNull(oldFormation.getElearning(), newFormation.getElearning()) ) {
			sbf.append("E-learning : " + Util.nullAsString(oldFormation.getElearning()) + "->" + Util.nullAsString(newFormation.getElearning()) + "<br/>");
			oldFormation.setElearning(newFormation.getElearning());			
		}
		if ( !Util.equalsWithNull(oldFormation.getCertification(), newFormation.getCertification()) ) {
			sbf.append("Certification : " + Util.nullAsString(oldFormation.getCertification()) + "->" + Util.nullAsString(newFormation.getCertification()) + "<br/>");
			oldFormation.setCertification(newFormation.getCertification());			
		}
		if ( !Util.equalsWithNull(oldFormation.getCoursOfficiel(), newFormation.getCoursOfficiel()) ) {
			sbf.append("Cours officiel : " + Util.nullAsString(oldFormation.getCoursOfficiel()) + "->" + Util.nullAsString(newFormation.getCoursOfficiel()) + "<br/>");
			oldFormation.setCoursOfficiel(newFormation.getCoursOfficiel());			
		}
		if ( !Util.equalsWithNull(oldFormation.getNiveau(), newFormation.getNiveau()) ) {
			sbf.append("Niveau : " + Util.nullAsString(oldFormation.getNiveau()) + "->" + Util.nullAsString(newFormation.getNiveau()) + "<br/>");
			oldFormation.setNiveau(newFormation.getNiveau());			
		}
		if ( !Util.equalsWithNull(oldFormation.getEligibleCpf(), newFormation.getEligibleCpf()) ) {
			sbf.append("Eligible CPF : " + Util.nullAsString(oldFormation.getEligibleCpf()) + "->" + Util.nullAsString(newFormation.getEligibleCpf()) + "<br/>");
			oldFormation.setEligibleCpf(newFormation.getEligibleCpf());			
		}
		if ( !Util.equalsWithNull(oldFormation.getCodeCpf(), newFormation.getCodeCpf()) ) {
			sbf.append("Code CPF : " + Util.nullAsString(oldFormation.getCodeCpf()) + "->" + Util.nullAsString(newFormation.getCodeCpf()) + "<br/>");
			oldFormation.setCodeCpf(newFormation.getCodeCpf());			
		}
		if ( !Util.equalsWithNull(oldFormation.getMotClePrimaire(), newFormation.getMotClePrimaire()) ) {
//			sbf.append("Mot-clé primaire : " + Util.nullAsString(oldFormation.getMotClePrimaire()) + "->" + Util.nullAsString(newFormation.getMotClePrimaire()) + "<br/>");
			sbf.append("Mot-clé primaire modifié -> " + Util.nullAsString(newFormation.getMotClePrimaire()) + "<br/>");
			oldFormation.setMotClePrimaire(newFormation.getMotClePrimaire());			
		}
		if ( !Util.equalsWithNull(oldFormation.getUrl(), newFormation.getUrl()) ) {
			sbf.append("URL modifié ->" + Util.nullAsString(newFormation.getUrl()) + "<br/>");
			oldFormation.setUrl(newFormation.getUrl());			
		}
		if ( !Util.equalsWithNull(oldFormation.getBaliseKeywords(), newFormation.getBaliseKeywords()) ) {
			sbf.append("Balise Keywords modifié ->" + Util.nullAsString(newFormation.getBaliseKeywords()) + "<br/>");
			oldFormation.setBaliseKeywords(newFormation.getBaliseKeywords());			
		}
		if ( !Util.equalsWithNull(oldFormation.getBaliseDescription(), newFormation.getBaliseDescription()) ) {
			sbf.append("Balise Description modifié ->" + Util.nullAsString(newFormation.getBaliseDescription()) + "<br/>");
			oldFormation.setBaliseDescription(newFormation.getBaliseDescription());			
		}
		if ( !Util.equalsWithNull(oldFormation.getBaliseTitle(), newFormation.getBaliseTitle()) ) {
			sbf.append("Balise Title modifié ->" + Util.nullAsString(newFormation.getBaliseTitle()) + "<br/>");
			oldFormation.setBaliseTitle(newFormation.getBaliseTitle());			
		}
		if ( !Util.equalsWithNull(oldFormation.getCampagneAdwords(), newFormation.getCampagneAdwords()) ) {
			sbf.append("Campagne Adwords modifié ->" + Util.nullAsString(newFormation.getCampagneAdwords()) + "<br/>");
			oldFormation.setCampagneAdwords(newFormation.getCampagneAdwords());			
		}
		if ( !Util.equalsWithNull(oldFormation.getNouveaute(), newFormation.getNouveaute()) ) {
			sbf.append("Nouveauté : " + Util.nullAsString(oldFormation.getNouveaute()) + "->" + Util.nullAsString(newFormation.getNouveaute()) + "<br/>");
			oldFormation.setNouveaute(newFormation.getNouveaute());			
		}
		if ( !Util.equalsWithNull(oldFormation.getTop10(), newFormation.getTop10()) ) {
			sbf.append("Top10 : " + Util.nullAsString(oldFormation.getTop10()) + "->" + Util.nullAsString(newFormation.getTop10()) + "<br/>");
			oldFormation.setTop10(newFormation.getTop10());			
		}
		if ( !Util.equalsWithNull(oldFormation.getLibelleTop10(), newFormation.getLibelleTop10()) ) {
			sbf.append("Libellé Top10 : " + Util.nullAsString(oldFormation.getLibelleTop10()) + "->" + Util.nullAsString(newFormation.getLibelleTop10()) + "<br/>");
			oldFormation.setLibelleTop10(newFormation.getLibelleTop10());			
		}
		return sbf.toString();
	}

	public String mergeStatut(Formation oldFormation, Formation newFormation) {
		StringBuffer sbf = new StringBuffer();
		if (newFormation.getStatut() != null && !newFormation.getStatut().equals(oldFormation.getStatut())) {			
			sbf.append("Statut : " + Util.nullAsString(oldFormation.getStatut()) + "->" + Util.nullAsString(newFormation.getStatut()) + "<br/>");
			oldFormation.setStatut(newFormation.getStatut());
		}
		if (!Util.equalsWithNull(oldFormation.getCurrentManager(), newFormation.getCurrentManager())) {
			if (newFormation.getCurrentManager() != null)
				newFormation
						.setCurrentManager(accountRepository.findById(newFormation.getCurrentManager().getId()).get());
			sbf.append("Responsable offre : "
					+ (oldFormation.getCurrentManager() != null ? oldFormation.getCurrentManager().getNomComplet()
							: "Vide")
					+ "->"
					+ (newFormation.getCurrentManager() != null ? newFormation.getCurrentManager().getNomComplet()
							: "Vide")
					+ "<br/>");
			oldFormation.setCurrentManager(newFormation.getCurrentManager());
		}
		return sbf.toString();
	}

	public String mergeSessions(Formation formation, List<SessionDto> newSessions, int currentYear) {

		StringBuilder sb = new StringBuilder();
		for (SessionDto sessionDto : newSessions) {

			if (sessionDto.getLieuOrganisme().getOrganisme().equals("PLB")) {
				_mergeSessions(formation, sessionDto.getLieuOrganisme(), formation.getSessions(),
						formation.getSessionsPLB(sessionDto.getLieuOrganisme()), sessionDto.getAllSessions(),
						currentYear, sb);

			} else {
				for (FormationPartenaire fp : formation.getFormationsPartenaire()) {
					if (fp.getPartenaire().getNom().equals(sessionDto.getLieuOrganisme().getOrganisme())) {
						_mergeSessions(formation, sessionDto.getLieuOrganisme(), fp.getSessions(),
								fp.getSessions(), sessionDto.getAllSessions(), currentYear, sb);
						break;
					}
				}
			}
		}
		return sb.toString();

	}

	private void _mergeSessions(Formation formation, LieuOrganisme lieuOrganisme, List<Session> allSessions,
			List<Session> oldSessions, List<Session> newSessions, int currentYear, StringBuilder sb) {

		DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");

		// Ceux qui ont été supprimées
		List<Session> toRemove = new ArrayList<Session>();
		for (Session oldSession : oldSessions) {
			if (oldSession.getYear() == currentYear) {
				boolean bTrouve = false;
				for (Session newSession : newSessions) {
					if (newSession.getDebut().equals(oldSession.getDebut())
							&& newSession.getFin().equals(oldSession.getFin())) {
						bTrouve = true;
						break;
					}
				}
				if (!bTrouve) {
					toRemove.add(oldSession);
				}
			}
		}
		for (Session session : toRemove) {
			allSessions.remove(session);
			if (formation.getSessions().contains(session)) {
				formation.getSessions().remove(session);
			}
			sb.append("Session " + lieuOrganisme + " du " + session.getDebut().format(df) + " au "
					+ session.getFin().format(df) + " " + "supprimée <br/>\n");
		}

		// Ceux qui ont été ajoutées
		for (Session newSession : newSessions) {
			boolean bTrouve = false;
			for (Session oldSession : oldSessions) {
				if (oldSession.getYear() == currentYear) {
					if (newSession.getDebut().equals(oldSession.getDebut())) {
						bTrouve = true;
						break;
					}
				}
			}
			if (!bTrouve) {
				newSession.setFormation(formation);
				newSession.setSessionLieu(lieuOrganisme.getSessionLieu());
				if (newSession.getFin() == null) {
					newSession.setFin(newSession.getDebut().plus(formation.getDuree(), ChronoUnit.DAYS));
				}
				allSessions.add(newSession);
				if (!formation.getSessions().contains(newSession)) {
					formation.getSessions().add(newSession);
				}
				sb.append("Session " + lieuOrganisme + " du " + df.format(newSession.getDebut()) + " au "
						+ df.format(newSession.getFin()) + " " + "ajoutée <br/>\n");
			}
		}
	}

}
