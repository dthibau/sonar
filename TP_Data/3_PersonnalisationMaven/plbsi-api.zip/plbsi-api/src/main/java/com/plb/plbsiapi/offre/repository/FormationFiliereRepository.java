package com.plb.plbsiapi.offre.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.plb.plbsiapi.offre.model.Categorie;
import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.model.FormationFiliere;

public interface FormationFiliereRepository extends JpaRepository<FormationFiliere, Long> {

	public Optional<FormationFiliere> findByFormationAndCategorie(Formation formation, Categorie categorie);
}
