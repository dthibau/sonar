package com.plb.plbsiapi.partenaire.gkn;

import java.net.URL;
import java.util.Map;

import javax.validation.constraints.NotNull;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@ConfigurationProperties(prefix="gkn")
@Validated
public class GKNProperties {

	@NotNull
	private URL sessionsURL;
	@NotNull
	private URL tarifsURL;
	
	private URL sessions22URL;
	private URL tarifs22URL;
	
	private Map<String, GKNPartenaire> partenaires;
	
	public Map<String, GKNPartenaire> getPartenaires() {
		return partenaires;
	}
	public void setPartenaires(Map<String, GKNPartenaire> partenaires) {
		this.partenaires = partenaires;
	}
	public URL getSessionsURL() {
		return sessionsURL;
	}
	public void setSessionsURL(URL sessionsURL) {
		this.sessionsURL = sessionsURL;
	}
	public URL getTarifsURL() {
		return tarifsURL;
	}
	public void setTarifsURL(URL tarifsURL) {
		this.tarifsURL = tarifsURL;
	}
	public URL getSessions22URL() {
		return sessions22URL;
	}
	public void setSessions22URL(URL sessionsURL) {
		this.sessions22URL = sessionsURL;
	}
	public URL getTarifs22URL() {
		return tarifs22URL;
	}
	public void setTarifs22URL(URL tarifsURL) {
		this.tarifs22URL = tarifsURL;
	}
	
	
}
