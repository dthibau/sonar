package com.plb.plbsiapi.elk.resource;

import java.io.IOException;
import java.nio.file.DirectoryIteratorException;
import java.util.List;
import java.util.Optional;
import java.util.regex.PatternSyntaxException;

import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.ResponseException;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.repository.AccountRepository;
import com.plb.plbsiapi.elk.ELKConfigurationProperties;
import com.plb.plbsiapi.elk.offre.resource.views.InvendusViews;
import com.plb.plbsiapi.elk.offre.service.InvendusResult;
import com.plb.plbsiapi.elk.offre.service.OffreService;

import io.swagger.v3.oas.annotations.Operation;

/**
 * Interact with ELK server
 * @author dthibau
 *
 */
@RestController
@RequestMapping(path="/elk")
public class ELKResource {
	private final Logger log = LoggerFactory.getLogger(ELKResource.class);

	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	RestClient restClient;
	
	@Autowired
	OffreService offreService;
	
	
	@Autowired
	ELKConfigurationProperties elkConfigurationProperties;
		
	@GetMapping("/users")
	public ResponseEntity<String> getUser() {
		Response ret = null;

		try {
			// Mise à jour des comptes utilisateurs
			Request getRequest = new Request("GET", "/_security/user/");
			try {
			ret = restClient.performRequest(getRequest);
			log.info(ret.toString());
			} catch (ResponseException e) {
				log.warn(e.toString());
			}

			
		} catch (PatternSyntaxException | DirectoryIteratorException | IOException e) {
			System.err.println(e);
		}
		return new ResponseEntity<String>(ret.toString(),HttpStatus.OK);

	}
	@PostMapping("/synchronise")
	@Operation(summary = "Synchronise les utilisateurs plbsi avec les utilisateurs ELK",
    description = "Les rôles MANAGER deviennent plb_offre, les rôles TB_MANAGER deviennent plb_tb et les autres sont 'kibana_dashboard_only_user'. Un utilisateur désactivé de plbsi est supprimé dans ELK")
	public ResponseEntity<Void> synchronize() {
		
		List<Account> accounts = this.accountRepository.findAllUnActive();
		for ( Account account : accounts ) {
			_deleteUser(account);
		}
		accounts = this.accountRepository.findAllActive();

		for ( Account account : accounts ) {
			String role ="kibana_dashboard_only_user";
			if ( account.getRoles().contains("TB_MANAGER") ) {
				role = "plb_tb";
			} else if ( account.getRoles().contains("MANAGER") ) {
				role = "plb_offre";
			}
			
			_updateUser(account,role);
			
			
		}
		
		return ResponseEntity.accepted().build();
	}
	
	@PostMapping("/invendus")
	@Operation(summary = "Recherche les invendus dans l'index Offre")
	@JsonView(InvendusViews.List.class)
	public Optional<InvendusResult> invendus() {
		
		offreService.lookForInvendus();
		return offreService.getInvendusResult();
	}
	private void _deleteUser(Account account) {
		try {
			// Mise à jour des comptes utilisateurs
			Request deleteRequest = new Request("DELETE", "/_security/user/" + account.getLogin());
			try {
			Response deleteResponse = restClient.performRequest(deleteRequest);
			log.info(deleteResponse.toString());
			} catch (ResponseException e) {
				log.debug("Account:" +account + " " + e.toString());
			}
			
		} catch (PatternSyntaxException | DirectoryIteratorException | IOException e) {
			System.err.println(e);
		}
		
	}
	private void _updateUser(Account account, String role) {
		String jsonString = "{\n" + "    \"password\" : \"" + account.getPassword() + "\",\n" +
		          "    \"full_name\" : \"" + account.getNomComplet() + "\",\n" + 
                "    \"email\" : \"" + account.getEmail() + "\",\n" + 
		          "    \"roles\" : [\"" + role +"\"]\n}";

		HttpEntity entity = new NStringEntity(jsonString,
				ContentType.APPLICATION_JSON);
		log.info(entity.toString());
		try {
			// Mise à jour des comptes utilisateurs
			Request deleteRequest = new Request("DELETE", "/_security/user/" + account.getLogin());
			try {
			Response deleteResponse = restClient.performRequest(deleteRequest);
			log.info(deleteResponse.toString());
			} catch (ResponseException e) {
				log.warn(e.toString());
			}

			Request createRequest = new Request("POST", "/_security/user/" + account.getLogin());
			createRequest.setEntity(entity);
			Response createResponse = restClient.performRequest(createRequest);
			log.info(EntityUtils.toString(createResponse.getEntity()));
			
		} catch (PatternSyntaxException | DirectoryIteratorException | IOException e) {
			System.err.println(e);
		}
	}
}
