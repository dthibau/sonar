package com.plb.plbsiapi.backoffice.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.plb.plbsiapi.backoffice.model.Url;

@Repository
public interface UrlRepository extends JpaRepository<Url, Long> {
	List<Url> findByDateGreaterThan(Date date, Sort sort);
}
