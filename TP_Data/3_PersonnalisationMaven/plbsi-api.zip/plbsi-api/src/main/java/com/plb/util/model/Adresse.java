package com.plb.util.model;

import javax.persistence.Embeddable;

import lombok.Data;

@Embeddable
@Data
public class Adresse {

	private String numero;
	private String rue;
	private String ville;
	private Integer codePostal;
}
