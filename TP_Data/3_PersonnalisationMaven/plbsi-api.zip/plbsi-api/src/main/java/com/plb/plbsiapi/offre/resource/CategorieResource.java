package com.plb.plbsiapi.offre.resource;

import java.util.List;

import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.model.Categorie;
import com.plb.plbsiapi.offre.model.CategorieConnexe;
import com.plb.plbsiapi.offre.repository.CategorieConnexeRepository;
import com.plb.plbsiapi.offre.repository.CategorieRepository;
import com.plb.plbsiapi.offre.resource.views.CategorieViews;

@RestController
@RequestMapping(path = "/api/offre/categories")
public class CategorieResource {

	@Autowired
	CategorieRepository categoryRepository;
	
	@Autowired
	CategorieConnexeRepository categoryConnexeRepository;
	
	
	@GetMapping
	@JsonView(CategorieViews.List.class)
	public List<Categorie> findAll() {
		return categoryRepository.findAll(Sort.by(Sort.Direction.ASC, "libelle"));
	}
	
	@GetMapping(path="/filiere/{id}")
	@JsonView(CategorieViews.List.class)
	public List<Categorie> findByFiliere(@PathVariable("id") Integer filiereId) {
		return categoryRepository.findByFiliereId(filiereId);
	}
	
	@GetMapping(path="/{id}")
	@JsonView(CategorieViews.Detail.class)
	public Categorie findOne(@PathVariable("id") Integer id) {
		return categoryRepository.fullLoad(id).orElseThrow(() -> new EntityNotFoundException("No such category "+id));
	}
	
	@GetMapping(path="/connexes/{id}")
	@JsonView(CategorieViews.Detail.class)
	public List<CategorieConnexe> findConnexes(@PathVariable("id") Integer id) {
		return categoryRepository.getCategorieConnexes(id);
	}


	@GetMapping(path="/referentes/{id}")
	@JsonView(CategorieViews.List.class)
	public List<Categorie> findReferentes(@PathVariable("id") Integer id) {
		return categoryRepository.getCategorieReferentes(id);
	}
	
	@PutMapping(path="/referentes/{id}")
	@JsonView(CategorieViews.List.class)
	public List<Categorie> updateReferentes(@PathVariable("id") Integer id, @RequestBody List<Categorie> referentes) {
		
		categoryConnexeRepository.findCategoriesReferentes(id).stream().forEach(cc -> categoryConnexeRepository.delete(cc));
		
		referentes.stream().forEach(c -> {
			int lastOrder = categoryConnexeRepository.findLastOrder(c.getId()).orElse(0);
			CategorieConnexe cc = new CategorieConnexe();
			cc.setLinkedId(id);
			cc.setBaseCategorie(c);
			cc.setOrder(lastOrder+1);
			categoryConnexeRepository.save(cc);
		});
		return categoryRepository.getCategorieReferentes(id);
	}
	

	@PostMapping
	@JsonView(CategorieViews.Detail.class)
	public ResponseEntity<Categorie> createCategorie(@Valid @RequestBody Categorie category) {
		int i=0;
		for ( CategorieConnexe cc : category.getCategoriesConnexes() ) {
			cc.setBaseCategorie(category);
			cc.setOrder(i++);
		}
		Categorie c = categoryRepository.save(category);	
		Categorie ret = categoryRepository.fullLoad(c.getId()).orElseThrow(() -> new EntityNotFoundException("No such category "+c.getId())); 

		return new ResponseEntity<Categorie>(ret, HttpStatus.CREATED);
	}
	
	@PutMapping
	@JsonView(CategorieViews.Detail.class)
	public ResponseEntity<Categorie> updateCategorie(@Valid @RequestBody Categorie categorieToSave) {
		Categorie original = categoryRepository.fullLoad(categorieToSave.getId()).orElseThrow(() -> new EntityNotFoundException("No such category "+categorieToSave.getId())); 
		for ( CategorieConnexe cc : original.getCategoriesConnexes() ) {
			categoryConnexeRepository.delete(cc);
		}
		
		int i=0;
		for ( CategorieConnexe cc : categorieToSave.getCategoriesConnexes() ) {
			cc.setBaseCategorie(categorieToSave);
			cc.setOrder(i++);
		}
		categoryRepository.save(categorieToSave);	
		
		Categorie ret = categoryRepository.fullLoad(categorieToSave.getId()).orElseThrow(() -> new EntityNotFoundException("No such category "+categorieToSave.getId()));
		
		return new ResponseEntity<Categorie>(ret, HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping(path="/{id}")
	public ResponseEntity<Void> deleteCategorie(@PathVariable("id") Integer id) {
		
		Categorie cat = categoryRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("No such category "+id));
		/* @TODO : Enlever le lien des formations archivées
		List<Formation> archivedFormations = new FormationDao(entityManager).findArchivedByCategorie(categorie);
		for ( Formation formation : archivedFormations ) {
			formation.setCategorie(null);
		}*/
		categoryConnexeRepository.findCategoriesReferentes(id).stream().forEach(cc -> categoryConnexeRepository.delete(cc));

		categoryRepository.delete(cat);

		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}

}
