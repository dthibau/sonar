package com.plb.plbsiapi.core.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.plb.plbsiapi.core.dto.LoggedUserDto;
import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.model.PlbUser;
import com.plb.plbsiapi.core.repository.AccountRepository;

@Service
public class CoreService {

	@Autowired
	AccountRepository accountRepository;

	public LoggedUserDto getLoggedUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		return new LoggedUserDto(authentication);
	}

	public Account getLoggedAccount() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		return ((PlbUser)authentication.getPrincipal()).getAccount();
	}


}
