package com.plb.plbsiapi.offre.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.elk.offre.resource.views.InvendusViews;
import com.plb.plbsiapi.offre.resource.views.CategorieViews;
import com.plb.plbsiapi.offre.resource.views.FiliereViews;
import com.plb.plbsiapi.offre.resource.views.FormationViews;

import lombok.Data;

@Entity
@Table(name="categorie")
@Data
public class Categorie {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "categorieGenerator")
	@SequenceGenerator(name = "categorieGenerator", sequenceName = "CATEGORIE_ID", initialValue = 1500000, allocationSize = 1)
	@Column(name="id_categorie")
	@JsonView({CategorieViews.List.class,FiliereViews.Detail.class,FormationViews.Detail.class, InvendusViews.List.class})
	private int id;
	
	@Column(name="cat_libelle")
	@JsonView({CategorieViews.List.class,FiliereViews.Detail.class,FormationViews.Detail.class,InvendusViews.List.class})
	private String libelle;
	
	@ManyToOne
	@JoinColumn(name="id_filiere_principale")
	@JsonView({CategorieViews.List.class,FormationViews.Detail.class})
//	@JsonBackReference(value="filiere_categorie")
	Filiere filiere;

	@Column(name="cat_rang")
	@JsonView({CategorieViews.List.class,FiliereViews.Detail.class})
	private int rang;
	
	@Column(name="cat_url")
	@JsonView(CategorieViews.List.class)
	private String url;
	// Web
	@Lob
	@Column(name="cat_description", columnDefinition="text")
	@JsonView(CategorieViews.Detail.class)
	private String description;
	
	@Column(name="cat_balise_title")
	@JsonView(CategorieViews.Detail.class)
	private String metaTitre;
	
	@Column(name="cat_balise_description", columnDefinition="text")
	@JsonView(CategorieViews.Detail.class)
	private String metaDescription;
	
	@Column(name="cat_balise_keywords", columnDefinition="text")
	@JsonView(CategorieViews.Detail.class)
	private String metaKeywords;
	

	@OneToMany(cascade=CascadeType.ALL, mappedBy="baseCategorie")
	@JsonView(CategorieViews.Detail.class)
	List<CategorieConnexe> categoriesConnexes = new ArrayList<CategorieConnexe>();
	
	@Column(name="cat_afficher_haut", columnDefinition = "TINYINT")
	@JsonView(CategorieViews.Detail.class)
	Integer afficherHaut=1;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Categorie other = (Categorie) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public String toString() {
		return "Categorie [id=" + id + ", libelle=" + libelle + "]";
	}

	
	
}
