package com.plb.plbsiapi.core.model;

public enum Role {
	MANAGER("manager"),DISPATCHER("dispatcher"),COMMERCIAL("commercial"),INTERVENANTS_MANAGER("intervenantsManager"),TB_MANAGER("tableauBordManager"),AC_MANAGER("AccountsManager");
	
	private final String libelle; 
    Role(String libelle) {
        this.libelle = libelle;
    }
	public String getLibelle() {
		return libelle;
	}
    
}
