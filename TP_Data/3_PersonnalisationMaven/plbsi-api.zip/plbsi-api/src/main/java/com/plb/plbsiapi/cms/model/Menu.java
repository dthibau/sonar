package com.plb.plbsiapi.cms.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="cms_menu")
public class Menu implements Comparable<Menu> {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private String libelle;
	
	private int indice;
	
	private boolean published;
	
	@JsonIgnore
	@ManyToOne
	private Menu parent;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public Menu getParent() {
		return parent;
	}

	public void setParent(Menu parent) {
		this.parent = parent;
	}
	
	@Transient
	public Long getParentId() {
		return this.parent != null ? this.getParent().getId() : null;
	}

	public int getIndice() {
		return indice;
	}

	public void setIndice(int indice) {
		this.indice = indice;
	}

	public String getComputedIndice() {
		return this.parent != null ? this.parent.getComputedIndice() + "." + getIndice() : "" + getIndice(); 
	}
	public String getPath() {
		return toString();
	}
	
	public boolean isPublished() {
		return published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}

	@Override
	public String toString() {		
		return parent != null ? parent.toString() + " -> " + getLibelle() : getLibelle();
	}

	@Override
	public int compareTo(Menu o) {
		return getComputedIndice().compareTo(o.getComputedIndice());
	}

}
