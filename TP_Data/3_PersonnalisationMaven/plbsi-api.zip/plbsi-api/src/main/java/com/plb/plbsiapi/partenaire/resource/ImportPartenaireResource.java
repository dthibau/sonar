package com.plb.plbsiapi.partenaire.resource;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.NotFoundException;
import com.plb.plbsiapi.offre.model.Partenaire;
import com.plb.plbsiapi.offre.repository.PartenaireRepository;
import com.plb.plbsiapi.partenaire.ImportResultDto;
import com.plb.plbsiapi.partenaire.UpdateLineDto;
import com.plb.plbsiapi.service.ImportService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;




@RestController
@RequestMapping(path="/api/import")
public class ImportPartenaireResource {

	@Autowired
	ImportService importService;
	
	@Autowired
	PartenaireRepository partenaireRepository;
	
	@PutMapping(path="/partenaire/{nom}")
	 @Operation(summary = "Met à jour les tarifs et sessions d'un partenaire donné",
	    description = "Les données sont fournies au format CSV : 'Référence','Tarif','Duree','Mois1','Mois2',...,'MoisN'")
	@ApiResponses(value = { 
		      @ApiResponse(responseCode = "400", description = "Tous les paramètres ne sont pas fournis"),
		      @ApiResponse(responseCode = "404", description = "Le partenaire n'est pas trouvé") })
	public ImportResultDto importPartenaire(
			@Parameter(name = "Le nom du partenaire", required = true) 
			@PathVariable(name="nom") String nom,
			@Parameter(name= "L'année de démarrage (par défaut l'année en cours)", required = false, example="") 
			@RequestParam (required=false, value="startYear") Integer startYear,
			@Parameter(name = "Le numéro du mois de démarrage", required = false, example="") 
			@RequestParam (required=false, value="startMonth") Integer startMonth,
			@io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Un copié/collé du fichier CSV, format attendu : <br/>"+
					"AWAMA090;3622.5;5;-;25;-;20;-;-;-;-;-;-;-;;;<br/>" + 
					"AWASC090;3465;5;-;18;-;13;24;-;-;-;-;-;-;;;")  @RequestBody String csvFile ) throws NotFoundException {
	
		// Retreive partenaire Id
		Optional<Partenaire> partenaire = partenaireRepository.findByNomIgnoreCase(nom);
		if (!partenaire.isPresent())
			throw new NotFoundException("No such partenaire");
		// Parse CSV file
		int year = startYear != null ? startYear : LocalDate.now().getYear();
		List<UpdateLineDto> lines = startMonth != null ? _parseCSV(csvFile, year, startMonth) : _parseCSV(csvFile);
		LocalDate startingDate = startMonth != null ? LocalDate.of(year, startMonth, 1) : null;
		
		// Update 
		return importService.importLines(partenaire.get(), startingDate, lines);
	}
	
	private List<UpdateLineDto> _parseCSV(String csvFile, int year, int startMonth) {
				
		return Stream.of(csvFile.split("\n"))
			      .map (line -> new UpdateLineDto(line,year,startMonth))
			      .collect(Collectors.toList());
		
		
	}
	private List<UpdateLineDto> _parseCSV(String csvFile) {
		
		return Stream.of(csvFile.split("\n"))
			      .map (line -> new UpdateLineDto(line))
			      .collect(Collectors.toList());
		
		
	}
}
