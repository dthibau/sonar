package com.plb.plbsiapi.core.resource;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.core.model.Event;
import com.plb.plbsiapi.core.service.CoreService;
import com.plb.plbsiapi.core.service.NotificationService;
import com.plb.plbsiapi.offre.event.FormationModificationEvent;
import com.plb.plbsiapi.offre.model.Formation;

import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(path="/api/core/notification")
@Slf4j
public class NotificationResource {

	@Autowired
	NotificationService notificationService;

	@Autowired
	CoreService coreService;

	@PostMapping
	@Operation(summary = "Envoi tous les exemples de notification à la personne loggée")
	public ResponseEntity<Void> sendMails() throws MessagingException {

		List<Event> events = _buildEvents();
		events.stream().forEach(e -> {
			try {
				notificationService.forceNotifyEvent(e);
			} catch (MailException | FileNotFoundException | MessagingException e1) {
				log.error(e1.getMessage());
			}
		});

		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}

	private List<Event> _buildEvents() {
		Formation formation = new Formation();
		formation.setCurrentManager(coreService.getLoggedAccount());
		formation.setReference("REF");
		formation.setLibelle("Libellé formation");
		List<Event> ret = new ArrayList<Event>();

		ret.add(new FormationModificationEvent(coreService.getLoggedAccount(), formation, "bla-bla"));

		return ret;
	}
}
