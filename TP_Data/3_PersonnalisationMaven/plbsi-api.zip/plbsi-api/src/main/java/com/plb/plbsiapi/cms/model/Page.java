package com.plb.plbsiapi.cms.model;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "cms_page")
public class Page implements Comparable<Page> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@NotEmpty
	private String reference;

	@NotEmpty
	private String titre;

	@Column(name="sous_titre")
	private String sousTitre;

	@Lob
	private String content;

	@ManyToOne(optional = true)
	@JoinColumn(name="menu_id ")
	private Menu menu;

	@ManyToOne(optional = true)
	@JoinColumn(name="parent_page_id ")
	private Page parentPage;

	@ManyToOne(optional = true)
	@JoinColumn(name="gabarit_id")
	private Gabarit gabarit;

	private boolean statique;

	private boolean published;

	@Column(name="seo_title")
	private String seoTitle;
	@Column(name="seo_description")
	private String seoDescription;
	@Column(name="seo_keywords")
	private String seoKeywords;

	private String url;
	@Column(name="url_statique")
	private String urlStatique;

	private Instant updated;

	@Column(name="last_updater")
	private String lastUpdater;

	@Min(value = 1)
	private long rang;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String libelle) {
		this.titre = libelle;
	}

	public String getSousTitre() {
		return sousTitre;
	}

	public void setSousTitre(String sousTitre) {
		this.sousTitre = sousTitre;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public long getRang() {
		return rang;
	}

	public void setRang(long rangRubrique) {
		this.rang = rangRubrique;
	}

	public Gabarit getGabarit() {
		return gabarit;
	}

	public void setGabarit(Gabarit gabarit) {
		this.gabarit = gabarit;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public boolean isPublished() {
		return published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}

	public boolean isStatique() {
		return statique;
	}

	public void setStatique(boolean statique) {
		this.statique = statique;
	}

	public String getSeoTitle() {
		return seoTitle;
	}

	public void setSeoTitle(String seoTitle) {
		this.seoTitle = seoTitle;
	}

	public String getSeoDescription() {
		return seoDescription;
	}

	public void setSeoDescription(String seoDescription) {
		this.seoDescription = seoDescription;
	}

	public String getSeoKeywords() {
		return seoKeywords;
	}

	public void setSeoKeywords(String seoKeywords) {
		this.seoKeywords = seoKeywords;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrlStatique() {
		return urlStatique;
	}

	public void setUrlStatique(String urlStatique) {
		this.urlStatique = urlStatique;
	}

	public Instant getUpdated() {
		return updated;
	}

	public void setUpdated(Instant updated) {
		this.updated = updated;
	}

	public String getLastUpdater() {
		return lastUpdater;
	}

	public void setLastUpdater(String lastUpdater) {
		this.lastUpdater = lastUpdater;
	}

	public Page getParentPage() {
		return parentPage;
	}

	public void setParentPage(Page parentPage) {
		this.parentPage = parentPage;
	}

	public String getComputedRang() {
		if (menu != null)
			return menu.getComputedIndice() + "." + getRang();
		else if (parentPage != null)
			return parentPage.getComputedRang() + "." + getRang();
		else 
			return "99";
	}

	@Override
	public int compareTo(Page o) {
		return getComputedRang().compareTo(o.getComputedRang());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Page other = (Page) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	
}
