package com.plb.plbsiapi.partenaire.gkn22.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="courses")
public class GKN22Courses {

	private List<GKN22Course> courses;

	public List<GKN22Course> getCourses() {
		return courses;
	}

	@XmlElement(name = "course")
	public void setCourses(List<GKN22Course> courses) {
		this.courses = courses;
	}

	
	
	
}
