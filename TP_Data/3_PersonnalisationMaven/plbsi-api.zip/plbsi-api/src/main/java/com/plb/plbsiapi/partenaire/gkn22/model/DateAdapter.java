package com.plb.plbsiapi.partenaire.gkn22.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class DateAdapter extends XmlAdapter<String, LocalDate> {

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Override
    public String marshal(LocalDate localDate) throws Exception {
       return formatter.format(localDate);
    }

    @Override
    public LocalDate unmarshal(String date) throws Exception {
        return LocalDate.parse(date, formatter);
    }

}
