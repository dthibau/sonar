package com.plb.plbsiapi.backoffice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import java.util.Date;
import javax.persistence.TemporalType;

@Entity
@Table(name="url")
public class Url {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private String urlbase;
	
	private String urlredirection;
	
	@Temporal(TemporalType.DATE)
    private Date date;

	private int code;
	
	private boolean actif;
	
	private int idobj;
	
	private String type;
	
	public Long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	public String getUrlbase() {
		return urlbase;
	}

	public void setUrlbase(String urlbase) {
		this.urlbase = urlbase;
	}
	
	public String getUrlredirection() {
		return urlredirection;
	}
	
	public void setUrlredirection(String urlredirection) {
		this.urlredirection = urlredirection;
	}
	
	public Date getDate() {
		return date;
	}
	
	public void setDate (Date date) {
		this.date = date;
	}
	
	public int getCode() {
		return code;
	}
	
	public void setCode (int code) {
		this.code = code;
	}
	
	public boolean getActif() {
		return actif;
	}
	
	public void setActif(boolean actif) {
		this.actif = actif;
	}
	
	public int getIdbbj() {
		return idobj;
	}
	
	public void setIdoj(int idobj) {
		this.idobj = idobj;
	}
	
	public String getType() {
		return this.type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
}

