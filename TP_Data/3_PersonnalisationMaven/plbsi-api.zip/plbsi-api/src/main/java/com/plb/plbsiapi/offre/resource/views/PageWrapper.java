package com.plb.plbsiapi.offre.resource.views;

import java.util.List;

import org.springframework.data.domain.Page;

import com.fasterxml.jackson.annotation.JsonView;

public class PageWrapper<T> {

	private Page<T> page;
	
	public PageWrapper(Page<T> page) {
		this.page = page;	
	}
	
	@JsonView(FormationViews.List.class)
	public List<T> getContent() {
		return page.getContent();
	}
	@JsonView(FormationViews.List.class)
	public int getSize() {
		return page.getSize();
	}
	@JsonView(FormationViews.List.class)
	public int getNoPage() {
		return page.getNumber();
	}
	@JsonView(FormationViews.List.class)
	public int getTotalPages() {
		return page.getTotalPages();
	}
	@JsonView(FormationViews.List.class)
	public long getTotalElements() {
		return page.getTotalElements();
	}

}
