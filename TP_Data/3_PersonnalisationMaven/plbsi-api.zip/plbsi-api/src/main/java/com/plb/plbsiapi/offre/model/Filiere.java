package com.plb.plbsiapi.offre.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.resource.views.CategorieViews;
import com.plb.plbsiapi.offre.resource.views.FiliereViews;
import com.plb.plbsiapi.offre.resource.views.FormationViews;

import lombok.Data;

@Entity
@Table(name = "filiere")
@Data
public class Filiere {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id_filiere")
	@JsonView({FiliereViews.List.class,CategorieViews.List.class,FormationViews.Detail.class})
	private int id;

	@Column(name = "fil_libelle")
	@JsonView({FiliereViews.List.class,CategorieViews.List.class,FormationViews.Detail.class})
	private String libelle;

	@Column(name = "fil_url")
	@JsonView(FiliereViews.List.class)
	private String url;

	@Column(name = "fil_ordre")
	@JsonView(FiliereViews.List.class)
	private int ordre;

	@Column(name = "new_fil_color")
	@JsonView(FiliereViews.List.class)
	private String color;

	@Column(name = "fil_color_titre")
	@JsonView(FiliereViews.List.class)
	private String colorTitre;

	@Lob
	@Column(name = "fil_description", columnDefinition = "mediumtext")
	@JsonView({FiliereViews.Detail.class})
	private String description;

	@Column(name = "fil_titre")
	@JsonView({FiliereViews.Detail.class})
	private String titre;

	@Column(name = "fil_balise_title")
	@JsonView({FiliereViews.Detail.class})
	private String metaTitre;

	@Column(name = "fil_balise_description", columnDefinition = "text")
	@JsonView({FiliereViews.Detail.class})
	private String metaDescription;

	@Column(name = "fil_balise_keywords", columnDefinition = "text")
	@JsonView({FiliereViews.Detail.class})
	private String metaKeywords;

	@Column(name = "fil_mini_description")
	@JsonView({FiliereViews.Detail.class})
	private String miniDescription;

	@OneToMany(mappedBy="filiere",cascade=CascadeType.ALL)
	@JsonView({FiliereViews.Detail.class})
	@OrderBy("rang")
//	@JsonManagedReference(value="filiere_categorie")
	List<Categorie> categories = new ArrayList<Categorie>();

	@Override
	public String toString() {
		return libelle;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Filiere other = (Filiere) obj;
		if (id != other.id)
			return false;
		return true;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

}
