package com.plb.plbsiapi.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.plb.plbsiapi.core.model.Account;
import com.plb.plbsiapi.core.model.Event;
import com.plb.plbsiapi.core.repository.AccountRepository;
import com.plb.plbsiapi.core.repository.EventRepository;
import com.plb.plbsiapi.core.repository.FormationPartenaireRepository;
import com.plb.plbsiapi.offre.event.FormationModificationEvent;
import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.model.FormationPartenaire;
import com.plb.plbsiapi.offre.model.Partenaire;
import com.plb.plbsiapi.offre.model.Session;
import com.plb.plbsiapi.partenaire.ImportResultDto;
import com.plb.plbsiapi.partenaire.UpdateLineDto;

@Service
public class ImportService {

	@Autowired
	FormationPartenaireRepository formationPartenaireRepository;

	@Autowired
	EventRepository eventRepository;

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	EntityManager entityManager;

	private static final Logger logger = LoggerFactory.getLogger(ImportService.class);

	/**
	 * @param partenaire : Le partenaire
	 * @param mois       : Mois de départ pour les dates de session
	 * @param lines      : Une ligne contient la référence de la formation, le tarif
	 *                   et les dates de sessions.
	 * @return
	 */
	public ImportResultDto importLines(Partenaire partenaire, LocalDate startingDate, List<UpdateLineDto> lines) {
		ImportResultDto ret = new ImportResultDto();
		StringBuffer sbfUpdate = new StringBuffer();
		StringBuffer sbfError = new StringBuffer();
		List<FormationPartenaire> fps = formationPartenaireRepository.findByPartenaire(partenaire);
		Map<String, Formation> formationPartenairesMap = new HashMap<>();
		for (FormationPartenaire fp : fps) {
			formationPartenairesMap.put(fp.getReference(), fp.getFormation());
		}

		ret.setStartingMonth(startingDate != null ? startingDate.toString() : "Pas de mise à jour des sessions");

		int i = 0;
		for (UpdateLineDto line : lines) {
			logger.info("Traitement de la ligne " + line);
			i++;
			ret.incrementCountProcessed();
			if (!line.isValid()) {
				sbfError.append("\nLigne " + i + " non valide : " + line);
				logger.error("\nLigne " + i + " non valide : " + line);
				continue;
			}
			try {

				List<FormationPartenaire> formationPartenaires = formationPartenaireRepository
						.findByPartenaireAndCode(partenaire, line.getReference());

				logger.info("Trouvé(es) " + formationPartenaires.size() + " formations PLB correspondantes");
				if (formationPartenaires.isEmpty()) {
					sbfError.append("\nLigne " + i + " Code non trouvé " + line.getReference());
					logger.error("\nLigne " + i + " Code non trouvé " + line.getReference());
					ret.incrementCountErrors();
					continue;
				}
				for (FormationPartenaire fp : formationPartenaires) {

					sbfUpdate.append("\nCode " + line.getReference() + "(formation PLB :"
							+ fp.getFormation().getReference() + ") mis à jour ");
					formationPartenairesMap.remove(line.getReference());
					StringBuffer sbfUpdateLine = new StringBuffer();

					fp.setPrix(line.getTarif());
					// Removing replaced sessions
					if (startingDate != null) {
						List<Session> toRemove = new ArrayList<>();

						for (Session s : fp.getSessions()) {
							if (s.getDebut().isAfter(startingDate)) {
								toRemove.add(s);
							}
						}
						for (Session s : toRemove) {
							fp.getSessions().remove(s);
						}
						// Add new sessions
						for (LocalDate localDate : line.getSessions()) {
							Session s = new Session();
							s.setDebut(localDate);
							s.setFin(localDate.plusDays(line.getDuree() - 1));
							s.setFormation(fp.getFormation());
							fp.getSessions().add(s);
						}
					}
					if (startingDate != null) {
						sbfUpdateLine.append("\tNouvelle valeur " + fp.logTarifSessionString());
					} else {
						sbfUpdateLine.append("\tNouvelle valeur " + fp.logTarifString());
					}

					formationPartenaireRepository.save(fp);
					// Event pour la formation
					Optional<Account> loggedUser = accountRepository
							.findByLogin(SecurityContextHolder.getContext().getAuthentication().getName());
					Event e = new FormationModificationEvent(loggedUser.get(), fp.getFormation(),
							"<b>Importation de " + fp.getPartenaire().getNom() + "</b><br>" + sbfUpdateLine.toString().replace("\t", "<br/>"));
					eventRepository.saveAndFlush(e);
					sbfUpdate.append(sbfUpdateLine);
					ret.incrementCountUpdated();
				}
			} catch (Exception e) {
				e.printStackTrace();
				sbfError.append(
						"\nLigne " + i + " Impossible de sauvegarder " + line.getReference() + " " + e.getMessage());
				logger.error(
						"\nLigne " + i + " Impossible de sauvegarder " + line.getReference() + " " + e.getMessage());
				ret.incrementCountErrors();
			}

		}
		ret.setNotUpdated(formationPartenairesMap.keySet());
		ret.setErrorString(sbfError.toString().split("\n"));
		ret.setUpdateString(sbfUpdate.toString().split("\n"));
		return ret;
	}
}
