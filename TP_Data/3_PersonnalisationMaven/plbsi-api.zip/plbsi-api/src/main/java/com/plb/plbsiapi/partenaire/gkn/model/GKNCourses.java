package com.plb.plbsiapi.partenaire.gkn.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="courses")
public class GKNCourses {

	private List<GKNCourse> courses;

	public List<GKNCourse> getCourses() {
		return courses;
	}

	@XmlElement(name = "course")
	public void setCourses(List<GKNCourse> courses) {
		this.courses = courses;
	}

	
	
	
}
