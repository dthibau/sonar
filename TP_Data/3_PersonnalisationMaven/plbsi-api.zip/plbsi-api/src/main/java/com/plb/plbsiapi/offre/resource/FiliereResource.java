package com.plb.plbsiapi.offre.resource;

import java.util.List;

import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.model.Filiere;
import com.plb.plbsiapi.offre.repository.FiliereRepository;
import com.plb.plbsiapi.offre.resource.views.FiliereViews;

@RestController
@RequestMapping(path = "/api/offre/filieres")
public class FiliereResource {

	@Autowired
	FiliereRepository filiereRepository;
	
	@GetMapping
	@JsonView(FiliereViews.List.class)
	public List<Filiere> findAll() {
		return filiereRepository.findAll(Sort.by(Sort.Direction.ASC, "ordre"));
	}
	
	@GetMapping(path="/{id}")
	@JsonView(FiliereViews.Detail.class)
	public Filiere findOne(@PathVariable("id") Integer id) {
		return filiereRepository.fullLoad(id).orElseThrow(() -> new EntityNotFoundException("No such filiere "+id));
	}
	
	@PostMapping
	@JsonView(FiliereViews.Detail.class)
	public ResponseEntity<Filiere> createFiliere(@Valid @RequestBody Filiere filiere) {
		Filiere f = filiereRepository.save(filiere);	

		return new ResponseEntity<Filiere>(filiereRepository.fullLoad(f.getId()).orElse(null), HttpStatus.CREATED);
	}
	
	@PutMapping
	@JsonView(FiliereViews.Detail.class)
	public ResponseEntity<Filiere> updateFiliere(@Valid @RequestBody Filiere filiere) {
		filiereRepository.findById(filiere.getId()).orElseThrow(() -> new EntityNotFoundException("No such filiere "+filiere.getId())); 
		filiereRepository.save(filiere);
		
		return new ResponseEntity<Filiere>(filiereRepository.fullLoad(filiere.getId()).orElse(null), HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping(path="/{id}")
	public ResponseEntity<Void> deleteFiliere(@PathVariable("id") Integer id) {
		Filiere filiere = filiereRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("No such filiere "+id)); 
		filiereRepository.delete(filiere);	
		
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}

}
