package com.plb.plbsiapi.offre.resource;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.model.Partenaire;
import com.plb.plbsiapi.offre.model.SessionLieu;
import com.plb.plbsiapi.offre.repository.FormationRepository;
import com.plb.plbsiapi.offre.repository.PartenaireRepository;
import com.plb.plbsiapi.offre.repository.SessionLieuRepository;
import com.plb.plbsiapi.offre.resource.views.PartenaireLieu;

@RestController
@RequestMapping(path="/api/offre/lieux")
public class SessionLieuResource {
	
	@Autowired
	SessionLieuRepository sessionLieuRepository;
	
	@Autowired
	PartenaireRepository partenaireRepository;
	
	@Autowired
	FormationRepository formationRepository;
	
	
	@GetMapping
	public List<PartenaireLieu> findAll() {
		List<PartenaireLieu> ret = new ArrayList<PartenaireLieu>();
		ret.add(new PartenaireLieu(sessionLieuRepository.findPLB()));
		partenaireRepository.findAll().stream().forEach(p -> {
			ret.add(new PartenaireLieu(p, sessionLieuRepository.findByPartenaire(p)));
		});
		return ret;
	}
	
	@GetMapping("/formation/{formationId}")
	@Transactional(readOnly=true)
	public List<PartenaireLieu> findByFormation(@PathVariable Integer formationId) {
		Formation f = formationRepository.findById(formationId).orElseThrow(() -> new EntityNotFoundException());
		Hibernate.initialize(f.getFormationsPartenaire());
		List<PartenaireLieu> ret = new ArrayList<PartenaireLieu>();
		ret.add(new PartenaireLieu(sessionLieuRepository.findPLB()));
		f.getFormationsPartenaire().stream().forEach(fp -> {
			ret.add(new PartenaireLieu(fp.getPartenaire(), sessionLieuRepository.findByPartenaire(fp.getPartenaire())));
		});
		return ret;
	}
	
	@GetMapping("/partenaire/{id}")
	public List<SessionLieu> findByPartenaire(@PathVariable Integer partenaireId) {
		Partenaire p = partenaireRepository.findById(partenaireId).orElseThrow(() -> new EntityNotFoundException());
		return sessionLieuRepository.findByPartenaire(p);
	}
	@GetMapping("/plb/")
	public List<SessionLieu> findPLB() {
		return sessionLieuRepository.findPLB();
	}

}
