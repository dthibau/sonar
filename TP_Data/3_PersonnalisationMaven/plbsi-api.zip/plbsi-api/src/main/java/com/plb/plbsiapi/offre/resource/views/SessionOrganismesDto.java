package com.plb.plbsiapi.offre.resource.views;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.model.SessionLieu;

import lombok.Data;



@Data
public class SessionOrganismesDto implements Comparable<SessionOrganismesDto> {


	
	@JsonView({FormationViews.List.class})
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private final LocalDate debut;
	@JsonView({FormationViews.List.class})
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private final LocalDate fin;
	
	@JsonView({FormationViews.List.class})
	private List<LieuOrganisme> lieuxOrganismes = new ArrayList<>();
		
	public SessionOrganismesDto(LocalDate debut, LocalDate fin) {
		super();
		this.debut = debut;
		this.fin = fin;
	}
	
	public void addLieuOrganisme(LieuOrganisme lieuOrganisme) {
		lieuxOrganismes.add(lieuOrganisme);
	}
	
	@Override
	public int compareTo(SessionOrganismesDto o) {
		return debut.compareTo(o.getDebut()) ;
	}
	

	
}
