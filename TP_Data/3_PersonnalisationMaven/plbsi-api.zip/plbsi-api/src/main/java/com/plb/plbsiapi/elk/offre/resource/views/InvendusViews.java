package com.plb.plbsiapi.elk.offre.resource.views;

public class InvendusViews {
	public static class List {
    }
	
	public static class Detail extends List{};
}
