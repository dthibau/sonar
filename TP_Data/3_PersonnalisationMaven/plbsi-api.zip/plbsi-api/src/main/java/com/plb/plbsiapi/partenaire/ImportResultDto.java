package com.plb.plbsiapi.partenaire;

import java.util.Set;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Résultat de l'importation")
public class ImportResultDto {

	@Schema(description = "Mois de départ des sessions", example = "1")
	public String startingMonth;
	@Schema(description  = "Nombre de lignes traitées", example = "1")
	public int countProcessed = 0;
	@Schema(description  = "Nombre de lignes ayant provoqué une mise à jour dans la base", example = "1")
	public int countUpdated = 0;
	@Schema(description  = "Nombre de lignes n'ayant pas pu être traitées", example = "1")
	public int countErrors = 0;
	@Schema(description  = "Détail pour chaque ligne en erreur")
	public String[] errorString;
	@Schema(description  = "Formations du partenaire n'ayant pas été mis à jour")
	public Set<String> notUpdated;
	@Schema(description  = "Détail pour chaque formation partenaire mise à jour : Valeur avant/Valeur après")
	public String[] updateString;


	public String getStartingMonth() {
		return startingMonth;
	}

	public void setStartingMonth(String startingMonth) {
		this.startingMonth = startingMonth;
	}

	public int getCountProcessed() {
		return countProcessed;
	}

	public void setCountProcessed(int countProcessed) {
		this.countProcessed = countProcessed;
	}

	public int getCountUpdated() {
		return countUpdated;
	}

	public void setCountUpdated(int countUpdated) {
		this.countUpdated = countUpdated;
	}

	public int getCountErrors() {
		return countErrors;
	}

	public void setCountErrors(int countErrors) {
		this.countErrors = countErrors;
	}

	public String[] getUpdateString() {
		return updateString;
	}

	public void setUpdateString(String[] updateString) {
		this.updateString = updateString;
	}

	public String[] getErrorString() {
		return errorString;
	}

	public void setErrorString(String[] errorString) {
		this.errorString = errorString;
	}

	public void incrementCountErrors() {
		countErrors++;
	}

	public void incrementCountUpdated() {
		countUpdated++;
	}

	public void incrementCountProcessed() {
		countProcessed++;
	}

	public Set<String> getNotUpdated() {
		return notUpdated;
	}

	public void setNotUpdated(Set<String> notUpdated) {
		this.notUpdated = notUpdated;
	}

}
