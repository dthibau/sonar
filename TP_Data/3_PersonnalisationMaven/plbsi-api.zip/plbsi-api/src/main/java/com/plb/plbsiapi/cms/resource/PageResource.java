package com.plb.plbsiapi.cms.resource;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.cms.model.Gabarit;
import com.plb.plbsiapi.cms.model.Menu;
import com.plb.plbsiapi.cms.model.Page;
import com.plb.plbsiapi.cms.repository.GabaritRepository;
import com.plb.plbsiapi.cms.repository.MenuRepository;
import com.plb.plbsiapi.cms.repository.PageRepository;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping(path = "/api/cms/pages")
public class PageResource {

	private final Logger log = LoggerFactory.getLogger(PageResource.class);

	@Autowired
	PageRepository pageRepository;

	@Autowired
	MenuRepository menuRepository;

	@Autowired
	GabaritRepository gabaritRepository;

	@GetMapping
	public List<Page> getAllOrSomePages(@RequestParam(required = false) Long menuId,
			@RequestParam(required = false) Long gabaritId, @RequestParam(required = false) Long parentPageId) {

		List<Page> ret = null;
		if (menuId == null && gabaritId == null && parentPageId == null) {
			ret = pageRepository.findAll();
		} else if (menuId != null && gabaritId == null) {
			Optional<Menu> menu = menuRepository.findById(menuId);
			ret = menu.map(r -> pageRepository.findByMenuOrderByRang(r)).orElse(new ArrayList<Page>());
		} else if (menuId == null && gabaritId != null) {
			Optional<Gabarit> gabarit = gabaritRepository.findById(gabaritId);
			ret = gabarit.map(g -> pageRepository.findByGabarit(g)).orElse(new ArrayList<Page>());
		} else if (parentPageId != null ) {
			Optional<Page> parentPage = pageRepository.findById(parentPageId);
			ret = parentPage.map(p -> pageRepository.findByParentPage(p)).orElse(new ArrayList<Page>());
		} else {
			Optional<Menu> menu = menuRepository.findById(menuId);
			Optional<Gabarit> gabarit = gabaritRepository.findById(gabaritId);
			if (!menu.isPresent() || !gabarit.isPresent()) {
				ret = new ArrayList<Page>();
			} else {
				ret = pageRepository.findByGabaritAndMenuOrderByRang(gabarit.get(), menu.get());
			}
		}
		Collections.sort(ret);
		return ret;
	}

	@GetMapping(path="/parents")
	
	@Operation(summary="Les pages parentes d'autres pages")
	public Set<Page> getParentsPages() {
		Set<Page> parents = new HashSet<>();
		pageRepository.findAll().stream().forEach(p -> {
			if ( p.getParentPage() != null) {
				parents.add(p.getParentPage());
			}
		});
		return parents;
		
	}
	
	@GetMapping(path="/parentables")
	@Operation(summary="Les pages associés à 1 menu peuvent être parentes d'autres pages")
	public List<Page> getParentablePages() {
		
		return pageRepository.findAll().stream().filter(p -> p.getMenu() != null && p.getParentPage() == null).collect(Collectors.toList());
		
	}
	@GetMapping(path = "{id}")
	public ResponseEntity<Page> getPage(@PathVariable Long id) throws URISyntaxException {
		log.debug("REST request to get Page : {}", id);

		return pageRepository.findById(id).map(p -> ResponseEntity.ok(p))
				.orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));

	}

	@PostMapping
	public ResponseEntity<Page> createPage(@Valid @RequestBody Page page) throws URISyntaxException {
		log.debug("REST request to save Page : {}", page);
		if (page.getId() != null && page.getId() != 0) {
			return ResponseEntity.badRequest().body(page);
		}
		page.setUpdated(Instant.now());
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		page.setLastUpdater(auth.getName());
		
		Page result = pageRepository.save(page);
		return ResponseEntity.created(new URI("/api/cms/pages/" + result.getId())).body(result);
	}

	/**
	 * Used to partial upate of content. Does not update the update date and the updater.
	 * @param page
	 * @return
	 * @throws URISyntaxException
	 */
	@PutMapping("content")
	public ResponseEntity<Page> updateContent(@Valid @RequestBody Page page) throws URISyntaxException {
		log.debug("REST request to update Page Content : {}", page);
		if (page.getId() == null) {
			return createPage(page);
		}
		Page result = pageRepository.save(page);
		return ResponseEntity.ok().body(result);
	}
	
	@PutMapping
	public ResponseEntity<Page> updatePage(@Valid @RequestBody Page page) throws URISyntaxException {
		log.debug("REST request to update Page : {}", page);
		if (page.getId() == null) {
			return createPage(page);
		}
		page.setUpdated(Instant.now());
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		page.setLastUpdater(auth.getName());
		Page result = pageRepository.save(page);
		return ResponseEntity.ok().body(result);
	}

	@PatchMapping
	public ResponseEntity<Page> patchPage(@RequestBody Page page) throws URISyntaxException {
		log.debug("REST request to update patially a page : {}", page);
		page.setUpdated(Instant.now());
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		page.setLastUpdater(auth.getName());
		
		return pageRepository.findById(page.getId()).map(p -> {
			if ( page.getReference() != null ) {
				p.setReference(page.getReference());
			}
			if ( page.getTitre() != null ) {
				p.setTitre(page.getTitre());
			}
			if ( page.getContent() != null ) {
				p.setContent(page.getContent());
			}
			if ( page.getRang() != 0 ) {
				p.setRang(page.getRang());
			}
			
			Page result = pageRepository.save(p);
			return ResponseEntity.ok(result);
		}).orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deletePage(@PathVariable Long id) {
		log.debug("REST request to delete Page : {}", id);
		Optional<Page> optPage = pageRepository.findById(id);
		if ( optPage.isPresent() ) {
			List<Page> children = pageRepository.findByParentPage(optPage.get());
			if ( children.isEmpty() ) {
				pageRepository.deleteById(id);
				return ResponseEntity.ok().build();				
			} else {
				return ResponseEntity.badRequest().body("Cette page est référencée par d'autres pages");
			}
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(""+id);
		}
	}

}
