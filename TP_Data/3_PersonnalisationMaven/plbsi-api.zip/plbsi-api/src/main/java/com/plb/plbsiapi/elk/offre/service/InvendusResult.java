package com.plb.plbsiapi.elk.offre.service;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.elk.offre.resource.views.InvendusViews;
import com.plb.plbsiapi.offre.model.Formation;

public class InvendusResult {
	Instant lastLookUp;
	List<Formation> formations = new ArrayList<>();
	DateTimeFormatter formatter =
		    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.MEDIUM)
		                     .withLocale( Locale.FRENCH )
		                     .withZone( ZoneId.systemDefault() );
	@JsonView(InvendusViews.List.class)
	public String getLastLookUp() {
		return formatter.format(lastLookUp);
	}
	public void setLastLookUp(Instant lastLookUp) {
		this.lastLookUp = lastLookUp;
	}
	@JsonView(InvendusViews.List.class)
	public List<Formation> getFormations() {
		return formations;
	}
	public void setFormations(List<Formation> formations) {
		this.formations = formations;
	}
	public void addFormation(Formation formation) {
		this.formations.add(formation);
	}
	@JsonView(InvendusViews.List.class)
	public Integer getTotal() {
		return formations.size();
	}
	
}
