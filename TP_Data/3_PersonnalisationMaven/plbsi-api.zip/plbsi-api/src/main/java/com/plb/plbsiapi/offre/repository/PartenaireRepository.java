package com.plb.plbsiapi.offre.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.plb.plbsiapi.offre.model.Partenaire;

public interface PartenaireRepository extends JpaRepository<Partenaire, Integer> {
	
	
	public Optional<Partenaire> findByNomIgnoreCase(String nom);

}
