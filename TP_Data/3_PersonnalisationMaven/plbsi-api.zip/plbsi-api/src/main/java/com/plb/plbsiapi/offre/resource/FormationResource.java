package com.plb.plbsiapi.offre.resource;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.mail.MessagingException;
import javax.persistence.EntityNotFoundException;

import org.apache.lucene.queryparser.classic.ParseException;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.offre.model.Formation;
import com.plb.plbsiapi.offre.repository.FormationRepository;
import com.plb.plbsiapi.offre.resource.views.FormationFilter;
import com.plb.plbsiapi.offre.resource.views.FormationViews;
import com.plb.plbsiapi.offre.resource.views.MinimalFormationDto;
import com.plb.plbsiapi.offre.resource.views.PageWrapper;
import com.plb.plbsiapi.offre.resource.views.SessionDto;
import com.plb.plbsiapi.offre.resource.views.UpdateFormationResponse;
import com.plb.plbsiapi.offre.service.SearchService;
import com.plb.plbsiapi.offre.service.SessionService;
import com.plb.plbsiapi.offre.service.UpdateFormationService;

import lombok.RequiredArgsConstructor;
import lombok.extern.java.Log;

@RestController
@RequiredArgsConstructor
@RequestMapping(path = "/api/offre/formations")
@Log
public class FormationResource implements 
ApplicationListener<ContextRefreshedEvent> {

	// Stateful
	private List<MinimalFormationDto> allFormations;
	
	private final FormationRepository formationRepository;
	private final SearchService searchService;
	private final UpdateFormationService updateFormationService;
	private final SessionService sessionService;

	@Override public void onApplicationEvent(ContextRefreshedEvent event) {
		loadSelectables();
    }

	private void loadSelectables() {
		Thread t = new Thread(() -> {allFormations = findSelectables(); });
		t.start();
	}
	@GetMapping
	@JsonView(FormationViews.List.class)
	public PageWrapper<Formation> findAll(@RequestParam(required = false) String q,
			@RequestParam(required = false) Boolean moreResult, @RequestParam(required = false) Integer filiereId,
			@RequestParam(required = false) Integer categorieId, @RequestParam(required = false) Boolean excluPLB,
			@RequestParam(required = false) Integer partenaireId, @RequestParam(required = false) Integer page,
			@RequestParam(required = false) Integer size, @RequestParam(required = false) String sortColumn,
			@RequestParam(required = false) String sortOrder, @RequestParam(required = false) Boolean archived)
			throws ParseException {

		FormationFilter formationFilter = new FormationFilter(q, moreResult, filiereId, categorieId, excluPLB,
				partenaireId, archived);
		page = page != null ? page : 0;
		size = size != null ? size : 20;

		if (!formationFilter.isFullText()) { // Tri par défaut : statut
			if (sortColumn == null) {
				sortColumn = "statut";
				sortOrder = "desc";
			}
			if (sortColumn.equalsIgnoreCase("categorieLibelle")) {
				sortColumn = "categorie.libelle";
			}
			if (sortColumn.equalsIgnoreCase("filiereLibelle")) {
				sortColumn = "categorie.filiere.libelle";
			}
			Sort.Direction direction = sortOrder != null
					? (sortOrder.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC)
					: Sort.Direction.ASC;

			return new PageWrapper<Formation>(
					searchService.search(formationFilter, PageRequest.of(page, size, Sort.by(direction, sortColumn))));

		} else { // Tri par défaut : pertinence Lucene
			Sort.Direction direction = sortOrder != null
					? (sortOrder.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC)
					: Sort.Direction.ASC;

			Pageable pagination = sortColumn != null ? PageRequest.of(page, size, Sort.by(direction, sortColumn))
					: PageRequest.of(page, size);

			return new PageWrapper<Formation>(searchService.fullTextSearch(formationFilter, pagination));
		}
	}

	@GetMapping(path = "/selectables")
	@JsonView(FormationViews.Detail.class)
	public synchronized List<MinimalFormationDto> findSelectables() {
		if ( allFormations == null ) {
			log.info("Retreiving selectables ...");
			allFormations = formationRepository.findAllUnarchived().stream()
					.map(f -> new MinimalFormationDto(f)).collect(Collectors.toList());
			log.info("Selectables retreived !!");
		}
		return allFormations;
	}

	@GetMapping(path = "/{id}")
	@JsonView(FormationViews.Detail.class)
	public Formation findById(@PathVariable("id") Integer id) throws EntityNotFoundException {
		return searchService.get(id);
	}

	@GetMapping(path = "/categorie/{id}")
	@JsonView(FormationViews.SmallList.class)
	public List<Formation> findByCategorie(@PathVariable("id") Integer categorieId) {
		return formationRepository.findByCategorieId(categorieId);
	}

	@PostMapping
	@JsonView(FormationViews.Detail.class)
	public ResponseEntity<Formation> createFormation(@RequestBody Formation formation) {
		formation = formationRepository.save(formation);
		loadSelectables();
		return new ResponseEntity<Formation>(formation, HttpStatus.CREATED);
	}

	@PatchMapping
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<UpdateFormationResponse> updateFormation(@RequestBody Formation formation)
			throws EntityNotFoundException, MailException, FileNotFoundException, MessagingException {

		UpdateFormationResponse response = updateFormationService.update(formation);
		loadSelectables();
		return new ResponseEntity<UpdateFormationResponse>(response,HttpStatus.ACCEPTED);
	}
	
	@PatchMapping(path = "/statut")
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<UpdateFormationResponse> updateStatut(@RequestBody Formation formation)
			throws EntityNotFoundException, MailException, FileNotFoundException, MessagingException {

		UpdateFormationResponse response = updateFormationService.updateStatut(formation);

		return new ResponseEntity<UpdateFormationResponse>(response,HttpStatus.ACCEPTED);
	}


	@PatchMapping(path = "/sessions/{id}/{year}")
	@JsonView(FormationViews.Detail.class)
	public ResponseEntity<UpdateFormationResponse> updateSessions(@PathVariable("id") Integer id,
			@PathVariable("year") int year, @RequestBody List<SessionDto> sessions)
			throws EntityNotFoundException, MailException, FileNotFoundException, MessagingException {

		UpdateFormationResponse response = updateFormationService.updateSessions(year, id, sessions);

		return new ResponseEntity<UpdateFormationResponse>(response, HttpStatus.ACCEPTED);
	}

	@GetMapping(path = "/sessions/{id}/{year}")
	@JsonView(FormationViews.Sessions.class)
	public List<SessionDto> getPlannedSessions(@PathVariable("id") Integer id, @PathVariable("year") int year) {

		return sessionService.getPlannedSessions(id, year);
	}

	@GetMapping(path = "/reference/exists/{reference}")
	public Boolean isReferenceExist(@PathVariable("reference") String reference) {
		return formationRepository.findByReference(reference).isPresent();
	}

	@PutMapping(path = "/sort/{idCategorie}")
	public ResponseEntity<Void> sortFormations(@PathVariable("idCategorie") Integer idCategorie,
			@RequestBody List<Formation> formations) {

		updateFormationService.sortFormation(idCategorie, formations);

		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}

	@PutMapping(path = "/categorie/{idCategorie}/{idFormation}")
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<UpdateFormationResponse> updateCategorie(@PathVariable("idCategorie") Integer idCategorie,
			@PathVariable("idFormation") Integer idFormation) {

		UpdateFormationResponse response = updateFormationService.updateCategorie(idCategorie, idFormation);

		return new ResponseEntity<UpdateFormationResponse>(response, HttpStatus.ACCEPTED);
	}
	
	@PostMapping(path = "/secondaire/{idCategorie}/{idFormation}")
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<UpdateFormationResponse> addCategorieSecondaire(@PathVariable("idCategorie") Integer idCategorie,
			@PathVariable("idFormation") Integer idFormation) {

		UpdateFormationResponse response = updateFormationService.addCategorieSecondaire(idCategorie, idFormation);

		return new ResponseEntity<UpdateFormationResponse>(response, HttpStatus.ACCEPTED);
	}

	@DeleteMapping(path = "/secondaire/{idCategorie}/{idFormation}")
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<UpdateFormationResponse> removeCategorieSecondaire(@PathVariable("idCategorie") Integer idCategorie,
			@PathVariable("idFormation") Integer idFormation) {

		UpdateFormationResponse response = updateFormationService.removeCategorieSecondaire(idCategorie, idFormation);

		return new ResponseEntity<UpdateFormationResponse>(response, HttpStatus.ACCEPTED);
	}
	@PostMapping(path = "/associee/{idAssociee}/{idFormation}")
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<UpdateFormationResponse> addFormationAssociee(@PathVariable("idAssociee") Integer idAssociee,
			@PathVariable("idFormation") Integer idFormation) {

		UpdateFormationResponse response = updateFormationService.addFormationAssociee(idAssociee, idFormation);

		return new ResponseEntity<UpdateFormationResponse>(response, HttpStatus.ACCEPTED);
	}

	@DeleteMapping(path = "/associee/{idAssociee}/{idFormation}")
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<UpdateFormationResponse> removeFormationAssociee(@PathVariable("idAssociee") Integer idAssociee,
			@PathVariable("idFormation") Integer idFormation) {

		UpdateFormationResponse response = updateFormationService.removeFormationAssociee(idAssociee, idFormation);

		return new ResponseEntity<UpdateFormationResponse>(response, HttpStatus.ACCEPTED);
	}

	@PostMapping(path = "/mutualisee/{idMutualisee}/{idFormation}")
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<UpdateFormationResponse> addFormationMutualisee(@PathVariable("idMutualisee") Integer idMutualisee,
			@PathVariable("idFormation") Integer idFormation) {

		UpdateFormationResponse response = updateFormationService.addFormationMutualisee(idMutualisee, idFormation);

		return new ResponseEntity<UpdateFormationResponse>(response, HttpStatus.ACCEPTED);
	}

	@DeleteMapping(path = "/mutualisee/{idMutualisee}/{idFormation}")
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<UpdateFormationResponse> removeFormationMutualisee(@PathVariable("idMutualisee") Integer idMutualisee,
			@PathVariable("idFormation") Integer idFormation) {

		UpdateFormationResponse response = updateFormationService.removeFormationMutualisee(idMutualisee, idFormation);

		return new ResponseEntity<UpdateFormationResponse>(response, HttpStatus.ACCEPTED);
	}
	

	@PutMapping(path = "/bloc/{bloc}/{idFormation}")
	@JsonView(FormationViews.SmallList.class)
	public ResponseEntity<Void> updateBloc(@PathVariable("bloc") String bloc,
			@PathVariable("idFormation") Integer idFormation, @RequestBody(required=false) String content) {

		updateFormationService.updateBloc(bloc, idFormation, content);

		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}
}
