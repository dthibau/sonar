package com.plb.plbsiapi.cms.resource;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.plb.plbsiapi.cms.model.Menu;
import com.plb.plbsiapi.cms.repository.MenuRepository;

@RestController
@RequestMapping(path="/api/cms/menus")
public class MenuResource {
	
	private final Logger log = LoggerFactory.getLogger(MenuResource.class);
	
	@Autowired
	MenuRepository menuRepository;
	
	@GetMapping
	public List<Menu> getAll() {
			
		List<Menu> menus = menuRepository.findAll(Sort.by(Sort.Direction.ASC, "indice"));
		Collections.sort(menus);
		return menus;
	}
	
	@GetMapping(path = "{id}")
	public ResponseEntity<Menu> getMenu(@PathVariable Long id) throws URISyntaxException {
		log.debug("REST request to get Menu : {}", id);

		return menuRepository.findById(id).map(p -> ResponseEntity.ok(p))
				.orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));

	}
	
	@DeleteMapping(path = "{id}")
	public ResponseEntity<Menu> deleteMenu(@PathVariable Long id) throws URISyntaxException {
		log.debug("REST request to get Menu : {}", id);

		Optional<Menu> optMenu = menuRepository.findById(id); 
		if ( optMenu.isPresent() ) {
			menuRepository.delete(optMenu.get());
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(null);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		

	}
	
	@PostMapping(path="/{parentId}")
	public ResponseEntity<Menu> createMenu(@PathVariable Long parentId, @Valid @RequestBody Menu menu) throws URISyntaxException {
		log.debug("REST request to create Menu : {}, parentId", menu, parentId);
		
		if (menu.getId() != null) {
			return ResponseEntity.badRequest().body(menu);
		}
		menu.setParent(menuRepository.findById(parentId).orElse(null));
		Menu result = menuRepository.save(menu);
		return ResponseEntity.created(new URI("/api/cms/menus/" + result.getId())).body(result);
	}
	@PostMapping
	public ResponseEntity<Menu> createMenu(@Valid @RequestBody Menu menu) throws URISyntaxException {
		log.debug("REST request to create Menu : {}", menu);
		
		if (menu.getId() != null) {
			return ResponseEntity.badRequest().body(menu);
		}
		Menu result = menuRepository.save(menu);
		return ResponseEntity.created(new URI("/api/cms/menus/" + result.getId())).body(result);
	}

	@PutMapping(path="/{parentId}")
	public ResponseEntity<Menu> updateMenu(@PathVariable Long parentId, @Valid @RequestBody Menu menu) throws URISyntaxException {
		log.debug("REST request to update Menu : {}, parentId", menu, parentId);
		
		if (menu.getId() == null) {
			return createMenu(parentId,menu);
		}

		menu.setParent(menuRepository.findById(parentId).orElse(null));
		Menu result = menuRepository.save(menu);
		return ResponseEntity.ok().body(result);
	}
	@PutMapping
	public ResponseEntity<Menu> updateMenu(@Valid @RequestBody Menu menu) throws URISyntaxException {
		log.debug("REST request to update Menu : {}", menu);
		
		
		if (menu.getId() == null) {
			return createMenu(menu);
		}

		Menu result = menuRepository.save(menu);
		return ResponseEntity.ok().body(result);
	}
}
