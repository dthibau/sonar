package com.plb.plbsiapi.core.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.plb.plbsiapi.offre.model.FormationPartenaire;
import com.plb.plbsiapi.offre.model.Partenaire;

@Repository
public interface FormationPartenaireRepository extends JpaRepository<FormationPartenaire, Integer> {

	/**
	 * La même reférence partenaire peut être en backup de plusieurs formations PLB
	 * 
	 * @param partenaire
	 * @param code
	 * @return
	 */
	@Query("select distinct fp from FormationPartenaire fp left join fetch fp.sessions where fp.partenaire = :partenaire and fp.reference=:reference")
	public List<FormationPartenaire> findByPartenaireAndCode(@Param("partenaire") Partenaire partenaire,
			@Param("reference") String reference);

	@Query("select distinct fp from FormationPartenaire fp left join fetch fp.sessions where fp.partenaire = :partenaire")
	public List<FormationPartenaire> findByPartenaire(@Param("partenaire") Partenaire partenaire);
}
