package com.plb.plbsiapi.offre.resource.views;

import com.fasterxml.jackson.annotation.JsonView;
import com.plb.plbsiapi.elk.offre.resource.views.InvendusViews;
import com.plb.plbsiapi.offre.model.Formation;

public class MinimalFormationDto {

	private Formation formation;
	
	public MinimalFormationDto() {
	}
	public MinimalFormationDto(Formation formation) {
		this.formation= formation;
	}
	@JsonView({FormationViews.List.class, FormationViews.Detail.class, InvendusViews.List.class})
	public Integer getIdFormation() {
		return formation.getIdFormation();
	}
	@JsonView({FormationViews.List.class, FormationViews.Detail.class, InvendusViews.List.class})
	public String getLibelle() {
		return formation.getLibelle();
	}
	@JsonView({FormationViews.List.class, FormationViews.Detail.class, InvendusViews.List.class})
	public String getReference() {
		return formation.getReference();
	}
	@JsonView({FormationViews.List.class, FormationViews.Detail.class, InvendusViews.List.class})
	public String getURLPlb() {
		return formation.getUrlPlb();
	}
}
