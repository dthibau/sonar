package com.plb.plbsiapi.partenaire.gkn.model;

import java.time.LocalDate;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name="sessions")
public class GKNSession {

	private List<LocalDate> dates;
	
	public List<LocalDate> getDates() {
		return dates;
	}

	@XmlElement(name = "date")
	@XmlJavaTypeAdapter(DateAdapter.class)
	public void setDates(List<LocalDate> dates) {
		this.dates= dates;
	}
}
