package com.plb.plbsiapi.offre.resource.views;

import com.plb.plbsiapi.offre.model.Session;

import lombok.Data;

@Data
public class SessionOrganismeDto implements Comparable<SessionOrganismeDto> {

	private LieuOrganisme lieuOrganisme;
	private Session session;
	
	
	public SessionOrganismeDto(LieuOrganisme lieuOrganisme, Session session) {
		super();
		this.lieuOrganisme = lieuOrganisme;
		this.session = session;
	}

	
	@Override
	public int compareTo(SessionOrganismeDto o) {
		return getSession().getDebut().compareTo(o.getSession().getDebut()) ;
	}

	@Override
	public String toString() {
		return session.toString() + " (" + lieuOrganisme + ")";
	}
	
	
}
