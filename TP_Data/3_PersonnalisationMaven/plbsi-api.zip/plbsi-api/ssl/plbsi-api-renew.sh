#!/bin/bash
DEST=keystore.p12
DOMAIN=plbsi-rec.plb.fr


openssl pkcs12 -export -in /etc/letsencrypt/live/${DOMAIN}/cert.pem -inkey /etc/letsencrypt/live/${DOMAIN}/privkey.pem -out ${DEST} -name tomcat -CAfile /etc/letsencrypt/live/${DOMAIN}/chain.pem -caname root -passout pass:9lM)[dfZ

/etc/init.d/plbsi-api start --spring.profiles.active=int

