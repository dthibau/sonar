import { FormControl, ValidatorFn, AbstractControl } from '@angular/forms';


export class CustomValidators {
    static notAssigned(alreadyAssigned: number[]): ValidatorFn {
        return (control: AbstractControl): { [key: string]: boolean } | null => {
            console.log('Validating ' + control.value + ' with ' + alreadyAssigned);
            console.log(alreadyAssigned.indexOf(control.value, 0));
            if (control.value !== undefined && alreadyAssigned.indexOf(parseInt(control.value, 10), 0) !== -1 ) {
                return { alreadyAssigned: true };
            }
            return null;
        };
    }
}