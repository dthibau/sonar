import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  selected: number;
  constructor(private router: Router) {
    console.log(this.router.url);
    this.selected = 1;
    if ( this.router.url.includes('menu') ) {
      this.selected = 2;
    } else if ( this.router.url.includes('gabarit') ) {
      this.selected = 3;
    }
    
  }

  ngOnInit() {
  }

  public select(newSelect) {
    console.log('New Select' + newSelect);
    this.selected = newSelect;
  }
}
