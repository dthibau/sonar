import { Gabarit } from './gabarit.model';
import { Menu } from './menu.model';


export class Page {

    constructor(
        public id?: number,
        public reference?: string,
        public titre?: string,
        public sousTitre?: string,
        public content?: string,
        public published?: boolean,
        public gabarit?: Gabarit,
        public menu?: Menu,
        public rang?: number,
        public parentPage?: Page,
        public computedRang?: string,
        public statique?: boolean,
        public url?: string,
        public urlStatique?: string,
        public seoTitle?: string,
        public seoDescription?: string,
        public seoKeywords?: string,
        public updated?: string,
        public lastUpdater?: string
    ) {   }




}
