import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpParams, HttpHeaders } from '@angular/common/http';


import { Page } from './page-list/page.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Menu } from './page-list/menu.model';
import { Gabarit } from './page-list/gabarit.model';
import { SERVER_API_URL } from '../app.constants';



export type EntityResponseType = HttpResponse<Page>;

@Injectable()
export class PageService {

    private resourceUrl = SERVER_API_URL + '/cms/pages';
    private resourceGabaritUrl = SERVER_API_URL + '/cms/gabarits';
    private resourceMenuUrl = SERVER_API_URL + '/cms/menus';

    private httpOptions = {
        headers: new HttpHeaders({
          'Access-Control-Request-Method': 'POST'
        })
      };

    constructor(private http: HttpClient) { }


    create(page: Page): Observable<EntityResponseType> {
        const copy = this.convert(page);
        return this.http.post<Page>(this.resourceUrl, copy, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertResponse(res)));
    }

    update(page: Page): Observable<EntityResponseType> {
        const copy = this.convert(page);
        return this.http.put<Page>(this.resourceUrl, copy, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertResponse(res)));
    }

    updateContent(page: Page): Observable<EntityResponseType> {
        const copy = this.convert(page);
        return this.http.put<Page>(this.resourceUrl + '/content', copy, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertResponse(res)));
    }

    patch(page: Page): Observable<EntityResponseType> {
        const copy = this.convert(page);
        return this.http.patch<Page>(this.resourceUrl, copy, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertResponse(res)));
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<Page>(`${this.resourceUrl}/${id}`, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertResponse(res)));
    }

    query(req?: any): Observable<HttpResponse<Page[]>> {
        const options = this.createRequestOption(req);
        return this.http.get<Page[]>(this.resourceUrl, { params: options, observe: 'response' })
            .pipe(map((res: HttpResponse<Page[]>) => this.convertArrayResponse(res)));
    }
    parentables(req?: any): Observable<HttpResponse<Page[]>> {
        const options = this.createRequestOption(req);
        return this.http.get<Page[]>(this.resourceUrl + '/parentables', { params: options, observe: 'response' })
            .pipe(map((res: HttpResponse<Page[]>) => this.convertArrayResponse(res)));
    }
    parents(req?: any): Observable<HttpResponse<Page[]>> {
        const options = this.createRequestOption(req);
        return this.http.get<Page[]>(this.resourceUrl + '/parents', { params: options, observe: 'response' })
            .pipe(map((res: HttpResponse<Page[]>) => this.convertArrayResponse(res)));
    }

    fetchMenus(): Observable<HttpResponse<Menu[]>> {
        return this.http.get<Menu[]>(this.resourceMenuUrl, { observe: 'response' })
            .pipe(map((res: HttpResponse<Menu[]>) => this.convertMenuArrayResponse(res)));
    }

    fetchGabarits(): Observable<HttpResponse<Gabarit[]>> {
        return this.http.get<Menu[]>(this.resourceGabaritUrl, { observe: 'response' })
            .pipe(map((res: HttpResponse<Gabarit[]>) => this.convertGabaritArrayResponse(res)));
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    findMenu(id: number): Observable<EntityResponseType> {
        return this.http.get<Menu>(`${this.resourceMenuUrl}/${id}`, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertMenuResponse(res)));
    }
    createMenu(menu: Menu): Observable<Menu> {
        console.log('Creating Menu');
        const copy = this.convertMenu(menu);
        return  menu.parentId !== null && menu.parentId !== undefined ?
             this.http.post<Menu>(this.resourceMenuUrl + '/' + menu.parentId, copy, this.httpOptions) :
            this.http.post<Menu>(this.resourceMenuUrl, copy, this.httpOptions);
    }

    updateMenu(menu: Menu): Observable<Menu> {
        console.log('Updating Menu');
        const copy = this.convertMenu(menu);
        return menu.parentId !== null && menu.parentId !== undefined ?
            this.http.put<Menu>(this.resourceMenuUrl + '/' + menu.parentId, copy, this.httpOptions) :
            this.http.put<Menu>(this.resourceMenuUrl, copy, this.httpOptions);
    }


    deleteMenu(id: number): Observable<HttpResponse<any>> {
        console.log('Sending DEL request');
        return this.http.delete<any>(`${this.resourceMenuUrl}/${id}`, { observe: 'response' });
    }


    private convertResponse(res: EntityResponseType): EntityResponseType {
        const body: Page = this.convertItemFromServer(res.body);
        return res.clone({ body });
    }

    private convertMenuResponse(res: EntityResponseType): EntityResponseType {
        const body: Menu = this.convertMenuFromServer(res.body);
        return res.clone({ body });
    }

    private convertArrayResponse(res: HttpResponse<Page[]>): HttpResponse<Page[]> {
        const jsonResponse: Page[] = res.body;
        const body: Page[] = [];
        for (const response of jsonResponse) {
            body.push(this.convertItemFromServer(response));
        }
        return res.clone({ body });
    }

    /**
     * Convert a returned JSON object to Page.
     */
    private convertItemFromServer(page: Page): Page {
        const copy: Page = Object.assign({}, page);
        return copy;
    }


    /**
     * Convert a returned JSON object to Menu.
     */
    private convertMenuFromServer(menu: Menu): Menu {
        const copy: Menu = Object.assign({}, menu);
        return copy;
    }

    private convertMenuArrayResponse(res: HttpResponse<Menu[]>): HttpResponse<Menu[]> {
        const jsonResponse: Menu[] = res.body;
        const body: Menu[] = [];
        for (const response of jsonResponse) {
            body.push(this.convertMenuFromServer(response));
        }
        return res.clone({ body });
    }

    private convertGabaritArrayResponse(res: HttpResponse<Gabarit[]>): HttpResponse<Gabarit[]> {
        const jsonResponse: Gabarit[] = res.body;
        const body: Gabarit[] = [];
        for (const response of jsonResponse) {
            body.push(this.convertGabaritFromServer(response));
        }
        return res.clone({ body });
    }
    /**
     * Convert a returned JSON object to Gabarit.
     */
    private convertGabaritFromServer(gabarit: Gabarit): Gabarit {
        const copy: Gabarit = Object.assign({}, gabarit);
        return copy;
    }

    /**
     * Convert a Page to a JSON which can be sent to the server.
     */
    private convert(page: Page): Page {
        if (page.menu != null && (page.menu.id == null || page.menu.id == 0) ) {
            page.menu = null;
        }
        if (page.parentPage != null && (page.parentPage.id == null || page.parentPage.id == 0) ) {
            page.parentPage = null;
        }
        const copy: Page = Object.assign({}, page);
        return copy;
    }
    private convertMenu(menu: Menu): Menu {
        const copy: Menu = Object.assign({}, menu);
        return copy;
    }


    private createRequestOption = (req?: any): HttpParams => {
        let options: HttpParams = new HttpParams();
        if (req) {
            Object.keys(req).forEach((key) => {
                if (req[key] != null && req[key] != -1 ) {
                    options = options.set(key, req[key]);
                }
            });
        }
        return options;
    }
}
