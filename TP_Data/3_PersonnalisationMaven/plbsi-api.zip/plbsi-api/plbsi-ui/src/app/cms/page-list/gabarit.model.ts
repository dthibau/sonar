

export class Gabarit {
    constructor(
        public id?: number,
        public libelle?: string,
        public description?: string,
    ) {
    }
}
