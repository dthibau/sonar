

export class Menu {
    constructor(
        public id?: number,
        public libelle?: string,
        public indice?: number,
        public computedIndice?: number,
        public path?: string,
        public parentId?: number,
        public published?: boolean) {
    }

}
