import { Component, OnInit } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Page } from './page.model';
import { PageService } from '../page.service';
import { Gabarit } from './gabarit.model';
import { Menu } from './menu.model';
import { AlertService } from '../../app-common/alert.service';
import { WEB_URL } from 'src/app/app.constants';

@Component({
  selector: 'app-page-list',
  templateUrl: './page-list.component.html',
  styleUrls: ['./page-list.component.scss']
})
export class PageListComponent implements OnInit {

  pages: Page[];
  parentPages: Page[];
  gabarits: Gabarit[];
  menus: Menu[];
  selMenu: number;
  selGabarit: number;
  baseUrl: string;

  constructor(private pageService: PageService, private alertService: AlertService) { }

  ngOnInit() {
    this.loadAll();
    this.selMenu = -1;
    this.selGabarit = -1;
    this.baseUrl = WEB_URL;
  }

  loadAll() {
    this.pageService.query().subscribe(
      (res: HttpResponse<Page[]>) => this.onSuccess(res.body),
      (res: HttpErrorResponse) => this.onError(res.message)
    );
    this.pageService.parents().subscribe(
      (res: HttpResponse<Page[]>) => { this.parentPages = res.body; },
      (res: HttpErrorResponse) => this.onError(res.message)
    );
    this.pageService.fetchGabarits().subscribe(
      (res: HttpResponse<Gabarit[]>) => { this.gabarits = res.body; },
      (res: HttpErrorResponse) => this.onError(res.message)
    );
    this.pageService.fetchMenus().subscribe(
      (res: HttpResponse<Menu[]>) => { this.menus = res.body; },
      (res: HttpErrorResponse) => this.onError(res.message)
    );
  }

  fetchPages() {
    this.pageService.query({
      gabaritId: this.selGabarit,
      menuId: this.selMenu}
      ).subscribe(
      (res: HttpResponse<Page[]>) => this.onSuccess(res.body),
      (res: HttpErrorResponse) => this.onError(res.message)
    );
  }

  deletePage(id: number) {
    if (confirm('Voulez-vous vraiment supprimer cette page ?')) {
      this.pageService.delete(id).subscribe(
        (res: HttpResponse<Menu[]>) => { this.fetchPages(); },
        (res: HttpErrorResponse) => this.onError(res.error)
      );
    }
    
  }

  private onSuccess(data) {

    // this.page = pagingParams.page;
    this.pages = data;
  }
  private onError(error) {
    console.log("Erreur : "+error);
    this.alertService.error(error);
  }
  public isParent(page) {

    return this.parentPages.some(p => {return p.id == page.id});
  }
}
