import { Component, OnInit } from '@angular/core';
import { Menu } from '../page-list/menu.model';
import { PageService } from '../page.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import { CustomValidators } from '../../customValidator';
import { AlertService } from 'src/app/app-common/alert.service';

@Component({
  selector: 'app-menu-detail',
  templateUrl: './menu-detail.component.html',
  styleUrls: ['./menu-detail.component.scss']
})
export class MenuDetailComponent implements OnInit {

  menu: Menu;
  menus: Menu[];
  alreadyAssigned: number[];
  isSaving: boolean;

  myForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private pageService: PageService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap) => {
      const menuId = params.get('id');
      console.log('Menu Id  ' + menuId);
      this.pageService.fetchMenus().subscribe(
        (resAll: HttpResponse<Menu[]>) => {
          this.menus = resAll.body;
          console.log('Menus :' + this.menus);
          this.alreadyAssigned = this.menus.map(m => m.indice);
          if (menuId !== null) {
            this.pageService.findMenu(+menuId).subscribe(
              (res: HttpResponse<Menu>) => {
                this.menu = res.body;
                console.log(this.menu.parentId);
                this.alreadyAssigned = this.menus.filter(m => m.id !== this.menu.id).filter(m => m.parentId === this.menu.parentId).map(m => m.indice);
                const index = this.alreadyAssigned.indexOf(this.menu.indice, 0);
                if (index > -1) {
                  this.alreadyAssigned.splice(index, 1);
                }
                console.log('Already assigned ' + this.alreadyAssigned);
                this.createForm();
              },
              (res: HttpErrorResponse) => this.onError(res.message));
          } else {
            this.menu = new Menu();
            this.alreadyAssigned = this.menus.filter(m => m.parentId === null).map(m => m.indice);
            this.createForm();
          }
        },
        (res: HttpErrorResponse) => this.onError(res.message)

      );
    });

    this.isSaving = false;
  }

  public createForm() {
    this.myForm = this.fb.group({
      id: [this.menu.id],
      libelle: [this.menu.libelle, [Validators.required, Validators.minLength(3)]],
      indice: [this.menu.indice,
        [Validators.required, Validators.min(1), Validators.max(9),
          CustomValidators.notAssigned(this.alreadyAssigned)]],
      parentId: [this.menu.parentId],
      published: [this.menu.published]
    });
  }
  public filterMenu() {
    if (this.menus !== undefined) {
      return this.menus.filter(m => m.id !== this.menu.id);
    } else {
      return;
    }
  }
  public updateAssignedIndices(selectedParent) {
    console.log('Selected parent ' + selectedParent + ' Menus :' + this.menus);
    const id = parseInt(selectedParent, 10);
    this.alreadyAssigned = this.menus.filter(m => m.id !== this.menu.id).filter(m => m.parentId === id).map(m => m.indice);
    console.log('Already assigned ' + this.alreadyAssigned);
    this.myForm.get('indice').setValidators( [Validators.required, Validators.min(1), Validators.max(9),
      CustomValidators.notAssigned(this.alreadyAssigned)]);
    this.myForm.get('indice').updateValueAndValidity();
  }
  private onError(error) {
    this.alertService.error(error.message);
  }


  public save() {
    this.menu = this.myForm.value;
    console.log('Menu is' + this.menu);
    if (this.menu.id !== undefined) {
      this.subscribeToSaveResponse(
        this.pageService.updateMenu(this.menu));
    } else {
      this.subscribeToSaveResponse(
        this.pageService.createMenu(this.menu));
    }
    this.isSaving = true;
  }
  private subscribeToSaveResponse(result: Observable<Menu>) {
    result.subscribe((menu: Menu) =>
      this.onSaveSuccess(menu), (res: HttpErrorResponse) => this.onSaveError());
  }

  private onSaveSuccess(result: Menu) {
    this.menu = result;
    this.alertService.success('Modification enregistrée');
    this.isSaving = false;
    this.router.navigate(['cms/menus']);
  }

  private onSaveError() {
    console.log('save failed');
  }

}
