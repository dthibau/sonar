import { CmsComponent } from './cms.component';
import { MenuDetailComponent } from './../cms/menu-detail/menu-detail.component';
import { MenuListComponent } from './../cms/menu-list/menu-list.component';
import { PageDetailComponent } from './../cms/page-detail/page-detail.component';
import { PageListComponent } from './../cms/page-list/page-list.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GabaritListComponent } from './gabarit-list/gabarit-list.component';
import { MainNavigationComponent } from '../core/main-navigation.component';


const routes: Routes = [
  { path: 'cms', redirectTo: 'cms/pages', pathMatch: 'full' },
  {
    path: 'cms', component: MainNavigationComponent, children: [
      { path: 'pages', component: CmsComponent, children: [{ path: '', component: PageListComponent }] },
      { path: 'page/:id', component: CmsComponent, children: [{ path: '', component: PageDetailComponent }] },
      { path: 'page', component: CmsComponent, children: [{ path: '', component: PageDetailComponent }] },
      { path: 'menus', component: CmsComponent, children: [{ path: '', component: MenuListComponent }] },
      { path: 'menu/:id', component: CmsComponent, children: [{ path: '', component: MenuDetailComponent }] },
      { path: 'menu', component: CmsComponent, children: [{ path: '', component: MenuDetailComponent }] },
      { path: 'gabarits', component: CmsComponent, children: [{ path: '', component: GabaritListComponent }] }
    ]
  },



];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CmsRoutingModule { }
