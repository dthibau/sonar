import { Component, OnInit } from '@angular/core';
import { PageService } from '../page.service';
import { Page } from '../page-list/page.model';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Gabarit } from '../page-list/gabarit.model';
import { Menu } from '../page-list/menu.model';

import * as CustomCKEditor from '../../../ckeditor_custom/ckeditor';

// import { ChangeEvent} from '../../ckeditor_custom/ckeditor';
import { Observable } from 'rxjs';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { CustomValidators } from '../../customValidator';
import { CKMODEL, WEB_URL } from '../../../app/app.constants';
import { AlertService } from '../../../app/app-common/alert.service';

@Component({
  selector: 'app-page-detail',
  templateUrl: './page-detail.component.html',
  styleUrls: ['./page-detail.component.scss']
})
export class PageDetailComponent implements OnInit {

  baseUrl = WEB_URL;
  page: Page;
  gabarits: Gabarit[];
  menus: Menu[];
  pages: Page[];
  alreadyAssigned: number[] = [];
  isSaving: boolean;
  attachement: string;

  pageForm: FormGroup;

  public Editor = CustomCKEditor;

  public ckModel = CKMODEL;


  constructor(
    private fb: FormBuilder,
    private pageService: PageService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.ckModel.config.autosave.save = editor => this.saveEditorData(editor.getData()); 


    this.route.paramMap.subscribe((params: ParamMap) => {
      const pageId = params.get('id');
      console.log('Page Id  ' + pageId);
      if (pageId !== null) {
        this.pageService.find(+pageId).subscribe(
          (res: HttpResponse<Page>) => {
            this.page = res.body;
            console.log('Content is ' + this.page.content);
            this.ckModel.editorData = this.page.content
            if (this.page.menu != null) {
              this.updateAssignedRangMenu(this.page.menu.id);
              this.attachement = '0';
            } else if (this.page.parentPage != null) {
              this.updateAssignedRangPage(this.page.parentPage.id);
              this.attachement = '1';
            } else {
              this.attachement = '2';
            }

            this.createForm();
            this.pageService.parentables().subscribe(
              (res: HttpResponse<Page[]>) => {
                this.pages = res.body.filter(p => p.id !== this.page.id);
              },
              (res: HttpErrorResponse) => this.onError(res.message)
            );
          }, (res: HttpErrorResponse) => this.onError(res.message));

      } else {
        this.page = new Page(0, '', '', '', '', false, new Gabarit(), new Menu(), 0, new Page());
        this.attachement = '0';
        this.createForm();
        this.pageService.parentables().subscribe(
          (res: HttpResponse<Page[]>) => {
            this.pages = res.body;
          },
          (res: HttpErrorResponse) => this.onError(res.message)
        );
      }
    });
    this.pageService.fetchGabarits().subscribe(
      (res: HttpResponse<Gabarit[]>) => { this.gabarits = res.body; },
      (res: HttpErrorResponse) => this.onError(res.message)
    );
    this.pageService.fetchMenus().subscribe(
      (res: HttpResponse<Menu[]>) => { this.menus = res.body; },
      (res: HttpErrorResponse) => this.onError(res.message)
    );

  }

  public createForm() {
    console.log('Create form ' + this.page.statique);
    this.pageForm = this.fb.group({
      id: [this.page.id],
      reference: [this.page.reference, [Validators.required, Validators.maxLength(5)]],
      titre: [this.page.titre, [Validators.required]],
      sousTitre: [this.page.sousTitre, [Validators.minLength(5)]],
      published: [this.page.published],
      gabaritId: [this.page.gabarit != null ? this.page.gabarit.id : null],
      attachement: [this.attachement],
      menuId: [this.page.menu != null ? this.page.menu.id : null],
      rang: [this.page.rang,
      [Validators.required, Validators.min(1), Validators.max(9),
      CustomValidators.notAssigned(this.alreadyAssigned)]],
      parentPageId: [this.page.parentPage != null ? this.page.parentPage.id : null],
      statique: [this.page.statique],
      url: [this.page.url],
      urlStatique: [this.page.urlStatique],
      seoTitle: [this.page.seoTitle],
      seoDescription: [this.page.seoDescription],
      seoKeywords: [this.page.seoKeywords]
    });
    this.setDynamicValidations();
  }

  public updateAssignedRangMenu(selectedMenu) {
    console.log('Selected menu ' + selectedMenu);
    this.pageService.query({
      menuId: selectedMenu
    }).subscribe(
      (res: HttpResponse<Page[]>) => {
        const pages = res.body;
        this.alreadyAssigned = pages.filter(p => p.id !== this.page.id).map(p => p.rang);
        console.log('Already assigned ' + this.alreadyAssigned);
        this.pageForm.get('rang').setValidators([Validators.required, Validators.min(1), Validators.max(9),
        CustomValidators.notAssigned(this.alreadyAssigned)]);
      },
      (res: HttpErrorResponse) => this.onError(res.message)
    );

  }
  public updateAssignedRangPage(selectedPage) {
    console.log('Selected page ' + selectedPage);
    this.pageService.query({
      parentPageId: selectedPage
    }).subscribe(
      (res: HttpResponse<Page[]>) => {
        const pages = res.body;
        this.alreadyAssigned = pages.filter(p => p.id !== this.page.id).map(p => p.rang);
        console.log('Already assigned ' + this.alreadyAssigned);
        this.pageForm.get('rang').setValidators([Validators.required, Validators.min(1), Validators.max(9),
        CustomValidators.notAssigned(this.alreadyAssigned)]);
      },
      (res: HttpErrorResponse) => this.onError(res.message)
    );

  }

  public changeAttachement(attachement) {

    this.attachement = attachement;
    console.log("Attachement is " + this.attachement);
    this.setDynamicValidations();
  }

  public toggleStatique(statiqueValue) {

    this.page.statique = !this.page.statique;
    this.setDynamicValidations();
  }

  private setDynamicValidations() {
    if (this.attachement == '0') {
      console.log("Set DynamicValidations Attachement is " + this.attachement);
      this.pageForm.get('menuId').setValidators([Validators.required]);
      this.pageForm.get('parentPageId').clearValidators();
      this.pageForm.get('parentPageId').setErrors(null);
      this.pageForm.get('rang').setValidators([Validators.required, Validators.min(1), Validators.max(9),
      CustomValidators.notAssigned(this.alreadyAssigned)]);
    } else if (this.attachement == '1') {
      console.log("Set DynamicValidations Attachement is " + this.attachement);

      this.pageForm.get('menuId').clearValidators();
      this.pageForm.get('menuId').setErrors(null);

      this.pageForm.get('parentPageId').setValidators([Validators.required]);
      this.pageForm.get('rang').setValidators([Validators.required, Validators.min(1), Validators.max(9),
      CustomValidators.notAssigned(this.alreadyAssigned)]);
    } else if (this.attachement == '2') {
      console.log("Set DynamicValidations Attachement is " + this.attachement);

      this.pageForm.get('menuId').clearValidators();
      this.pageForm.get('parentPageId').clearValidators();
      this.pageForm.get('rang').clearValidators();

      this.pageForm.get('menuId').setErrors(null);
      this.pageForm.get('parentPageId').setErrors(null);
      this.pageForm.get('rang').setErrors(null);
    }


    if (this.page.statique) {
      this.pageForm.get('gabaritId').clearValidators();
      this.pageForm.get('gabaritId').setErrors(null);
      this.pageForm.get('url').clearValidators();
      this.pageForm.get('url').setErrors(null);
      this.pageForm.get('urlStatique').setValidators([Validators.required]);
    } else {
      this.pageForm.get('gabaritId').setValidators([Validators.required]);
      this.pageForm.get('url').setValidators([Validators.required]);
      this.pageForm.get('urlStatique').clearValidators();
      this.pageForm.get('urlStatique').setErrors(null);
    }

  }

  getFormValidationErrors() {
    const result = [];
    Object.keys(this.pageForm.controls).forEach(key => {

      const controlErrors: ValidationErrors = this.pageForm.get(key).errors;
      if (controlErrors) {
        Object.keys(controlErrors).forEach(keyError => {
          result.push({
            'control': key,
            'error': keyError,
            'value': controlErrors[keyError]
          });
        });
      }
    });

    return result;
  }

  private onError(error) {
    this.alertService.error(error.message);
  }

  public saveEditorData(editorData) {
    if (this.page.id !== 0) {
      this.page.content = editorData
      this.pageService.updateContent(this.page).subscribe();
    }
  }

  public save() {
    console.log('B4 form' + this.page);
    this.mergeForm();
    console.log('After Form' + this.page);
    if (this.page.id !== 0) {
      this.subscribeToSaveResponse(
        this.pageService.update(this.page));
    } else {
      this.subscribeToSaveResponse(
        this.pageService.create(this.page));
    }
  }
  private subscribeToSaveResponse(result: Observable<HttpResponse<Page>>) {
    result.subscribe((res: HttpResponse<Page>) =>
      this.onSaveSuccess(res.body), (res: HttpErrorResponse) => this.onSaveError());
  }

  private onSaveSuccess(result: Page) {
    this.page = result;
    this.alertService.success('Modification enregistrée');
    this.router.navigate(['cms/pages']);
  }

  private onSaveError() {
    console.log('save failed');
  }

  private mergeForm() {
    console.log('Merge Form');
    this.page.reference = this.pageForm.get('reference').value;
    this.page.titre = this.pageForm.get('titre').value;
    this.page.sousTitre = this.pageForm.get('sousTitre').value;
    if (this.pageForm.get('attachement').value == '0') {
      if (this.page.menu == null) {
        this.page.menu = new Menu();
      }
      this.page.menu.id = this.pageForm.get('menuId').value;
      this.page.rang = this.pageForm.get('rang').value;
      this.page.parentPage = null;
    } else if (this.pageForm.get('attachement').value == '1') {
      if (this.page.parentPage == null) {
        this.page.parentPage = new Page();
      }
      this.page.parentPage.id = this.pageForm.get('parentPageId').value;
      this.page.rang = this.pageForm.get('rang').value;
      this.page.menu = null;
    } else {
      this.page.parentPage = null;
      this.page.menu = null;
      this.page.rang = 99;
    }
    console.log('Statique ?' + this.pageForm.get('statique').value);
    this.page.statique = this.pageForm.get('statique').value;
    if (this.page.statique) {
      this.page.gabarit = null;
      this.page.url = null;
      this.page.urlStatique = this.pageForm.get('urlStatique').value;
    } else {
      this.page.gabarit.id = this.pageForm.get('gabaritId').value;
      this.page.url = this.pageForm.get('url').value;
      this.page.urlStatique = null;
    }
    this.page.published = this.pageForm.get('published').value;
    this.page.seoTitle = this.pageForm.get('seoTitle').value;
    this.page.seoDescription = this.pageForm.get('seoDescription').value;
    this.page.seoKeywords = this.pageForm.get('seoKeywords').value;
    console.log(this.page);
  }
}

