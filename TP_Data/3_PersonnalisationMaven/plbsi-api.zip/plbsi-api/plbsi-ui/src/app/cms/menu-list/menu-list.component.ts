import { Component, OnInit } from '@angular/core';
import { PageService } from '../page.service';
import { Menu } from '../page-list/menu.model';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { AlertService } from 'src/app/app-common/alert.service';

@Component({
  selector: 'app-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.scss']
})
export class MenuListComponent implements OnInit {

  menus: Menu[];
  selMenu: number;

  constructor(private pageService: PageService, private alertService: AlertService) { }

  ngOnInit() {
    this.loadAll();
    this.selMenu = -1;
  }

  loadAll() {
    this.pageService.fetchMenus().subscribe(
      (res: HttpResponse<Menu[]>) => { this.menus = res.body; },
      (res: HttpErrorResponse) => this.onError(res.message)
    );
  }

  public notDeletable(id :number) : boolean {
    return this.menus.some(m => m.parentId == id);
  }
  deleteMenu(id: number) {
    if (confirm('Voulez-vous vraiment supprimer ce menu ?')) {
      this.pageService.deleteMenu(id).subscribe(
        (res: HttpResponse<Menu[]>) => { this.loadAll(); },
        (res: HttpErrorResponse) => this.onError(res.message)
      );
    }  
  }

  private onError(error) {
    this.alertService.error(error.message);
  }



}
