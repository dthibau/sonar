import { Component, OnInit } from '@angular/core';
import { Gabarit } from '../page-list/gabarit.model';
import { PageService } from '../page.service';

import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { AlertService } from 'src/app/app-common/alert.service';

@Component({
  selector: 'app-gabarit-list',
  templateUrl: './gabarit-list.component.html',
  styleUrls: ['./gabarit-list.component.scss']
})
export class GabaritListComponent implements OnInit {

  gabarits: Gabarit[];

  constructor(private pageService: PageService, private alertService: AlertService) { }

  ngOnInit() {
    this.loadAll();
  }

  loadAll() {
    this.pageService.fetchGabarits().subscribe(
      (res: HttpResponse<Gabarit[]>) => { this.gabarits = res.body; },
      (res: HttpErrorResponse) => this.onError(res.message)
    );
  }

  private onError(error) {
    this.alertService.error(error.message);
  }

}
