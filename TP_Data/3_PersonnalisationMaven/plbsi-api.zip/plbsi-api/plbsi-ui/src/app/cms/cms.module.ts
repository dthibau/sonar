import { MenuDetailComponent } from './menu-detail/menu-detail.component';
import { MenuListComponent } from './menu-list/menu-list.component';
import { PageDetailComponent } from './page-detail/page-detail.component';
import { PageListComponent } from './page-list/page-list.component';
import { GabaritListComponent } from './gabarit-list/gabarit-list.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AlertService } from '../app-common/alert.service';
import { PageService } from './page.service';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CmsRoutingModule } from './cms-routing.module';
import { CmsComponent } from './cms.component';
import { AppCommonModule } from '../app-common/app-common.module';


@NgModule({
  declarations: [
    CmsComponent,
    PageListComponent,
    PageDetailComponent,
    MenuListComponent,
    MenuDetailComponent,
    GabaritListComponent,
    NavbarComponent
  ],
  imports: [
    AppCommonModule,
    CmsRoutingModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CKEditorModule,
  ],
  providers: [PageService,AlertService],
  exports: [CmsComponent]
})
export class CmsModule { }
