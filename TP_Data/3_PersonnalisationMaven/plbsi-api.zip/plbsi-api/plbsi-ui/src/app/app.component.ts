import { Component} from '@angular/core';
import { Subscription } from 'rxjs';
import { CoreService } from './core/core.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent  {
  title = 'plbsi-ui';
  subscription: Subscription;


  constructor(private coreService: CoreService ) { 
    if ( !this.coreService.loggedUser ) {
      console.log('App Component Loged User not set')
      this.coreService.setLoggedUser();
    }
          }
    
 
}
