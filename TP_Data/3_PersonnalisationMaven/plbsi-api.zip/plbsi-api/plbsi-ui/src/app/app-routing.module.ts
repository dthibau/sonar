import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainNavigationComponent } from './core/main-navigation.component';
import { CoreService } from './core/core.service';



const routes: Routes = [

  { path: '',  component: MainNavigationComponent, canActivate: [CoreService], pathMatch: 'full' },

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
