import { Url } from './url.model';
import { UrlsService } from './urls.service';
import { Component, OnInit } from '@angular/core';
import { faTrash } from '@fortawesome/free-solid-svg-icons';
import { WEB_URL } from 'src/app/app.constants';

@Component({
  selector: 'app-urls',
  templateUrl: './urls.component.html',
  styleUrls: ['./urls.component.scss']
})
export class UrlsComponent implements OnInit {
  success = '';
  error = '';
  faTrash = faTrash;
  urls: Url[] = [];
  pageUrls: Url[] = [];
  filteredUrls: Url[] = [];
  currentPage = 1;
  maxPage = 1;
  baseUrl = WEB_URL;
  
  constructor(public urlsService: UrlsService) { }

  ngOnInit() {
    this.loadUrls();
  }

  deleteUrl(urlId: number) {
    if (confirm('Voulez-vous vraiment supprimer cette redirection ?')) {
      this.urlsService.deleteUrl(urlId).subscribe(() => {
        this.loadUrls();
      });
    }
  }

  addUrl(url: Url) {
    this.urlsService.createUrl(url).subscribe(() => {
      this.success = 'Ajout de la redirection réussi';
      this.loadUrls();
    }, () => {
      this.error = 'Echec de l\'ajout de la redirection';
    });
  }

  resetMessages() {
    this.success = '';
    this.error = '';
  }

  loadUrls() {
    this.urlsService.getUrls().subscribe(urls => {
      this.maxPage = Math.ceil(urls.length / 20);
      this.urls = urls;
      this.getPageUrls();
    });
  }

  nextPage() {
    this.currentPage += 1;
    this.getPageUrls();
  }

  previousPage() {
    this.currentPage -= 1;
    this.getPageUrls();
  }

  getPageUrls() {
    const urls = this.filteredUrls.length > 0 ? this.filteredUrls : this.urls;
    this.pageUrls = urls.slice((this.currentPage - 1) * 20, this.currentPage * 20);
  }

  onChange(event: any) {
    const value = event.target.value;
    if (value.length > 0) {
      this.filteredUrls = this.urls.filter(x => {
        if (x.urlbase.includes(value) || x.urlredirection.includes(value) || x.code.toString().includes(value)) {
          return x;
        }
      });
      this.currentPage = 1;
      this.maxPage = Math.ceil(this.filteredUrls.length / 20);
      this.getPageUrls();
    } else {
      this.filteredUrls = [];
      this.maxPage = Math.ceil(this.urls.length / 20);
      this.currentPage = 1;
      this.getPageUrls();
    }
  }

}
