import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { SERVER_API_URL } from 'src/app/app.constants';
import { Account } from 'src/app/core/core.model';

@Injectable({
  providedIn: 'root'
})
export class AccountsService {
  apiUrl = SERVER_API_URL + '/backoffice/accounts';

  constructor(private httpClient: HttpClient) { }


  public getAccounts(): Observable<Account[]> {
    return this.httpClient.get<Account[]>(this.apiUrl)
    .pipe(
      catchError(this.errorHandle)
    );
  }

  public deleteAccount(id: number): Observable<any> {
    return this.httpClient.delete(this.apiUrl + `/${id}`)
    .pipe(
      catchError(this.errorHandle)
    );
  }

  public updateAccount(account: Account): Observable<any> {
    const copy = this.convert(account);
    return this.httpClient.patch(this.apiUrl + `/${account.id}`, copy)
    .pipe(
      catchError(this.errorHandle)
    );
  }

  public createAccount(account: Account): Observable<any> {
    const copy = this.convert(account);
    return this.httpClient.post(this.apiUrl, copy)
    .pipe(
      catchError(this.errorHandle)
    );
  }

  public errorHandle(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }

  private convert(account: Account) {
    return Object.assign({}, account);
  }
}
