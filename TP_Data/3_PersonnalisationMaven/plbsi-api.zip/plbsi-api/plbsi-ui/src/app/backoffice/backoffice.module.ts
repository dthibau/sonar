import { AccountsModule } from './accounts/accounts.module';
import { UrlsModule } from './urls/urls.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BackofficeRoutingModule } from './backoffice-routing.module';
import { BackofficeComponent } from './backoffice.component';
import { NavmenuComponent } from './navmenu/navmenu.component';


@NgModule({
  declarations: [BackofficeComponent, NavmenuComponent],
  imports: [
    CommonModule,
    BackofficeRoutingModule,
    UrlsModule,
    AccountsModule
  ]
})
export class BackofficeModule { }
