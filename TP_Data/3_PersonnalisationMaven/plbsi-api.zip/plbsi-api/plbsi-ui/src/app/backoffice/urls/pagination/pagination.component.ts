import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit {
  @Input() page: number;
  @Input() maxPage: number;
  @Output() nextPage: EventEmitter<any> = new EventEmitter();
  @Output() previousPage: EventEmitter<any> = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }

  goNextPage() {
    this.nextPage.emit(null);
  }

  goPreviousPage() {
    this.previousPage.emit(null);
  }

}
