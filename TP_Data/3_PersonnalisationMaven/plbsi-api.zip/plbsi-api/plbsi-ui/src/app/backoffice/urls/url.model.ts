export class Url {
  public id: number;
  public urlbase: string;
  public urlredirection: string;
  public code: number;
  public idobj: number;
  public actif: boolean;
  public date: Date;
  public type: string;
}
