import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Url } from '../url.model';

@Component({
  selector: 'app-create-modal',
  templateUrl: './create-modal.component.html',
  styleUrls: ['./create-modal.component.scss']
})
export class CreateModalComponent implements OnInit {
  @Output() postUrl: EventEmitter<any> = new EventEmitter();
  @Input() success: string;
  @Input() error: string;
  checkoutForm: FormGroup;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.checkoutForm = this.formBuilder.group({
      urlbase: '',
      urlredirection: '',
      code: 301
    });
  }

  onSubmit(data) {
    const newUrl = new Url();
    newUrl.urlbase = data.urlbase;
    newUrl.urlredirection = data.urlredirection;
    newUrl.code = data.code;
    newUrl.date = new Date();
    newUrl.idobj = 0;
    newUrl.actif = true;
    newUrl.type = 'Perso';
    if (newUrl.urlbase.length > 0 && newUrl.urlredirection.length > 0) {
      this.postUrl.emit(newUrl);
      this.checkoutForm.reset({ code: 301 });
      setTimeout(() => {
        this.closeModal();
      }, 800);
    }
  }

  closeModal() {
    document.getElementById('closeModal').click();
  }
}