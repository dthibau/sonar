import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, OnChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ROLE_AC_MANAGER, ROLE_COMMERCIAL, ROLE_DISPATCHER, ROLE_INTERVENANTS_MANAGER, ROLE_MANAGER, ROLE_TB_MANAGER } from 'src/app/app.constants';
import { Account } from 'src/app/core/core.model';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit, OnChanges {
  @Input() account: Account;
  @Output() updated: EventEmitter<any> = new EventEmitter();
  @Output() added: EventEmitter<any> = new EventEmitter();
  roles = [
    ROLE_MANAGER,
    ROLE_INTERVENANTS_MANAGER,
    ROLE_COMMERCIAL,
    ROLE_AC_MANAGER,
    ROLE_TB_MANAGER,
    ROLE_DISPATCHER
  ];
  updateForm = new FormGroup({
    email: new FormControl(''),
    login: new FormControl(''),
    password: new FormControl(''),
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    tel: new FormControl(''),
    roles: new FormControl('')
  });
  constructor() { }

  ngOnInit() {
  }

  updateRole(role: string, add = false) {
    let roles = this.updateForm.get('roles').value.split(';');
    if (!add) {
      roles = roles.filter(x => x && x !== role);
    } else {
      roles = [...roles, role];
    }
    roles = roles.filter(Boolean);
    this.updateForm.patchValue({
      roles: roles.join(';')
    });
  }

  updateAccount(data) {
    const newAcc = new Account();
    newAcc.id = this.account.id,
    newAcc.email = data.email,
    newAcc.login = data.login,
    newAcc.password = data.password || this.account.password,
    newAcc.prenom = data.firstName,
    newAcc.nom = data.lastName,
    newAcc.telephone = data.tel,
    newAcc.roles = data.roles,
    newAcc.deleteddate = this.account.deleteddate;
    this.updated.emit(newAcc);
    this.closeModal();
  }

  addAccount(data) {
    const newAcc = new Account();
    newAcc.email = data.email,
    newAcc.login = data.login,
    newAcc.password = data.password,
    newAcc.prenom = data.firstName,
    newAcc.nom = data.lastName,
    newAcc.telephone = data.tel,
    newAcc.roles = data.roles,
    newAcc.deleteddate = null;
    this.added.emit(newAcc);
    this.closeModal();
  }

  closeModal() {
    document.getElementById('closeModal').click();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.account) {
      const changedAccount = changes.account.currentValue;
      if (changedAccount) {
        this.updateForm.setValue({
          email: changedAccount.email,
          login: changedAccount.login,
          password: '',
          firstName: changedAccount.prenom,
          lastName: changedAccount.nom,
          tel: changedAccount.telephone,
          roles: changedAccount.roles,
        });
      } else {
        this.updateForm.setValue({
          email: '',
          login: '',
          password: '',
          firstName: '',
          lastName: '',
          tel: '',
          roles: '',
        });
      }
    }
  }

}
