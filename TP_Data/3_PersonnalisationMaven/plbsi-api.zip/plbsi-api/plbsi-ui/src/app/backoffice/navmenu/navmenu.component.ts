import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ROLE_AC_MANAGER, ROLE_MANAGER } from 'src/app/app.constants';
import { CoreService } from 'src/app/core/core.service';



@Component({
  selector: 'app-navmenu',
  templateUrl: './navmenu.component.html',
  styleUrls: ['./navmenu.component.scss']
})
export class NavmenuComponent {

  ROLE_MANAGER = ROLE_MANAGER
  ROLE_AC_MANAGER = ROLE_AC_MANAGER

  constructor(public coreService: CoreService, public router: Router) { }


}
