import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Url } from './url.model';
import { SERVER_API_URL } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class UrlsService {
  apiUrl = SERVER_API_URL + '/backoffice/urls';

  constructor(private httpClient: HttpClient) { }

  public getUrls(): Observable<Url[]> {
    return this.httpClient.get<Url[]>(this.apiUrl)
    .pipe(
      catchError(this.errorHandle)
    );
  }

  public deleteUrl(urlId: number): Observable<any> {
    return this.httpClient.delete(this.apiUrl + `/${urlId}`)
    .pipe(
      catchError(this.errorHandle)
    );
  }

  public createUrl(url: Url): Observable<any> {
    const copy = this.convert(url);
    return this.httpClient.post(this.apiUrl, copy)
    .pipe(
      catchError(this.errorHandle)
    );
  }

  public errorHandle(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }

  private convert(url: Url) {
    return Object.assign({}, url);
  }
}
