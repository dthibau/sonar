import { UrlsService } from './urls.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UrlsComponent } from './urls.component';
import { PaginationComponent } from './pagination/pagination.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { CreateModalComponent } from './create-modal/create-modal.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [UrlsComponent, PaginationComponent, CreateModalComponent],
  imports: [
    CommonModule,
    FontAwesomeModule,
    ReactiveFormsModule
  ],
  providers: [UrlsService],
  exports: [UrlsComponent]
})
export class UrlsModule { }
