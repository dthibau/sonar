import { AccountsService } from './accounts.service';
import { CookieService } from 'ngx-cookie-service';
import { Component, OnInit } from '@angular/core';
import { faLock, faUnlock, faPenSquare } from '@fortawesome/free-solid-svg-icons';
import { Account } from 'src/app/core/core.model';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss']
})
export class AccountsComponent implements OnInit {
  displayLocked = false;
  faLock = faLock;
  faUnlock = faUnlock;
  faPenSquare = faPenSquare;
  filteredAccounts: Account[];
  error = '';
  accounts: Account[];
  currentAccount: Account;
  constructor(public accountsService: AccountsService) { }

  ngOnInit() {
    this.loadAccounts();
  }
 

  setCurrentAccount(account: Account) {
    this.currentAccount = account;
  }

  lockAccount(id: number) {
    if (confirm('Voulez-vous vraiment supprimer ce compte ?')) {
      this.accountsService.deleteAccount(id).subscribe(() => {
        this.loadAccounts();
      });
    }
  }

  unlockAccount(account: Account) {
    account.deleteddate = null;
    this.accountsService.updateAccount(account).subscribe(() => {
      this.loadAccounts();
    })
  }

  addAccount(account) {
    this.accountsService.createAccount(account).subscribe(() => {
      this.loadAccounts();
    });
  }

  updateAccount(account) {
    this.accountsService.updateAccount(account).subscribe(() => {
      this.loadAccounts();
    });
  }

  updateLockDisplay() {
    this.displayLocked = !this.displayLocked;
    this.loadAccounts();
  }

  loadAccounts() {
    this.accountsService.getAccounts().subscribe((accounts: any) => {
      this.accounts = accounts.map(x => {
        x = { ...x, deleteddate: x.deletedDate };
        delete x.deletedDate;
        return x;
      });
      if (!this.displayLocked) {
        this.accounts = this.accounts.filter(x => !x.deleteddate);
      }
      this.filteredAccounts = this.accounts;
    });
  }



  onSearch(event) {
    const value = event.target.value.toLowerCase();
    if (value) {
      this.filteredAccounts = this.accounts.filter(x => (x.email && x.email.toLowerCase().includes(value))
        || (x.login && x.login.toLowerCase().includes(value)) || (x.prenom && x.prenom.toLowerCase().includes(value))
        || (x.nom && x.nom.toLowerCase().includes(value)) || (x.telephone && x.telephone.toLowerCase().includes(value)));
    } else {
      this.filteredAccounts = this.accounts;
    }
  }



}
