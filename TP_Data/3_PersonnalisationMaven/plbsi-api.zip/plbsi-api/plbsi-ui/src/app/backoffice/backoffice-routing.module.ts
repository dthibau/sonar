import { AccountsComponent } from './accounts/accounts.component';
import { UrlsComponent } from './urls/urls.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { BackofficeComponent } from './backoffice.component';
import { MainNavigationComponent } from '../core/main-navigation.component';
import { CoreService } from '../core/core.service';
import { Observable } from 'rxjs';
import { ROLE_AC_MANAGER, ROLE_MANAGER } from '../app.constants';
import { BackofficeService } from './backoffice.service';



const backofficeRoutes: Routes = [
  { path: 'backoffice',  component: MainNavigationComponent, canActivate: [BackofficeService], pathMatch: 'full' },
  { path: 'backoffice', component: MainNavigationComponent, children: [
    { path: 'urls', component: BackofficeComponent, children: [{ path: '', component: UrlsComponent }] },
    { path: 'accounts', component: BackofficeComponent, children: [{ path: '', component: AccountsComponent }] }
  ] }
];

@NgModule({
  imports: [RouterModule.forChild(backofficeRoutes)],
  exports: [RouterModule]
})
export class BackofficeRoutingModule {}

