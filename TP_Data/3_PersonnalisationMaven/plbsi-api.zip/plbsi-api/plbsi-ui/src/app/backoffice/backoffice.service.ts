import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { ROLE_AC_MANAGER, ROLE_MANAGER } from '../app.constants';
import { CoreService } from '../core/core.service';

@Injectable({
  providedIn: 'root'
})
export class BackofficeService implements CanActivate {

  constructor(public coreService: CoreService, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
    Observable<boolean> | Promise<boolean> | boolean {
    console.log("Back-office routing Can activate")


    if (this.coreService.hasRole(ROLE_MANAGER)) {
      this.router.navigateByUrl('/backoffice/urls')
    } else if (this.coreService.hasRole(ROLE_AC_MANAGER)) {
      this.router.navigateByUrl('/backoffice/accounts')
    }


    return true;
  }

}
