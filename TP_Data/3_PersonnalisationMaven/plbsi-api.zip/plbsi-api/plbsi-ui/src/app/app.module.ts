import { CmsModule } from './cms/cms.module';
import { BackofficeModule } from './backoffice/backoffice.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreService } from './core/core.service';
import { MainNavigationComponent } from './core/main-navigation.component';
import { OffreModule } from './offre/offre.module';
import { LoginModalComponent } from './core/login.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [
    AppComponent,
    MainNavigationComponent,
    LoginModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CmsModule,
    BackofficeModule,
    OffreModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgbModule
  ],
  entryComponents: [
    LoginModalComponent,
  ],
  exports: [LoginModalComponent],
  providers: [CookieService, CoreService],
  bootstrap: [AppComponent]
})
export class AppModule { }
