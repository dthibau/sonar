import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpParams, HttpHeaders } from '@angular/common/http';


import { LoggedUser, Kibana, Account } from './core.model';
import { Observable } from 'rxjs';
import { ROLES, SERVER_API_URL } from '../app.constants';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate } from '@angular/router';


@Injectable()
export class CoreService implements CanActivate {

    loggedUser: LoggedUser;

    constructor(private http: HttpClient, private router: Router ) { }

    setLoggedUser() {
      console.log("setLoggedUser")
      this.http.get<LoggedUser>(`${SERVER_API_URL}/loggeduser`).subscribe((lu: LoggedUser) => {
        this.initLoggedUser(lu)
      } );
    }
    getLoggedUser() {
        return this.http.get<LoggedUser>(`${SERVER_API_URL}/loggeduser`);
    }
    getKibana() {
      return this.http.get<Kibana>(`${SERVER_API_URL}/kibana`);
  }

  login(username: string, password: string): Observable<{}> {
    console.log('usename='+username + ' password='+password );
    const data =
      `username=${encodeURIComponent(username)}` +
      `&password=${encodeURIComponent(password)}` +
      '&submit=Login';

    const headers = new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded');

    return this.http.post('/api/authentication', data, { headers });
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
  Observable<boolean>|Promise<boolean>|boolean {
    console.log("Can activate")

        if ( this.hasRole('AC_MANAGER') ) {
          this.router.navigateByUrl('/backoffice')
        } else {
          this.router.navigateByUrl('/offre/formations')      
        }


      return true;
  }

  hasRole(role: string) : boolean {
    return this.loggedUser && this.loggedUser.currentRole == role;
  }

  hasOneOfRoles(roles: string[]) : boolean {
    let ret = false;
    roles.forEach( r => {
      ret = ret || this.hasRole(r);
    } );

    return ret;
  }

  setCurrentRole(role: string) : boolean {
    console.log("Set current role " + role);
    if ( this.loggedUser.authorities.includes(role) ) 
      this.loggedUser.currentRole = role
    return false;
  }

  otherRoles() : string[] {
    let other  = Object.assign([], this.loggedUser.authorities);
    other.forEach((element,index)=>{
      if(element==this.loggedUser.currentRole) 
        other.splice(index,1);
   });
   return other;

  }

  getAccounts(role: string) {
    return this.http.get<Account[]>(`${SERVER_API_URL}/backoffice/accounts/role?role=${role}`);

  }
  private initLoggedUser(lu: LoggedUser) {
    console.log("initLoggedUser " + lu)
    this.loggedUser = lu;
    this.loggedUser.currentRole = this.loggedUser.authorities[0]
    if ( this.hasRole('MANAGER') ) { // Adding all roles for MANAGER
      ROLES.forEach(role => {
        if ( !this.loggedUser.authorities.includes(role) ) 
          this.loggedUser.authorities.push(role)
      })
    }
  }
}
