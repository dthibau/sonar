import { resolveSanitizationFn } from '@angular/compiler/src/render3/view/template';

export class LoggedUser {
    login: string;
    authorities: string[];
    currentRole: string
  }

  export class Account {
    public id: number;
    public email: string;
    public login: string;
    public password: string;
    public roles: string;
    public nom: string;
    public prenom: string;
    public telephone: string;
    public deleteddate: Date;
    public nomComplet: string
  }

  export interface Kibana {
    url: string
  }