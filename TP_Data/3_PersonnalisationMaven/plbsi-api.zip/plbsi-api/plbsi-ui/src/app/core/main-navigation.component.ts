import { Component, OnInit } from '@angular/core';
import { ROLE_AC_MANAGER, ROLE_MANAGER, ROLE_TB_MANAGER } from '../app.constants';
import { Kibana } from './core.model';
import { CoreService } from './core.service';
import { LoginModalService } from './login-modal.service';

@Component({
  selector: 'app-main-navigation',
  templateUrl: './main-navigation.component.html',
  styleUrls: ['./main-navigation.component.scss']
})
export class MainNavigationComponent implements OnInit {

  kibana: Kibana;

  ROLE_MANAGER = ROLE_MANAGER;
  ROLE_AC_MANAGER = ROLE_AC_MANAGER
  ROLE_TB_MANAGER = ROLE_TB_MANAGER
  
  constructor(public coreService: CoreService, private loginModalService: LoginModalService) { }

  ngOnInit() {
    this.coreService.getKibana().subscribe(
      (kibana: Kibana) => this.kibana = { ...kibana }
    )

  }

  login(): void {
    this.loginModalService.open();
  }
}
