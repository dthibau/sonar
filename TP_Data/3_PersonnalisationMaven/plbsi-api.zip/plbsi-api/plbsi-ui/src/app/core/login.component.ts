import { Component, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { CoreService } from './core.service';


@Component({
  selector: 'app-login-modal',
  templateUrl: './login.component.html',
})
export class LoginModalComponent implements AfterViewInit {
  @ViewChild('username', { static: false })
  username?: ElementRef;

  authenticationError = false;

  loginForm = this.fb.group({
    username: [''],
    password: [''],
    rememberMe: [false],
  });

  constructor(private coreService: CoreService, private router: Router, public activeModal: NgbActiveModal, private fb: FormBuilder) {}

  ngAfterViewInit(): void {
    if (this.username) {
      this.username.nativeElement.focus();
    }
  }

  cancel(): void {
    this.authenticationError = false;
    this.loginForm.patchValue({
      username: '',
      password: '',
    });
    this.activeModal.dismiss('cancel');
  }

  login(): void {
    this.coreService
      .login(
         this.loginForm.get('username')!.value,
        this.loginForm.get('password')!.value
      )
      .subscribe(
        () => {
          this.authenticationError = false;
          this.activeModal.close();

            this.router.navigate(['']);

        },
        () => {this.authenticationError = false;
          this.activeModal.close();

            this.router.navigate(['']);}
      );
  }


}
