import { Component, ElementRef, EventEmitter, Input, OnInit, Output, Self, ViewChild } from '@angular/core';
import { AbstractControl, ControlValueAccessor, NgControl, ValidationErrors, Validator, Validators } from '@angular/forms';
import { FormControlName } from '@angular/forms';

@Component({
  selector: 'app-required-field',
  templateUrl: './required-field.component.html',
  styleUrls: ['./required-field.component.scss'],
  providers: [FormControlName],
  styles: [`
  :host {
      border-left-style:none !important;
  }`]
})
export class RequiredFieldComponent implements OnInit, ControlValueAccessor, Validator {
  @Input() label: string;
  @Input() requiredMsg: string;
  @Input() cols; // Nbre de colonne prise par la zone de saisie

  @ViewChild('input', { static: false }) input: ElementRef<HTMLInputElement>;

  @Output() change: EventEmitter<string> = new EventEmitter();

  onChange = (value) => { };
  onTouched = () => { };
  touched = false;
  disabled = false;
  value: string;
  id: string;
  class: string

  constructor(@Self() public controlDir: FormControlName) {
    controlDir.valueAccessor = this;

  }

  ngOnInit() {
    const control = this.controlDir.control;
    let validators = control.validator ? [control.validator, Validators.required] : Validators.required
    control.setValidators(validators);
    control.updateValueAndValidity();
    console.log("cols ="+this.cols)
    if (this.cols == undefined) {
      this.cols = 10;
    }
    this.updateClass();

  }
  updateClass(): void {
    const control = this.controlDir.control;
    this.class = `form-control col-sm-${this.cols}`
    if (control.touched) {
      this.class += ' ng-touched';
    }
    if (control.pristine) {
      this.class += ' ng-pristine';
    }
    if (control.invalid) {
      this.class += ' ng-invalid';
    }
    if ( this.change != null ) {
      this.change.emit(control.value);
    }
  }
  ngAfterViewInit(): void {
    this.input.nativeElement.value = this.value;
  }
  writeValue(value: string) {
    this.value = value;
    if (this.input != undefined) {
      this.input.nativeElement.value = value;

    }
  }

  registerOnChange(onChange: any) {
    this.onChange = onChange;
  }

  registerOnTouched(onTouched: any) {
    this.onTouched = onTouched;
  }

  markAsTouched() {
    if (!this.touched) {
      this.onTouched();
      this.touched = true;
    }
  }

  setDisabledState(disabled: boolean) {
    this.disabled = disabled;
  }

  validate(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (value.length == 0) {
      return {
        required: {
          value
        }
      };
    }
  }
}
