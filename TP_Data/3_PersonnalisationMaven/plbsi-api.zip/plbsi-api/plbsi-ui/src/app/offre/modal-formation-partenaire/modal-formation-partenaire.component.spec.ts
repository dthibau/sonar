import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalFormationPartenaireComponent } from './modal-formation-partenaire.component';

describe('ModalFormationPartenaireComponent', () => {
  let component: ModalFormationPartenaireComponent;
  let fixture: ComponentFixture<ModalFormationPartenaireComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalFormationPartenaireComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalFormationPartenaireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
