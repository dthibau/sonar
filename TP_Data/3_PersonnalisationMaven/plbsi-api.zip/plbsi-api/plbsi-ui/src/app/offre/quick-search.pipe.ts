import { Pipe, PipeTransform } from '@angular/core';
import { FilterableItem, Formation } from './offre.model';

@Pipe({
  name: 'quickSearch'
})
export class QuickSearchPipe implements PipeTransform {

  transform(items: FilterableItem[], searchText: string, filterMetadata: any): FilterableItem[] {
    
    let filteredItems;
    if (!items) { 
      filteredItems = []
    } else if (!searchText) {
      filteredItems =items; 
    } else {
      searchText = searchText.toLowerCase();
      filteredItems = items.filter((it: FilterableItem) => {
        return it.filterString().includes(searchText);
      });
    }

    filterMetadata.count = filteredItems.length;
    return filteredItems;
  }

}
