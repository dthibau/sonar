import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SortableFormationListComponent } from './sortable-formation-list.component';

describe('SortableFormationListComponent', () => {
  let component: SortableFormationListComponent;
  let fixture: ComponentFixture<SortableFormationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SortableFormationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SortableFormationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
