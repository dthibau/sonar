import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AlertService } from 'src/app/app-common/alert.service';
import { ApplyForm, CKMODEL } from 'src/app/app.constants';
import { Filiere } from '../offre.model';
import { OffreService } from '../offre.service';
import * as CustomCKEditor from '../../../ckeditor_custom/ckeditor';

@Component({
  selector: 'app-filiere-detail',
  templateUrl: './filiere-detail.component.html',
  styleUrls: ['./filiere-detail.component.scss'],
})
export class FiliereDetailComponent implements OnInit, ApplyForm {

  filiereForm: FormGroup;
  filiere: Filiere;
  filieres: Filiere[];

  filiereId: number;

  isSaving: boolean;
  isApplying: boolean;

  public Editor = CustomCKEditor;
  public ckModel = CKMODEL;


  constructor(
    private fb: FormBuilder,
    private offreService: OffreService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.ckModel.config.autosave.save = editor => this.saveEditorData(editor.getData()); 

    this.route.paramMap.subscribe((params: ParamMap) => {
      this.filiereId = +params.get('id');
      if (this.filiereId !== 0) {
        this.offreService.findFiliere(this.filiereId).subscribe(
          (res: Filiere) => {
            this.filiere = res;
            console.log('Filiere ' + this.filiere);
            this.createForm();
          });
      } else {
        this.filiere = new Filiere();
        this.createForm();
      }
      this.offreService.getFilieres().subscribe(
        (res: Filiere[]) => { 
          this.filieres = res;
          this.filieres.filter(f => f.id !== this.filiere.id )
        }
      )
    });
  }

  public createForm() {
    this.filiereForm = this.fb.group({
      libelle: [this.filiere.libelle],
      titre: [this.filiere.titre],
      miniDescription: [this.filiere.miniDescription],
      url: [this.filiere.url],
      description: [this.filiere.description],
      metaTitre: [this.filiere.metaTitre],
      metaDescription: [this.filiere.metaDescription],
      metaKeywords: [this.filiere.metaKeywords],
      ordre: [this.filiere.ordre],
      color: [this.filiere.color, Validators.required],
      colorTitre: [this.filiere.colorTitre, Validators.required],
    });
  }

  public remove() {
    this.offreService.deleteFiliere(this.filiere.id).subscribe(() => this.onRemoveSuccess()); 
  }
  public isRemoveEnabled() {
    return this.filiere.categories ? this.filiere.categories.length == 0 : false;
  }
  public saveEditorData(editorData) {
    if (this.filiere.id !== undefined && this.filiere.id !== 0) {
      this.filiere.description = editorData;
      this.offreService.updateFiliere(this.filiere).subscribe();
    }
  }
  public applyForm() {
    console.log("Apply Form");
    this.doSave();
    this.isApplying = true;
  }
  public save() {
    this.doSave();
    this.isSaving = true;
  }
  private doSave() {
    this.filiere = this.filiereForm.value;
    console.log('Id ' + this.filiereId);
    if (!this.filiereId) {
      this.subscribeToSaveResponse(
        this.offreService.createFiliere(this.filiere));
    } else {
      this.filiere.id = this.filiereId;
      this.subscribeToSaveResponse(
        this.offreService.updateFiliere(this.filiere));
    }
  }
  private subscribeToSaveResponse(result: Observable<Filiere>) {
    result.subscribe((filiere: Filiere) =>
      this.onSaveSuccess(filiere), (res: HttpErrorResponse) => this.onSaveError());
  }

  private onSaveSuccess(result: Filiere) {
    this.filiere = result;
    this.filiereId = this.filiere.id;
    this.alertService.success('Modification enregistrée');
    if ( this.isSaving ) {
      this.isSaving = false;
      this.router.navigate(['offre/filieres']);  
    } else {
      this.isApplying = false;
    }
  }

  private onRemoveSuccess() {
    console.log('on Remove success');
    this.alertService.success('Filière supprimée');
    this.router.navigate(['offre/filieres'])
  }

  private onSaveError() {
    console.log('save failed');
  }

  public updateLibelle(value) {
    
    const libelle = this.filiereForm.get('libelle').value;
    if ( libelle ) {
      if ( !this.filiereForm.get('metaTitre').value ) {
        this.filiereForm.get('metaTitre').setValue(`Filière ${libelle}: la liste de nos formations ${libelle} | PLB Consultant`);
      }
      if ( !this.filiereForm.get('metaDescription').value ) {
        this.filiereForm.get('metaDescription').setValue(`Cette filière ${libelle} regroupe l’ensemble de nos formations ${libelle}. Des cours ${libelle} de tous niveaux pour apprendre ou se perfectionner avec PLB.`);
      }
      if ( !this.filiereForm.get('metaKeywords').value ) {
        this.filiereForm.get('metaKeywords').setValue(`${libelle}`);
      }
    }

    
  }
}
