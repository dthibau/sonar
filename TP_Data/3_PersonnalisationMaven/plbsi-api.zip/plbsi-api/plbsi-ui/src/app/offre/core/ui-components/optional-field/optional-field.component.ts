import { Component, ElementRef, Input, OnInit, Self, ViewChild } from '@angular/core';
import { AbstractControl, ControlValueAccessor, FormControlName, ValidationErrors, Validator } from '@angular/forms';

@Component({
  selector: 'app-optional-field',
  templateUrl: './optional-field.component.html',
  styleUrls: ['./optional-field.component.scss'],
  providers : [FormControlName]
})
export class OptionalFieldComponent implements OnInit, ControlValueAccessor, Validator {

  @Input() label: string;
  @Input() requiredMsg: string;
  @Input() cols;
  @Input() labelCols;

  @ViewChild('input', { static: false }) input: ElementRef<HTMLInputElement>;

  onChange = (value) => { };
  onTouched = () => { };
  touched = false;
  disabled = false;
  value: string;
  id: string;
  class: string
  labelClass: string

  constructor(@Self() public controlDir: FormControlName) {
    controlDir.valueAccessor = this;

  }

  ngOnInit() {
    const control = this.controlDir.control;
    control.updateValueAndValidity();
    if (this.cols == undefined) {
      this.cols = 10;
    }
    this.updateClass();
    if ( this.labelCols == undefined ) {
      this.labelCols=2
    }
    this.labelClass = `col-form-label col-sm-${this.labelCols}`;

  }
  updateClass(): void {
    const control = this.controlDir.control;
    this.class = `form-control col-sm-${this.cols}`
    if (control.touched) {
      this.class += ' ng-touched';
    }
    if (control.pristine) {
      this.class += ' ng-pristine';
    }
    if (control.invalid) {
      this.class += ' ng-invalid';
    }
  }
  ngAfterViewInit(): void {
    this.input.nativeElement.value = this.value;
  }
  writeValue(value: string) {
    this.value = value;
    if (this.input != undefined) {
      this.input.nativeElement.value = value;

    }
  }

  registerOnChange(onChange: any) {
    this.onChange = onChange;
  }

  registerOnTouched(onTouched: any) {
    this.onTouched = onTouched;
  }

  markAsTouched() {
    if (!this.touched) {
      this.onTouched();
      this.touched = true;
    }
  }

  setDisabledState(disabled: boolean) {
    this.disabled = disabled;
  }

  validate(control: AbstractControl): ValidationErrors | null {
    return null;
  }

}
