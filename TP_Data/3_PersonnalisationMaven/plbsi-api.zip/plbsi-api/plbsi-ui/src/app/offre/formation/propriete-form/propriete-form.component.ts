import { ThrowStmt } from '@angular/compiler';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertService } from 'src/app/app-common/alert.service';
import { ROLE_MANAGER } from 'src/app/app.constants';
import { CoreService } from 'src/app/core/core.service';
import { FormationService } from '../../formation.service';
import { Categorie, Formation, MinimalFormation, UpdateFormationResponse } from '../../offre.model';
import { OffreService } from '../../offre.service';

@Component({
  selector: 'app-propriete-form',
  templateUrl: './propriete-form.component.html',
  styleUrls: ['./propriete-form.component.scss']
})
export class ProprieteFormComponent implements OnInit {

  @Input()
  formation: Formation
  // Select Catégories
  categories: Categorie[]
  // Select Formations
  formations: MinimalFormation[]
  // Catégorie en cours de tri
  editedCategorie: Categorie
  formationsCategorie: Formation[]
  formationsSorted: boolean
  // Formations Suivantes
  MAX_SUIVANTES = 4
  formationsSuivantes: Formation[]

  ROLE_MANAGER = ROLE_MANAGER

  proprieteForm: FormGroup;

  constructor(private fb: FormBuilder,
    private formationService: FormationService,
    private offreService: OffreService,
    private alertService: AlertService,
    public coreService: CoreService) { }

  ngOnInit() {
    if (this.formation) {
      this._createForm();
      this._resolveFormationsSuivantes();
      this.offreService.getCategories().subscribe(res => {
        this.categories = res;
      })
    } else {
      console.error("Formation not set")
    }
  }


  public checkReference() {

    const reference = this.proprieteForm.get('reference').value;
    if (this.formation.reference !== reference) {
      this.formationService.referenceExist(reference).subscribe(b => {
        if (b) {
          this.alertService.error("La référence existe déjà");
        }
      })
    }

  }
  updateStatut(ufr: UpdateFormationResponse) {
    this.alertService.success(ufr.message);
  }

  public selectCategorie(id: number) {
    this.editedCategorie = this.categories.find(c => c.id == id);
    this.formationService.getFormationsFromCategorie(this.editedCategorie.id).subscribe(fs => {
      this.formationsCategorie = fs;
    })

  }

  // Evt : Une formation de la catégorie a été réordonnée 
  public updateFormations(arg: Formation[]) {
    this.formationsSorted = true;
    this.formationsCategorie = arg;
  }
  // Sauvegarde de l'ordre vers le serveur
  public sortFormations() {
    if (this.formationsSorted) {
      this.formationService.sortFormations(this.editedCategorie.id, this.formationsCategorie).subscribe(it => {
        this.alertService.success("Formations de " + this.editedCategorie.libelle + " réordonnées");
        if (this.editedCategorie.id == this.formation.categorie.id) {
          this._resolveFormationsSuivantes()
        }
        this.editedCategorie = null;
        this.formationsCategorie = null;
        this.formationsSorted = false;
      })
    }
  }
  public updateCategorie() {
    let idCategorie = this.proprieteForm.get('categorieId').value;
    if (idCategorie > 0) {
      this.formationService.updateCategorie(idCategorie, this.formation.idFormation).subscribe(ufr => {
        this.formation.categorie = ufr.formation.categorie
        this.alertService.success("Super : " + ufr.message);
      })
    }
  }
  // Ajout ligne catégorie secondaire dans le formulaire
  public addCategorieSecondaire() {
    if (!this.formation.categoriesSecondaires) {
      this.formation.categoriesSecondaires = new Array()
    }
    this.formation.categoriesSecondaires.push(new Categorie())
    this.proprieteForm.addControl(
      'cs_' + (this.formation.categoriesSecondaires.length - 1), new FormControl('-1', [Validators.required])
    )
  }
  // Màj côté serveur
  public changeCategorieSecondaire(index: number) {
    let idCategorie = this.proprieteForm.get('cs_' + index).value;
    if (this.formation.categoriesSecondaires[index].id > 0) {
      this.formationService.removeCategorieSecondaire(this.formation.categoriesSecondaires[index].id, this.formation.idFormation).subscribe(ufr => {
      })
    }
    this.formationService.addCategorieSecondaire(idCategorie, this.formation.idFormation).subscribe(ufr => {
      this.formation.categoriesSecondaires[index].id = idCategorie
      this.alertService.success(ufr.message);
    })
  }
  // Màj côté serveur
  public removeCategorieSecondaire(index: number) {
    if (this.formation.categoriesSecondaires[index].id > 0) {
      this.formationService.removeCategorieSecondaire(this.formation.categoriesSecondaires[index].id, this.formation.idFormation).subscribe(ufr => {
        this.alertService.success(ufr.message);
        this.formation.categoriesSecondaires.splice(index, 1);

        this.proprieteForm.removeControl('cs_' + index)
      })
    }


  }
  public selectCategorieSecondaire(index: number) {
    let idCategorie = this.proprieteForm.get('cs_' + index).value;
    if (idCategorie !== -1) {
      this.selectCategorie(idCategorie)
    }

  }

  public addAssociee() {
    if (!this.formation.associees) {
      this.formation.associees = new Array()
    }
    this.formation.associees.push(new MinimalFormation())

    console.log("AddFormationAssociee : " + this.formation.associees)
    this._resolveFormationsSuivantes();
  }

  public updateAssociee(event: any) {
    let index = event.index 
    let idFormation = event.idFormation
    if (this.formation.associees[index].idFormation > 0) {
      this.formationService.removeFormationAssociee(this.formation.associees[index].idFormation, this.formation.idFormation).subscribe()
    }
    this.formationService.addFormationAssociee(idFormation, this.formation.idFormation).subscribe(
      ufr => {
        this.formation.associees[index].idFormation = idFormation
        this.alertService.success(ufr.message);
      })
  }

  public deleteAssociee(index: number) {
    if (this.formation.associees[index].idFormation > 0) {
      this.formationService.removeFormationAssociee(this.formation.associees[index].idFormation, this.formation.idFormation).subscribe(ufr => {
        this.alertService.success(ufr.message);
      })
    }
    this.formation.associees.splice(index, 1);

    this._resolveFormationsSuivantes();
  }

  private _createForm() {
    console.log('Create Property form for ' + this.formation.reference);
    this.proprieteForm = this.fb.group({
      reference: [this.formation.reference, [Validators.required]],
      libelle: [this.formation.libelle, [Validators.required]],
      visible: [this.formation.visible],
      sousTitre: [this.formation.sousTitre],
      duree: [this.formation.duree],
      categorieId: [this.formation.categorie.id, [Validators.required]],

      prix: [this.formation.prix],
      remise: [this.formation.prix],
      tarifIntra: [this.formation.tarifIntra],
      plbInter: [this.formation.plbInter],
      origine: [this.formation.origine],
      support: [this.formation.support],
      distance: [this.formation.distance],
      elearning: [this.formation.elearning],

      certification: [this.formation.certification],
      coursOfficiel: [this.formation.coursOfficiel],

      niveau: [this.formation.niveau],

      eligibleCpf: [this.formation.eligibleCpf],
      codeCpf: [this.formation.codeCpf],
    });
    this.formation.categoriesSecondaires.forEach((c, i) => {
      this.proprieteForm.addControl(
        'cs_' + i, new FormControl(c.id, [Validators.required])
      )
    })

  }

  _resolveFormationsSuivantes() {
    this.formationsSuivantes = new Array();
    if (this.formation.associees.length < this.MAX_SUIVANTES) {
      this.formationService.getFormationsFromCategorie(this.formation.categorie.id).subscribe(fs => {
        let start = fs.findIndex(f => f.idFormation == this.formation.idFormation);
        for (let i = start + 1; i < fs.length && (i - start) <= this.MAX_SUIVANTES - this.formation.associees.length; i++) {
          this.formationsSuivantes.push(fs[i]);
        }
      })
    }
  }


}
