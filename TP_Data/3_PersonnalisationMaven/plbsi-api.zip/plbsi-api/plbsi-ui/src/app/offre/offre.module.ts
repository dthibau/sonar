import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';



import { NavmenuComponent } from './navmenu/navmenu.component';
import { OffreRoutingModule } from './offre-routing.module';
import { InvendusComponent } from './invendus/invendus.component';
import { OffreComponent } from './offre.component';
import { OffreService } from './offre.service';
import { ZZPipePipe } from './zzpipe.pipe';
import { QuickSearchPipe } from './quick-search.pipe';
import { FilieresComponent } from './filieres/filieres.component';
import { FiliereDetailComponent } from './filiere-detail/filiere-detail.component';
import { FormButtonsComponent } from './core/ui-components/form-buttons/form-buttons.component';
import { RequiredFieldComponent } from './core/ui-components/required-field/required-field.component';
import { AppCommonModule } from '../app-common/app-common.module';
import { CategoriesComponent } from './categories/categories.component';
import { CategorieDetailComponent } from './categorie-detail/categorie-detail.component';
import { OptionalFieldComponent } from './core/ui-components/optional-field/optional-field.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { SmallCategorieListComponent } from './core/ui-components/small-categorie-list/small-categorie-list.component';
import { RequiredSelectFieldComponent } from './core/ui-components/required-select-field/required-select-field.component';
import { FormationsComponent } from './formations/formations.component';
import { YearSessionsEditorComponent } from './year-sessions-editor/year-sessions-editor.component';
import { SafeHtmlPipe } from './safe-html.pipe';
import { FormationComponent } from './formation/formation.component';
import { ProprieteFormComponent } from './formation/propriete-form/propriete-form.component';
import { ReferencementFormComponent } from './formation/referencement-form/referencement-form.component';
import { WebFormComponent } from './formation/web-form/web-form.component';
import { HistoriqueComponent } from './formation/historique/historique.component';
import { CreateFormationComponent } from './create-formation/create-formation.component';
import { SortableFormationListComponent } from './core/ui-components/sortable-formation-list/sortable-formation-list.component';
import { CommerceFormComponent } from './formation/commerce-form/commerce-form.component';
import { ModalStatutComponent } from './modal-statut/modal-statut.component';
import { SelectFormationsComponent } from './select-formations/select-formations.component';
import { ModalFormationPartenaireComponent } from './modal-formation-partenaire/modal-formation-partenaire.component';


@NgModule({
  declarations: [OffreComponent,
    NavmenuComponent,
    InvendusComponent,
    ZZPipePipe,
    QuickSearchPipe,
    SafeHtmlPipe,
    FilieresComponent,
    FiliereDetailComponent,
    FormButtonsComponent,
    RequiredFieldComponent,
    CategoriesComponent,
    CategorieDetailComponent,
    OptionalFieldComponent,
    SmallCategorieListComponent,
    RequiredSelectFieldComponent,
    FormationsComponent,
    YearSessionsEditorComponent,
    FormationComponent,
    ProprieteFormComponent,
    ReferencementFormComponent,
    WebFormComponent,
    HistoriqueComponent,
    CreateFormationComponent,
    SortableFormationListComponent,
    CommerceFormComponent,
    ModalStatutComponent,
    SelectFormationsComponent,
    ModalFormationPartenaireComponent],
  imports: [
    AppCommonModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CKEditorModule,
    OffreRoutingModule
  ],
  providers: [OffreService]
})
export class OffreModule { }
