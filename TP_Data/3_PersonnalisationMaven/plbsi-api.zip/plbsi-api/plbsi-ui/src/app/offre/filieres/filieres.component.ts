import { Component, OnInit } from '@angular/core';
import { Filiere } from '../offre.model';
import { OffreService } from '../offre.service';

@Component({
  selector: 'app-filieres',
  templateUrl: './filieres.component.html',
  styleUrls: ['./filieres.component.scss']
})
export class FilieresComponent implements OnInit {

  filieres: Filiere[];

  constructor(private offreService: OffreService) { 

  }

  ngOnInit() {
    this.offreService.getFilieres().subscribe(
      (res: Filiere[]) => this.filieres = res
    )
  }

}
