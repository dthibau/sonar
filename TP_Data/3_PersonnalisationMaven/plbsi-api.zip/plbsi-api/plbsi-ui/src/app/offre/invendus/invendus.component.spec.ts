import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvendusComponent } from './invendus.component';

describe('InvendusComponent', () => {
  let component: InvendusComponent;
  let fixture: ComponentFixture<InvendusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvendusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvendusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
