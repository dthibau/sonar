import { AfterViewInit, Component, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { AlertService } from 'src/app/app-common/alert.service';
import { ROLE_MANAGER } from 'src/app/app.constants';
import { CoreService } from 'src/app/core/core.service';
import { FormationService } from '../formation.service';
import { Categorie, Formation } from '../offre.model';
import { OffreService } from '../offre.service';
import { CommerceFormComponent } from './commerce-form/commerce-form.component';
import { ProprieteFormComponent } from './propriete-form/propriete-form.component';
import { ReferencementFormComponent } from './referencement-form/referencement-form.component';
import { WebFormComponent } from './web-form/web-form.component';

@Component({
  selector: 'app-formation',
  templateUrl: './formation.component.html',
  styleUrls: ['./formation.component.scss']
})
export class FormationComponent implements OnInit, AfterViewInit {
  ROLE_MANAGER = ROLE_MANAGER

  formation : Formation;

  @ViewChildren(ProprieteFormComponent) 
  private queryProprieteFormComponent : QueryList<ProprieteFormComponent>;
  private proprieteFormComponent : ProprieteFormComponent

  @ViewChildren(CommerceFormComponent) 
  private queryCommerceFormComponent : QueryList<CommerceFormComponent>;
  private commerceFormComponent : CommerceFormComponent

  @ViewChildren(ReferencementFormComponent) 
  private queryReferencementFormComponent : QueryList<ReferencementFormComponent>;
  private referencementFormComponent : ReferencementFormComponent

  @ViewChildren(WebFormComponent) 
  private queryWebFormComponent : QueryList<WebFormComponent>;
  private webFormComponent : WebFormComponent

  constructor(
    private coreService: CoreService,
    private formationService: FormationService,
    private alertService: AlertService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(p => {
      const idFormation = p.get('id')
      console.log("idFormation="+idFormation)
      if (idFormation) {
        this.formationService.getFormation(+idFormation).subscribe( f =>
          this.formation = f
        );
      }
    })
    
  }

  isFormValid() : boolean {
    return this.proprieteFormComponent != null 
    && this.commerceFormComponent != null 
    && this.referencementFormComponent != null 
    && this.proprieteFormComponent.proprieteForm.valid && 
    this.commerceFormComponent.commerceForm.valid &&
    this.referencementFormComponent.referencementForm.valid
  }
  save() : boolean {
    let formation = {
      ...this.proprieteFormComponent.proprieteForm.value,
      ...this.commerceFormComponent.commerceForm.value,
      ...this.referencementFormComponent.referencementForm.value,
      ...this.webFormComponent.publicationForm.value
    }
    formation.idFormation = this.formation.idFormation
    formation.visible = formation.visible ? 'oui' : 'non' 
    console.log("Save ="+JSON.stringify(formation))
    this.formationService.patchFormation(formation).subscribe(ufr => {
      const msg = ufr.message.length > 0 ? 'Super '+ ufr.message : 'Super, Mais aucune modification'
      this.alertService.success(msg)
    })

    return false
  }

  ngAfterViewInit() {
    this.queryProprieteFormComponent.changes.subscribe((comps: QueryList<ProprieteFormComponent>) =>
    {
      this.proprieteFormComponent = comps.first
      console.log("After view Init="+this.proprieteFormComponent)
    });
    this.queryCommerceFormComponent.changes.subscribe((comps: QueryList<CommerceFormComponent>) =>
    {
      this.commerceFormComponent = comps.first
      console.log("After view Init="+this.commerceFormComponent)
    });
    this.queryReferencementFormComponent.changes.subscribe((comps: QueryList<ReferencementFormComponent>) =>
    {
      this.referencementFormComponent = comps.first
      console.log("After view Init="+this.referencementFormComponent)
    });
    this.queryWebFormComponent.changes.subscribe((comps: QueryList<WebFormComponent>) =>
    {
      this.webFormComponent = comps.first
      console.log("After view Init="+this.webFormComponent)
    });
   
  }

}
