import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequiredSelectFieldComponent } from './required-select-field.component';

describe('RequiredSelectFieldComponent', () => {
  let component: RequiredSelectFieldComponent;
  let fixture: ComponentFixture<RequiredSelectFieldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequiredSelectFieldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequiredSelectFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
