import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmallCategorieListComponent } from './small-categorie-list.component';

describe('SmallCategorieListComponent', () => {
  let component: SmallCategorieListComponent;
  let fixture: ComponentFixture<SmallCategorieListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmallCategorieListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmallCategorieListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
