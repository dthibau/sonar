import { Component, OnInit } from '@angular/core';
import { Categorie } from '../offre.model';
import { OffreService } from '../offre.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit {

  categories: Categorie[];

  searchText: string;
  filterMetadata = { count: 0 };

  constructor(private offreService: OffreService) { 
  }

  ngOnInit() {
    this.offreService.getCategories().subscribe(
      (res: Categorie[]) => this.categories = res);
  }

}
