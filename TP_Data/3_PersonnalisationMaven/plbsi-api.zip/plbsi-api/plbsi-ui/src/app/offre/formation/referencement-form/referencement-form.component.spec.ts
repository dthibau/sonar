import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferencementFormComponent } from './referencement-form.component';

describe('ReferencementFormComponent', () => {
  let component: ReferencementFormComponent;
  let fixture: ComponentFixture<ReferencementFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReferencementFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReferencementFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
