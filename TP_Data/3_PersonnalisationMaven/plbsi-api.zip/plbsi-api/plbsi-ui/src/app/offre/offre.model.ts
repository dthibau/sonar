import { Account } from "../core/core.model"

/* 
* Contrat utilisé par le "quicksearch" pipe
*/
export declare interface FilterableItem {
  filterString(): string;
}

/* 
* Contrat utilisé par le "select fields"
*/
export declare interface SelectableItem {
  id: number;

  getLibelle(): string;
  getId(): number;
}

/* 
* Contrat utilisé par le "small-categorie-component" 
*/
export declare interface SmallCategorieView {
  getLibelle(): string;
  getId(): number
  getRang(): number
}
export class PageFormation {
  totalPages: number
  totalElements: number
  size: number
  noPage : number
  content: Formation[]
}
export class MinimalFormation {
  idFormation: number
  reference: string
  libelle: string
}
export class Formation implements FilterableItem {
  idFormation: number
  reference: string
  libelle: string
  duree : number
  motClePrimaire: string
  url: string
  baliseKeywords: string
  baliseDescription: string
  baliseTitle: string
  campagneAdwords: string
  urlPlb: string
  dateCreation: string
  filiereLibelle: string
  categorieLibelle: string
  autresCategories : string[]
  categoriesSecondaires: Categorie[]  
  autresFilieres: string[]
  formationsPartenaire : FormationPartenaire[]
  nextSessionsByOrganismes : SessionOrganismes[]
  allSessionsByOrganismes: SessionOrganismes[]
  prix : number
  remise: string
  visible: string
  plbInter: boolean
  origine: string
  support: boolean
  distance: string
  elearning: boolean
  certification: string
  coursOfficiel: string
  niveau: string
  eligibleCpf: boolean
  codeCpf: string
  type: string
  tarifIntra: string
  statut: string
  currentManager: Account
  remarques: string
  blocCommercialisation: string
  blocIntra: string
  blocArgumentaire: string
  blocCertification: string
  blocCpf: string
  mutualisees: MinimalFormation[]
  associees: MinimalFormation[]
  actionCo: boolean
// Formulaire propriété  
  sousTitre: string
  categorie: Categorie
  descriptif: string
  objectifs_operationnels: string
  objectifs_pedagogiques: string
  prerequis: string
  participants: string
  travauxPratiques: string
  description: string
  contenu: string
  moyensPedagogiques: string
  modalitesSuivi: string
  // Formulaire publication
  nouveaute: string
  top10: number
  libelleTop10: string
  // Formulaire commerce
  coursPlbCataloguePartenaire: string
  autreObjectifSimple: string

  
  

  getTarif() : string {
    return this.prix != 0 ? this.prix.toLocaleString(
      undefined, // leave undefined to use the visitor's browser 
             // locale or a string like 'en-US' to override it.
      { minimumFractionDigits: 2 }
    ) + " €" : "Intra"
  }
  getClass() : string {
    return this.visible + (this.plbInter ? ' plb' : '')
  }
  filterString() : string {
    return this.reference.toLowerCase() + this.libelle.toLowerCase() + this.dateCreation +
    this.filiereLibelle.toLowerCase() + this.categorieLibelle.toLowerCase()
  }

}
export class FormationFilter {
  q: string
  moreResult: boolean
  filiereId: number
  categorieId: number
  excluPLB: boolean
  partenaireId: number
  sortColumn: string
  sortOrder: string
  page : number
  size: number
  archived: boolean
}
export class FormationPager {
  previousPages: boolean
  nextPages: boolean
  minPage: number
  maxPage: number
  availablePages() : Array<number> {
    let ret = new Array();
    for ( let i = this.minPage; i <= this.maxPage; i++ )
      ret.push(i);
    return ret;
  }
}
export class FormationPartenaire {
  id: number
  nom: string
  url: string
  reference: string
  prix: string
}

export class Partenaire {
  id: number
  nom: string
  web: string
  remise: number
}

// Lecture
export class SessionOrganismes {
  lieuxOrganismes: LieuOrganisme[]
  debut: string
  fin: string

  getLieux() : string {
    let ret = "[";
    let bFirst = true;
    this.lieuxOrganismes.forEach(lo => {
      if ( !bFirst ) {
        ret += ",";
      } else {
        bFirst = false;
      }
      if ( lo.sessionLieu ) {
        ret += lo.organisme + "/" + lo.sessionLieu.nom
      } else {
        ret += lo.organisme;
      }
    })
    ret += "]"
    return ret;
  }
}
export class LieuOrganisme {
  organisme: string;
  sessionLieu: SessionLieu;

  getLieu() : string {
    return this.sessionLieu ? this.sessionLieu.nom : this.organisme
  }
}
export class SessionLieu {
  id: string;
  nom: string;
  adresse: string;
}
export class PartenaireLieu {
  partenaire: Partenaire
  lieux: SessionLieu[]
}

// Maj de sessions par tableau mensuel
export class Session {
  debut: string
  fin: string
}
export class MonthSessions {
  sessions: Session[]
}
export class SessionDto {
  lieuOrganisme: LieuOrganisme
  monthSessions: MonthSessions[]

  constructor() {
    this.monthSessions = new Array(12);
  }
}
export class UpdateFormationResponse {
  formation: Formation
  message: string
}
export class Filiere implements SelectableItem {
  id: number
  libelle: string
  url: string
  ordre: number
  color: string
  colorTitre: string
  description: string
	titre: string
  metaTitre: string
  metaDescription: string
  metaKeywords: string
  miniDescription: string
  categories: Categorie[]

  getLibelle(): string {
    return this.libelle
  }
  getId(): number {
    return this.id
  }
}

export class Categorie implements FilterableItem, SelectableItem, SmallCategorieView {
  id: number
  libelle: string
  filiere: Filiere
  rang: number
  url: string
  description: string
  metaTitre: string
  metaDescription: string
  metaKeywords: string
  miniDescription: string
  categoriesConnexes: CategorieConnexe[]

  filterString() : string {
    return this.libelle.toLowerCase() + this.filiere.libelle.toLowerCase() + this.rang;
  }
  getLibelleComplet(): string {
    return this.libelle + " (" + this.filiere.libelle + ")"
  }
  getLibelle(): string {
    return this.libelle
  }
  getId(): number {
    return this.id
  }
  getRang(): number {
    return this.rang
  }
}

export class CategorieConnexe implements SmallCategorieView {
  id: number
  linkedId: number
  linkedLibelle: string
  linkedRang: number
  order: number

  getLibelle(): string {
    return this.linkedLibelle
  }
  getId(): number {
    return this.linkedId
  }
  getRang(): number {
    return this.linkedRang
  }


}


  export class Invendus {
    total: number
    lastLookUp: string
    formations: Formation[]
  }