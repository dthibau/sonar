import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CKMODEL } from 'src/app/app.constants';
import { Formation } from '../../offre.model';

import * as CustomCKEditor from '../../../../ckeditor_custom/ckeditor';


@Component({
  selector: 'app-web-form',
  templateUrl: './web-form.component.html',
  styleUrls: ['./web-form.component.scss']
})
export class WebFormComponent implements OnInit {

  @Input()
  formation: Formation


  publicationForm: FormGroup;

  editedBloc: string

  public Editor = CustomCKEditor;

  public ckModel = CKMODEL;
  public editorSingle: any;
  public editorDouble1: any;
  public editorDouble2: any;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this._createForm();
  }


  onReadySingle(editor) {
    this.editorSingle = editor;
    if (this.formation) {
      console.log("editor" + this.editorSingle)
      this.editorSingle.setData(this.formation.descriptif)
    }
  }
  onReadyDouble1(editor) {
    this.editorDouble1 = editor;
  }
  onReadyDouble2(editor) {
    this.editorDouble2 = editor;
  }

  selectObjectifs(): boolean {
    this.editorDouble1.setData(this.formation.objectifs_operationnels)
    this.editorDouble2.setData(this.formation.objectifs_pedagogiques)
    return false
  }
  selectPrerequisParticipants(): boolean {
    this.editorDouble1.setData(this.formation.prerequis)
    this.editorDouble2.setData(this.formation.participants)
    return false
  }

  selectTravauxPratiques(): boolean {
    console.log("TP")
    this.editorSingle.setData(this.formation.travauxPratiques != null ? this.formation.travauxPratiques : '')
    return false
  }
  selectDescription(): boolean {
    this.editorSingle.setData(this.formation.description != null ? this.formation.description : '')
    return false
  }
  selectContenu(): boolean {
    this.editorSingle.setData(this.formation.contenu)
    return false
  }
  selectMoyensModalites(): boolean {
    this.editorDouble1.setData(this.formation.moyensPedagogiques)
    this.editorDouble2.setData(this.formation.modalitesSuivi)
    return false
  }

  private _createForm() {
    this.publicationForm = this.fb.group({
      nouveaute: [this.formation.nouveaute],
      top10: [this.formation.top10],
      libelleTop10: [this.formation.libelleTop10]
    })
  }


}
