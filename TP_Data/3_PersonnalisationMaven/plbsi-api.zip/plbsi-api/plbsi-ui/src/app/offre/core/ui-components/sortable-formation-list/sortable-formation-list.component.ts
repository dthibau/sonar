import { Component, Input, OnInit, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Formation } from '../../../offre.model';

@Component({
  selector: 'app-sortable-formation-list',
  templateUrl: './sortable-formation-list.component.html',
  styleUrls: ['./sortable-formation-list.component.scss']
})
export class SortableFormationListComponent implements OnInit {

  @Input()
  formations : Formation[]

  @Output() change: EventEmitter<Formation[]> = new EventEmitter();
  
  constructor() { }

  ngOnInit() {
  }

  isFirst(id: number) : boolean {
    return this.formations[0].idFormation == id;
  }

  isLast(id: number): boolean {
    return this.formations[this.formations.length-1].idFormation == id;
  }

  monter(id: number) : boolean {
    const selectedIndex = this.formations.findIndex(f => f.idFormation == id);
    // Swap
    [this.formations[selectedIndex-1],this.formations[selectedIndex]] = [this.formations[selectedIndex],this.formations[selectedIndex-1]]
    this.change.emit(this.formations)
    return false;
  }


  descendre(id: number) : boolean {
    const selectedIndex = this.formations.findIndex(f => f.idFormation == id);
    // Swap
    [this.formations[selectedIndex],this.formations[selectedIndex+1]] = [this.formations[selectedIndex+1],this.formations[selectedIndex]]
    this.change.emit(this.formations)
    return false;
  }
}
