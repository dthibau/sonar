import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/app-common/alert.service';
import { FormationService } from '../formation.service';
import { Categorie, Formation } from '../offre.model';
import { OffreService } from '../offre.service';

@Component({
  selector: 'app-create-formation',
  templateUrl: './create-formation.component.html',
  styleUrls: ['./create-formation.component.scss']
})
export class CreateFormationComponent implements OnInit {

  formation: Formation

  categories: Categorie[]


  createForm : FormGroup;

  constructor(private fb: FormBuilder,
              private formationService: FormationService,
              private offreService: OffreService,
              private alertService: AlertService,
              private router: Router) { }

  ngOnInit() {
    this.formation = new Formation();
    this._createForm();
    
    this.offreService.getCategories().subscribe(res => {
      this.categories = res;
    })
    
  }
  public checkReference() {
    console.log(this.checkReference)
    const reference = this.createForm.get('reference').value;
    this.formationService.referenceExist(reference).subscribe(b => {
      if ( b && this.createForm.get('reference').valid ) {
        this.createForm.get('reference').setErrors({'incorrect': true})
        this.alertService.error("La référence existe déjà");
      }
    })
  }
  public save() {
    this._populateForm()
    this.formationService.createFormation(this.formation).subscribe(f => {
      this.formation = f;
      this.alertService.success("Formation sauvegardée");
      this.router.navigate(['offre/formation/'+this.formation.idFormation]);  
      
    })
  }
  private _createForm() {
    console.log('Create Creation form for ' + this.formation.reference);
    this.createForm = this.fb.group({
      reference: [this.formation.reference, [Validators.required, Validators.maxLength(10),  Validators.minLength(4)]],
      libelle: [this.formation.libelle, [Validators.required, Validators.maxLength(255), Validators.minLength(5)]],
      duree: [this.formation.duree, [Validators.required, Validators.min(1),Validators.max(200), Validators.pattern('^[0-9]*$')]],
      motClePrimaire: [this.formation.motClePrimaire],
      url: [this.formation.url, [Validators.required, Validators.pattern("([a-zA-Z ]|-|[0-9])*$")]],
      categorieId: ["",[Validators.required,Validators.min(1)]],
    });
  }

  private _populateForm() {
    this.formation = Object.assign(this.formation, this.createForm.value);
    let categorie = new Categorie();
    categorie.id = this.createForm.get('categorieId').value
    this.formation.categorie = categorie;
    console.log('Formation is' + JSON.stringify(this.formation));
  }
}
