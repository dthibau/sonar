import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { AlertService } from 'src/app/app-common/alert.service';
import { ROLE_MANAGER } from 'src/app/app.constants';
import { Account } from 'src/app/core/core.model';
import { CoreService } from 'src/app/core/core.service';
import { FormationService } from '../formation.service';
import { Formation } from '../offre.model';

@Component({
  selector: 'app-modal-statut',
  templateUrl: './modal-statut.component.html',
  styleUrls: ['./modal-statut.component.scss']
})
export class ModalStatutComponent implements OnInit, AfterViewInit {

  @Input()
  formation: Formation
  @Input()
  id: string

  @Output() updated: EventEmitter<any> = new EventEmitter();

  managers: Account[]

  ROLE_MANAGER = ROLE_MANAGER

  constructor(private formationService: FormationService,
    private coreService: CoreService,
    private alertService: AlertService) { }

  ngOnInit() {
    this.coreService.getAccounts(ROLE_MANAGER).subscribe((res: Account[]) => this.managers = res);
    this._initCurrentManager();
    
  }
  ngAfterViewInit() {
    console.log("After View Init" + this.formation)
  }

  saveStatut() {
    console.log("Saving statut")
    if (this.formation.currentManager == null || this.formation.currentManager.id == -1 ) 
      this.formation.currentManager = null
    else 
      this.formation.currentManager = this.managers.find(m => m.id == this.formation.currentManager.id)
    this.formationService.patchStatut(this.formation).subscribe(
      (ufr) => { //
        this.updated.emit(ufr);
      }, 
      (res: HttpErrorResponse) => {
        this.alertService.error("Oops, Prenez une grande inspiration, une erreur est survenue " + res.status)
      
      }
    )
    this._initCurrentManager()
  }
  private _initCurrentManager() {
    if ( this.formation && this.formation.currentManager == null ) {
      this.formation.currentManager = new Account()
      this.formation.currentManager.id = -1
    } 

  }
}
