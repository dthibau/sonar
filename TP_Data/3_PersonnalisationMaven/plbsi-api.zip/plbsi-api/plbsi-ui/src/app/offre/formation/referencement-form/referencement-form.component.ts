import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CoreService } from 'src/app/core/core.service';
import { FormationService } from '../../formation.service';
import { Formation } from '../../offre.model';

@Component({
  selector: 'app-referencement-form',
  templateUrl: './referencement-form.component.html',
  styleUrls: ['./referencement-form.component.scss']
})
export class ReferencementFormComponent implements OnInit {

  @Input()
  formation: Formation

  MAX_TITLE = 60;
  referencementForm: FormGroup;

  constructor(private fb: FormBuilder,
    private coreService: CoreService) {
    }

  ngOnInit() {
    if (this.formation) {
      this._createForm();
    } else {
      console.error("Formation not set")
    }
  }

  private _createForm() {
    console.log('Create Property form for ' + this.formation.reference);
    this.referencementForm = this.fb.group({
      motClePrimaire: [this.formation.motClePrimaire, [Validators.required]],
      url: [this.formation.url, [Validators.required, Validators.pattern("([a-zA-Z ]|-|[0-9])*$")]],
      baliseKeywords: [this.formation.baliseKeywords],
      baliseDescription: [this.formation.baliseDescription],
      baliseTitle: [this.formation.baliseTitle],
      campagneAdwords: [this.formation.campagneAdwords]
    });
  }
}
