import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CKMODEL, OBJECTIFS } from 'src/app/app.constants';
import { CoreService } from 'src/app/core/core.service';
import { Formation, MinimalFormation } from '../../offre.model';
import * as CustomCKEditor from '../../../../ckeditor_custom/ckeditor';
import { FormationService } from '../../formation.service';
import { AlertService } from 'src/app/app-common/alert.service';

@Component({
  selector: 'app-commerce-form',
  templateUrl: './commerce-form.component.html',
  styleUrls: ['./commerce-form.component.scss']
})
export class CommerceFormComponent implements OnInit {

  @Input()
  formation: Formation


  commerceForm: FormGroup;

  editedBloc: string

  public Editor = CustomCKEditor;

  public ckModel = CKMODEL;
  public editor: any;

  public autreNiveau: boolean;
  public objectifs = OBJECTIFS;
  NIVEAU_FONDAMENTAL = "Fondamental"
	NIVEAU_INTERMEDIAIRE = "Intermédiaire"
	NIVEAU_AVANCE = "Avancé"

  constructor(private fb: FormBuilder,
    private formationService: FormationService,
    private alertService: AlertService,
    public coreService: CoreService) {
  }

  ngOnInit() {
    if (this.formation) {
      this._createForm();
      this.autreNiveau = this.formation.niveau == null
      || !(this.hasStandardNiveau() ) 
      || (this.formation.autreObjectifSimple != null);

    } else {
      console.error("Formation not set")
    }

  }

  selectBloc(bloc : string) {
    this.editedBloc = bloc
    if ( bloc == 'Commercialisation') {
      this.editor.setData(this.formation.blocCommercialisation)
    }
    if ( bloc == 'Intra') {
      this.editor.setData(this.formation.blocIntra)
    }
    if ( bloc == 'Argumentaire') {
      this.editor.setData(this.formation.blocArgumentaire)
    }
    if ( bloc == 'Certification') {
      this.editor.setData(this.formation.blocCertification)
    }
    if ( bloc == 'CPF') {
      this.editor.setData(this.formation.blocCpf)
    }
  }

  onReady(editor) {
    this.editor = editor;
  }

  public saveBloc() {
    if (this.editedBloc) {
      console.log("Saving bloc"+ this.editor.getData())
      this.formationService.updateBloc(this.editedBloc,this.formation.idFormation, this.editor.getData()).subscribe(() => {
        console.log("Saved bloc")
        if ( this.editedBloc == 'Commercialisation') {
          this.formation.blocCommercialisation = this.editor.getData();
        }
        if ( this.editedBloc == 'Intra') {
          this.formation.blocIntra = this.editor.getData();
        }
        if ( this.editedBloc == 'Argumentaire') {
          this.formation.blocArgumentaire = this.editor.getData();
        }
        if ( this.editedBloc == 'Certification') {
           this.formation.blocCertification = this.editor.getData();
        }
        if ( this.editedBloc == 'CPF') {
          this.formation.blocCpf = this.editor.getData();
        }
      }
        
      );
    }
  }

  public addMutualisee() {
    if (!this.formation.mutualisees) {
      this.formation.mutualisees = new Array()
    }
    this.formation.mutualisees.push(new MinimalFormation())

  }

  public updateMutualisee(event: any) {
    let index = event.index 
    let idFormation = event.idFormation
    if (this.formation.mutualisees[index].idFormation > 0) {
      this.formationService.removeFormationMutualisee(this.formation.mutualisees[index].idFormation, this.formation.idFormation).subscribe()
    }
    this.formationService.addFormationMutualisee(idFormation, this.formation.idFormation).subscribe(
      ufr => {
        this.formation.mutualisees[index].idFormation = idFormation
        this.alertService.success(ufr.message);
      })
  }

  public deleteMutualisee(index: number) {
    if (this.formation.mutualisees[index].idFormation > 0) {
      this.formationService.removeFormationMutualisee(this.formation.mutualisees[index].idFormation, this.formation.idFormation).subscribe(ufr => {
        this.alertService.success(ufr.message);
      })
    }
    this.formation.mutualisees.splice(index, 1);

  }

  
  private _createForm() {
    console.log('Create Commerce form for ' + this.formation.reference);
    this.commerceForm = this.fb.group({


      prix: [this.formation.prix],
      remise: [this.formation.remise],
      tarifIntra: [this.formation.tarifIntra],
      coursPlbCataloguePartenaire: [this.formation.coursPlbCataloguePartenaire],
      plbInter: [this.formation.plbInter],
      origine: [this.formation.origine],
      support: [this.formation.support],
      distance: [this.formation.distance],
      elearning: [this.formation.elearning],

      certification: [this.formation.certification],
      coursOfficiel: [this.formation.coursOfficiel],

      niveau: [this.formation.niveau,[Validators.required,Validators.minLength(1)]],
      autreNiveau: [this.autreNiveau],

      eligibleCpf: [this.formation.eligibleCpf],
      codeCpf: [this.formation.codeCpf],
    });

  }

  public changeAutreNiveau() {
    this.autreNiveau = !this.autreNiveau
  }
  public hasStandardNiveau() : boolean {
		return this.formation.niveau == this.NIVEAU_FONDAMENTAL
		|| this.formation.niveau == this.NIVEAU_INTERMEDIAIRE
		|| this.formation.niveau == this.NIVEAU_AVANCE;
	}
}
