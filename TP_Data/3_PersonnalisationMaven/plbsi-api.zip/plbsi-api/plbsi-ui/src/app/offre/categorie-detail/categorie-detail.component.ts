import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AlertService } from 'src/app/app-common/alert.service';
import { ApplyForm, CKMODEL } from 'src/app/app.constants';
import { Categorie, CategorieConnexe, Filiere, Formation } from '../offre.model';
import { OffreService } from '../offre.service';

import * as CustomCKEditor from '../../../ckeditor_custom/ckeditor';
import { FormationService } from '../formation.service';


@Component({
  selector: 'app-categorie-detail',
  templateUrl: './categorie-detail.component.html',
  styleUrls: ['./categorie-detail.component.scss']
})
export class CategorieDetailComponent implements OnInit, ApplyForm {

  categorieId: number;
  categorieForm: FormGroup;
  categorie: Categorie;
  // Autres catégories de la filière
  autreCategories: Categorie[];
  // Catégories connexes
  categoriesConnexes: CategorieConnexe[];
  // Catégories référentes (la categorie courante est connexe des catégories référentes)
  categoriesReferentes: Categorie[];
  // Les catégories qui ne sont pas connexes à la catégorie courante
  selectableCategories: Categorie[];
  formations: Formation[];
  filieres: Filiere[];

  isApplying: boolean;
  isSaving: boolean;
  formSaved: boolean;
  referentesSaved: boolean;
  formationsUpdated = false;
  lastFiliere: number;

  public Editor = CustomCKEditor;
  public ckModel = CKMODEL;

  constructor(private fb: FormBuilder,
    private offreService: OffreService,
    private formationService: FormationService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private router: Router) {
    this.autreCategories = new Array();
  }


  ngOnInit() {
    this.ckModel.config.autosave.save = editor => this.saveEditorData(editor.getData());

    this.route.paramMap.subscribe((params: ParamMap) => {
      this.categorieId = +params.get('id');
      if (this.categorieId !== 0) {
        this.offreService.findCategorie(this.categorieId).subscribe(
          (res: Categorie) => {
            this.categorie = res;
            console.log('Catégorie ' + this.categorie);
            this.createForm();
            this._updateFiliere(this.categorie.filiere.id);
            this.formationService.getFormationsFromCategorie(this.categorie.id).subscribe(
              (res: Formation[]) => this.formations = res
            );
            this.offreService.getCategoriesConnexes(this.categorie.id).subscribe(
              (res: CategorieConnexe[]) => {
                this.categoriesConnexes = res;
                this.offreService.getCategories().subscribe(
                  (res: Categorie[]) => {
                    this.selectableCategories = res;
                    // Remove all Categorie connexes
                    this.selectableCategories.filter(c => !this.categoriesConnexes.some(cc => cc.id == c.id))
                  }
                )
              }
            );
            this.offreService.getCategoriesReferentes(this.categorie.id).subscribe(
              (res: Categorie[]) => this.categoriesReferentes = res
            );
          });

      } else {
        this.categorie = new Categorie();
        this.createForm();
        this.offreService.getCategories().subscribe(
          (res: Categorie[]) => this.selectableCategories = res)
          this.categoriesConnexes = new Array();
          this.categoriesReferentes = new Array();
      }

    });
    this.offreService.getFilieres().subscribe(
      (res: Filiere[]) => this.filieres = res
    )
  }

  public saveEditorData(editorData) {
    console.log('Save editorData ' );
    if (this.categorieId ) {
      this.categorie.description = editorData;
      this.offreService.updateCategorie(this.categorie).subscribe();
    }
  }

  public createForm() {
    this.categorieForm = this.fb.group({
      libelle: [this.categorie.libelle],
      rang: [this.categorie.rang],
      filiere: [this.categorie.filiere ? this.categorie.filiere.id : null],
      url: [this.categorie.url],
      description: [this.categorie.description],
      metaTitre: [this.categorie.metaTitre],
      metaDescription: [this.categorie.metaDescription],
      metaKeywords: [this.categorie.metaKeywords],
    });
  }

  changeLibelle() : void {
    const libelle = this.categorieForm.get('libelle').value;
    if ( libelle ) {
      if ( !this.categorieForm.get('metaTitre').value ) {
        this.categorieForm.get('metaTitre').setValue(`Formation ${libelle} : la liste de nos formations | PLB Consultant`)
      }
      if ( !this.categorieForm.get('metaKeywords').value ) {
        this.categorieForm.get('metaKeywords').setValue(libelle)
      }  
    }
  }
  changeFiliere() : void {
    let idFiliere = this.categorieForm.get('filiere').value;
    console.log('Change filiere Value ' + idFiliere );
    if ( idFiliere && idFiliere !== this.lastFiliere ) {
      this._updateFiliere(idFiliere);
      this.lastFiliere = idFiliere;
    } 
  }

  _updateFiliere(idFiliere: number) {
    console.log('Update filiere ' + JSON.stringify(idFiliere));
    this.offreService.getCategoriesFromFiliere(idFiliere).subscribe(
      (res: Categorie[]) => {
        this.autreCategories = res;
        this.autreCategories = this.autreCategories.filter(f => f.id !== this.categorie.id)
        this.lastFiliere = idFiliere;
      }
    )
  }

  remove(): void {
    this.offreService.deleteCategorie(this.categorie.id).subscribe(() => this.onRemoveSuccess());
  }
  isRemoveEnabled(): boolean {
    return this.categorieId != 0 && 
         (this.formations && !this.formations.length) && 
         (this.categoriesConnexes && !this.categoriesConnexes.length) && 
         (this.categoriesReferentes && !this.categoriesReferentes.length);
  }
  public applyForm() {
    this.doSave();
    this.isApplying = true;
  }
  public save() {
    this.doSave();
    this.isSaving = true;
  }
  private doSave() {
    this.categorie = Object.assign(this.categorie, this.categorieForm.value);
    this.categorie.categoriesConnexes = this.categoriesConnexes;
    let filiere = new Filiere();
    filiere.id = this.categorieForm.get('filiere').value
    this.categorie.filiere = filiere;
    console.log('Catégorie is' + JSON.stringify(this.categorie));

    this.formSaved = false;
    this.referentesSaved = false;
    // En premier, sauvegarde du formulaire et des catégories connexes
    let saveObservable: Observable<Categorie>  
    if (this.categorieId !== 0) {
      this.categorie.id = this.categorieId;
      saveObservable = this.offreService.updateCategorie(this.categorie)
    } else {
      this.categoriesConnexes = this.autreCategories.map(c => {
        let cc = new CategorieConnexe();
        cc.linkedId = c.id;
        cc.linkedLibelle = c.libelle;
        cc.linkedRang = c.rang;
        return cc;
      })
      this.categorie.categoriesConnexes = this.categoriesConnexes;
      this.categoriesReferentes = this.autreCategories;
      saveObservable = this.offreService.createCategorie(this.categorie);
    }
    saveObservable.subscribe(
      (categorie: Categorie) =>
          this.onSaveSuccess(categorie), 
          (res: HttpErrorResponse) => this.onSaveError()
    )
  }

  private onSaveSuccess(result: Categorie) {
    this.categorie = result;
    this.categorieId = this.categorie.id;
    this.formSaved = true;
    // En second sauvegarde des référentes
    this.offreService.updateReferentes(this.categorieId, this.categoriesReferentes).subscribe(
      (referentes: Categorie[]) =>
          this.onReferentesSuccess(referentes), 
          (res: HttpErrorResponse) => this.onSaveError()
    );
    console.log(this.formationsUpdated);
    if ( this.formationsUpdated ) {
      this.formationService.sortFormations(this.categorieId, this.formations).subscribe();
    }
  }

  private onReferentesSuccess(result: Categorie[]) {
    this.categoriesReferentes = result;
    this.referentesSaved = true;
    this.alertService.success('Modification enregistrée');
      if (this.isSaving) {
        this.isSaving = false;
        this.router.navigate(['offre/categories']);
      } else {
        this.isApplying = false;
      }
  }

  private onRemoveSuccess() {
    this.alertService.success('Catégorie supprimée');
    this.router.navigate(['offre/categories'])
  }

  private onSaveError() {
    console.log('save failed');
    if ( !this.formSaved && !this.referentesSaved ) {
      this.alertService.error('Un problème est survenu lors de la sauvegarde');
    } else if ( !this.formSaved ) {
      this.alertService.error('Impossible de sauvegarder le formulaire');
    } else if ( !this.referentesSaved ) {
      this.alertService.error('Impossible de sauvegarder les catégories référentes');
    }
    
  }

  public updateFormations(arg : Formation[]) {
    console.log("Updating formations with " + arg)
    this.formationsUpdated = true;
    this.formations = arg;
  }
  public addConnexe(id: any) {
    console.log("Adding connexe " + id)
    const selected = this.selectableCategories.find(c => c.id == id);
    this.selectableCategories = this.selectableCategories.filter(c => c.id != selected.id);
    let cc = new CategorieConnexe();
    cc.linkedId = selected.id
    cc.linkedLibelle = selected.libelle
    cc.order = this.categoriesConnexes.length
    cc.linkedRang = selected.rang
    this.categoriesConnexes.push(cc);
    if (!this.categoriesReferentes.find(c => c.id === id)) {
      this.categoriesReferentes.push(selected);
    }

  }

  public removeConnexe(id: any) {
    const selected = this.categoriesConnexes.find(c => c.getId() == id);
    this.categoriesConnexes = this.categoriesConnexes.filter(c => c.getId() != selected.getId());
    this.offreService.getCategories().subscribe(
      (res: Categorie[]) => {
        this.selectableCategories = res;
        // Remove all Categorie connexes
        this.selectableCategories.filter(c => !this.categoriesConnexes.some(cc => cc.getId() == c.id))
      }
    )
  }
  public upConnexe(id: any) {
    const selectedIndex = this.categoriesConnexes.findIndex(c => c.getId() == id);
    // Swap
    [this.categoriesConnexes[selectedIndex-1],this.categoriesConnexes[selectedIndex]] = [this.categoriesConnexes[selectedIndex],this.categoriesConnexes[selectedIndex-1]]
  }
  public downConnexe(id: any) {
    const selectedIndex = this.categoriesConnexes.findIndex(c => c.getId() == id);
    // Swap
    [this.categoriesConnexes[selectedIndex],this.categoriesConnexes[selectedIndex+1]] = [this.categoriesConnexes[selectedIndex+1],this.categoriesConnexes[selectedIndex]]
 
  }
  public removeReferente(id: any) {
    const selected = this.categoriesReferentes.find(c => c.id == id);
    this.categoriesReferentes = this.categoriesReferentes.filter(c => c.id != selected.id);

  }
}
