import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YearSessionsEditorComponent } from './year-sessions-editor.component';

describe('YearSessionsEditorComponent', () => {
  let component: YearSessionsEditorComponent;
  let fixture: ComponentFixture<YearSessionsEditorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YearSessionsEditorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YearSessionsEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
