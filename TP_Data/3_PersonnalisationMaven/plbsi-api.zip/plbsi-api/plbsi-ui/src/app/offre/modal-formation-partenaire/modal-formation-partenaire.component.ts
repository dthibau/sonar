import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Partenaire } from '../offre.model';
import { OffreService } from '../offre.service';

@Component({
  selector: 'app-modal-formation-partenaire',
  templateUrl: './modal-formation-partenaire.component.html',
  styleUrls: ['./modal-formation-partenaire.component.scss']
})
export class ModalFormationPartenaireComponent implements OnInit {

  @Output() added: EventEmitter<any> = new EventEmitter();

  partenaireForm : FormGroup

  partenaires: Partenaire[]

  constructor(private fb: FormBuilder, 
    private offreService: OffreService) { }

  ngOnInit() {
    this.offreService.getPartenaires().subscribe(res => this.partenaires=res);
    this._createForm()
  }

  public save() {
    this.added.emit(this.partenaireForm.value)
  }
  private _createForm() {
    this.partenaireForm = this.fb.group({
      partenaireId: ['', [Validators.required]],
      reference: [''],
      prix: [0.0],
      url: ['']
    })
  }
}
