import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ApplyForm } from 'src/app/app.constants';

@Component({
  selector: 'app-form-buttons',
  templateUrl: './form-buttons.component.html',
  styleUrls: ['./form-buttons.component.scss']
})
export class FormButtonsComponent implements OnInit {
  @Input() backLink: string;
  @Input() form: FormGroup;
  @Input() removeEnabled: boolean;

  @Output() apply : EventEmitter<any> = new EventEmitter();
  @Output() remove : EventEmitter<any> = new EventEmitter();
  

  constructor() { }

  ngOnInit() {
  }

  applyClicked() {
    console.log("Apply clicked "+this.apply)
    this.apply.emit();
  }


  removeClicked() {
    console.log("remove clicked "+this.remove)
    this.remove.emit();
  }
}
