import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpParams, HttpHeaders } from '@angular/common/http';


import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Categorie, CategorieConnexe, Filiere, Formation, Invendus, Partenaire } from './offre.model';
import { SERVER_API_URL } from '../app.constants';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CoreService } from '../core/core.service';



@Injectable()
export class OffreService implements CanActivate {

/* new HttpHeaders({
      'Access-Control-Request-Method': 'POST'
    })
  };
*/
  constructor(private http: HttpClient, private coreService: CoreService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
    Observable<boolean> | Promise<boolean> | boolean {
    return this.coreService.getLoggedUser().pipe(map(lu => lu.authorities.includes('MANAGER')))
  }

  getInvendus(): Observable<Invendus> {
    return this.http.get<Invendus>(`${SERVER_API_URL}/offre/invendus`).pipe(
      map((res: Invendus) => this._convertInvendus(res))
    );
  }

  getFilieres() {
    return this.http.get<Filiere[]>(`${SERVER_API_URL}/offre/filieres`).pipe(
      map((res: Filiere[]) => this._convertArrayFilieres(res)
      ));
  }

  findFiliere(id: number): Observable<Filiere> {
    return this.http.get<Filiere>(`${SERVER_API_URL}/offre/filieres/${id}`).pipe(
      map((res: Filiere) => this._convertFiliere(res)
      ));
  }

  createFiliere(filiere: Filiere): Observable<Filiere> {
    const copie = { ...filiere };
    copie.categories = null;
    return this.http.post<Filiere>(`${SERVER_API_URL}/offre/filieres`, copie).pipe(
      map((res: Filiere) => this._convertFiliere(res)
      ));
  }

  updateFiliere(filiere: Filiere): Observable<Filiere> {
    const copie = { ...filiere };
    copie.categories = null;
    return this.http.put<Filiere>(`${SERVER_API_URL}/offre/filieres`, copie).pipe(
      map((res: Filiere) => this._convertFiliere(res)
      ));
  }

  deleteFiliere(id: number): Observable<void> {
    return this.http.delete<void>(`${SERVER_API_URL}/offre/filieres/${id}`);
  }

  getCategories(): Observable<Categorie[]> {
    return this.http.get<Categorie[]>(`${SERVER_API_URL}/offre/categories`).pipe(
      map((res: Categorie[]) => this._convertArrayCategorie(res)
      ));
  }
  getCategoriesFromFiliere(filiereId: number): Observable<Categorie[]> {
    return this.http.get<Categorie[]>(`${SERVER_API_URL}/offre/categories/filiere/${filiereId}`).pipe(
      map((res: Categorie[]) => this._convertArrayCategorie(res)
      ));;
  }

  findCategorie(id: number): Observable<Categorie> {
    return this.http.get<Categorie>(`${SERVER_API_URL}/offre/categories/${id}`);
  }

  updateCategorie(categorie: Categorie): Observable<Categorie> {
    const copie = { ...categorie };
    return this.http.put<Categorie>(`${SERVER_API_URL}/offre/categories`, copie);
  }

  createCategorie(categorie: Categorie): Observable<Categorie> {
    const copie = { ...categorie };
    return this.http.post<Categorie>(`${SERVER_API_URL}/offre/categories`, copie);
  }

  deleteCategorie(id: number): Observable<void> {
    return this.http.delete<void>(`${SERVER_API_URL}/offre/categories/${id}`);
  }


  getCategoriesConnexes(categorieId: number): Observable<CategorieConnexe[]> {
    return this.http.get<CategorieConnexe[]>(`${SERVER_API_URL}/offre/categories/connexes/${categorieId}`).pipe(
      map((res: CategorieConnexe[]) => this._convertArrayCategorieConnexe(res)
      ));
  }

  updateReferentes(categorieId: number, referentes: Categorie[]): Observable<Categorie[]> {
    const copie = [...referentes ];
    return this.http.put<Categorie[]>(`${SERVER_API_URL}/offre/categories/referentes/${categorieId}`,copie).pipe(
      map((res: Categorie[]) => this._convertArrayCategorie(res)
      ));
  }

  getCategoriesReferentes(categorieId: number): Observable<Categorie[]> {
    return this.http.get<Categorie[]>(`${SERVER_API_URL}/offre/categories/referentes/${categorieId}`).pipe(
      map((res: Categorie[]) => this._convertArrayCategorie(res)
      ));
  }

  getPartenaires(): Observable<Partenaire[]> {
    return this.http.get<Partenaire[]>(`${SERVER_API_URL}/offre/partenaires`).pipe(
      map((res: Partenaire[]) => this._convertArrayPartenaires(res)
      ));
  }


  _convertFiliere(res: Filiere): Filiere {
    let ret: Filiere = Object.assign(new Filiere(), res);
    if ( ret.categories ) {
      let categories = this._convertArrayCategorie(ret.categories);
      ret.categories = categories;
    }
    return ret;
  }

  _convertArrayFilieres(res: Filiere[]): Filiere[] {
    let ret: Filiere[] = new Array();
    res.forEach(filiere => {
      const c = this._convertFiliere(filiere);
      ret.push(c);
    });
    return ret;
  }

  _convertPartenaire(res: Partenaire): Partenaire {
    let ret: Partenaire = Object.assign(new Partenaire(), res);
    return ret;
  }
  _convertArrayPartenaires(res: Partenaire[]): Partenaire[] {
    let ret: Partenaire[] = new Array();
    res.forEach(partenaire => {
      const c = this._convertPartenaire(partenaire);
      ret.push(c);
    });
    return ret;
  }

  _convertInvendus(res: Invendus): Invendus {
    let ret: Invendus = Object.assign(new Invendus(), res);
    let formations : Formation[] = new Array()
    res.formations.forEach(f => {
      const c = Object.assign(new Formation(), f);
      formations.push(c);
    });
    ret.formations = formations;
    return ret;
  }

  _convertArrayCategorie(res: Categorie[]): Categorie[] {
    let ret: Categorie[] = new Array();
    res.forEach(categorie => {
      const c = Object.assign(new Categorie(), categorie);
      ret.push(c);
    });
    return ret;
  }


  _convertArrayCategorieConnexe(res: CategorieConnexe[]): CategorieConnexe[] {
    let ret: CategorieConnexe[] = new Array();
    res.forEach(categorie => {
      const c = Object.assign(new CategorieConnexe(), categorie);
      ret.push(c);
    });
    return ret;
  }
}