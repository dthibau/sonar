import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalStatutComponent } from './modal-statut.component';

describe('ModalStatutComponent', () => {
  let component: ModalStatutComponent;
  let fixture: ComponentFixture<ModalStatutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalStatutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalStatutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
