import { Pipe, PipeTransform } from '@angular/core';
import { Formation } from './offre.model';

@Pipe({
  name: 'zZPipe'
})
export class ZZPipePipe implements PipeTransform {

  transform(items: Formation[], active: boolean): Formation[] {
    console.log('zzPipe active'+active);
    if ( !active ) { return items}
    else {
      return items.filter( (it) => !it.libelle.trim().toUpperCase().startsWith('ZZ'))
    }
  }

}
