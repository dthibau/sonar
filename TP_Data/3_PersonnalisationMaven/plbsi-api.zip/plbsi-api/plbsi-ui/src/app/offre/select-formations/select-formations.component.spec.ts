import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectFormationsComponent } from './select-formations.component';

describe('SelectFormationsComponent', () => {
  let component: SelectFormationsComponent;
  let fixture: ComponentFixture<SelectFormationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectFormationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectFormationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
