import { Component, ElementRef, EventEmitter, Input, OnInit, Output, Self, ViewChild } from '@angular/core';
import { AbstractControl, FormControlName, ValidationErrors, Validators } from '@angular/forms';
import { SelectableItem } from 'src/app/offre/offre.model';

@Component({
  selector: 'app-required-select-field',
  templateUrl: './required-select-field.component.html',
  styleUrls: ['./required-select-field.component.scss'],
  providers: [FormControlName],
  styles: [`
  :host {
      border-left-style:none !important;
  }`]
})
export class RequiredSelectFieldComponent implements OnInit {

  @Input() noSelectionLabel : string;
  @Input() options : SelectableItem[];
  @Input() label: string;
  @Input() requiredMsg: string;
  @Input() cols; // Nbre de colonne prise par la zone de saisie

  @ViewChild('select', { static: false }) input: ElementRef<HTMLSelectElement>;

  @Output() change: EventEmitter<string> = new EventEmitter();

  onChange = (value) => { 
    console.log('OnChange ' + value);

  };
  onTouched = () => { };
  touched = false;
  disabled = false;
  value: SelectableItem;
  id: string;
  class: string

  constructor(@Self() public controlDir: FormControlName) {
    controlDir.valueAccessor = this;

  }

  ngOnInit() {
    const control = this.controlDir.control;
    let validators = control.validator ? [control.validator, Validators.required] : Validators.required
    control.setValidators(validators);
    control.updateValueAndValidity();
    if (this.cols == undefined) {
      this.cols = 10;
    }
    this.updateClass();

  }
  updateClass(): void {
    console.log('updateClass '+JSON.stringify(this.value));
    console.log('updateClass '+JSON.stringify(this.controlDir.control.value));

    let found = this.options.find(c => ""+c.getId() == this.controlDir.control.value)
    if ( found ) {
      this.value = found;
    }
    console.log('found '+JSON.stringify(found));

    const control = this.controlDir.control;
    this.class = `form-control col-sm-${this.cols}`
    if (control.touched) {
      this.class += ' ng-touched';
    }
    if (control.pristine) {
      this.class += ' ng-pristine';
    }
    if (control.invalid) {
      this.class += ' ng-invalid';
    }
    if ( this.change != null ) {
      this.change.emit(control.value);
    }
  }
  ngAfterViewInit(): void {
    if ( this.value ) {
      this.input.nativeElement.value = "" + this.value.id;
    }
  }
  writeValue(value: SelectableItem) {
    console.log('WriteValue ' + JSON.stringify(value));
    this.value = value;
    if (this.input != undefined) {
      this.input.nativeElement.value = "" + this.value.id;
      this.controlDir.control.setValue("" + this.value.id);
    }
  }

  registerOnChange(onChange: any) {
    this.onChange = onChange;
  }

  registerOnTouched(onTouched: any) {
    this.onTouched = onTouched;
  }

  markAsTouched() {
    if (!this.touched) {
      this.onTouched();
      this.touched = true;
    }
  }

  setDisabledState(disabled: boolean) {
    this.disabled = disabled;
  }

  validate(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (value.length == 0) {
      return {
        required: {
          value
        }
      };
    }
  }

  isSelected(o : SelectableItem) : boolean {
    return this.value && o.getId() == this.value.id;
  }

}
