import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { AlertService } from '../../../app/app-common/alert.service';
import { FormationService } from '../formation.service';
import { Formation, FormationPartenaire, SessionLieu, LieuOrganisme, MonthSessions, PartenaireLieu, Session, SessionDto, SessionOrganismes, UpdateFormationResponse } from '../offre.model';

@Component({
  selector: 'app-year-sessions-editor',
  templateUrl: './year-sessions-editor.component.html',
  styleUrls: ['./year-sessions-editor.component.scss']
})
export class YearSessionsEditorComponent implements OnInit, OnChanges {

  @Input()
  formation: Formation

  @Output() saved: EventEmitter<any> = new EventEmitter();

  months = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
  editedPartenairesSessions: SessionDto[]
  plbSessions: SessionDto[]
  otherSessions: SessionDto[]
  currentYear = new Date().getFullYear()
  minYear = new Date().getFullYear()

  sessionForm: FormGroup;
  errorMsg: string
  partenairesLieux: PartenaireLieu[]
  plbLieux: SessionLieu[]
  lieuOrganismes: Map<String, LieuOrganisme>


  constructor(private fb: FormBuilder, private formationService: FormationService, private alertService: AlertService) { }

  ngOnInit() { this._createForm(); }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.formation) {
      this._createForm();
    }
  }
  public previousYear() {
    this.saveSessions();
    this.currentYear--;
    this._createForm();
    return false
  }
  public nextYear() {
    this.saveSessions();
    this.currentYear++;
    this._createForm();
    return false
  }
  public parse(e, month, organisme) {
    let ss = e.target.value;
    console.log("Value is " + ss)
    if (ss) {
      let sessions: string = "";
      ss.split(";").forEach((s: string) => {
        let days: string[] = s.split("-")
        if (days.length > 0 && this._checkDay(days[0], month)) {
          if (days.length == 1) {
            days.push(this._addDuree(days[0], month))
          } else if (! /^\+?(0|[1-9]\d*)$/.test(days[1])) { // Si pas un chiffre
            this._errorMsg("Attention !! jour 2 invalide");
          }
          if (sessions) {
            sessions += (";" + days[0] + "-" + days[1])
          } else {
            sessions += (days[0] + "-" + days[1])
          }
        } else {
          this._errorMsg("Attention !! jour 1 invalide");
        }
      });
      this.sessionForm.get(organisme + "_" + month).setValue(sessions)
    }

  }

  saveSessions(): SessionDto[] {
    console.log("Saving sessions")
    let sessionsDtos = this._buildSessionDtos();
    this.formationService.updateSessions(this.currentYear, this.formation, sessionsDtos).subscribe(
      (res: UpdateFormationResponse) => { //
        this.formation = res.formation
        this.alertService.success(res.message);
        this.saved.emit(null);
      },
      (res: HttpErrorResponse) => {
        this.alertService.error("Aïe, aië, aïe un petit café ? une erreur est survenue " + res.status)
      }
    )
    return sessionsDtos;
  }

  private _createForm() {
    this.formationService.getSessions(this.currentYear, this.formation).subscribe(res => {
      this.editedPartenairesSessions = res;
      console.log(this.editedPartenairesSessions)
      this.plbSessions = [...this.editedPartenairesSessions].filter(s => s.lieuOrganisme.organisme == "PLB")
      this.otherSessions = [...this.editedPartenairesSessions].filter(s => s.lieuOrganisme.organisme != "PLB")
      console.log(this.plbSessions)
      console.log(this.otherSessions)
      this.sessionForm = this.fb.group({});
      this.editedPartenairesSessions.forEach(sDto => {
        sDto.monthSessions.forEach((monthSession, index) => {
          this.sessionForm.addControl(sDto.lieuOrganisme.getLieu() + "_" + index, new FormControl(this._sessionsAsString(monthSession.sessions)))
        })
      })
    }
    )
  }
  private _sessionsAsString(sessions : Session[]) : string {
    let ret=""
    let bFirst=true;
    sessions.forEach(so => {
      const dateDebut = new Date(parseInt(so.debut.substr(6,4)),parseInt(so.debut.substr(3,2))-1,parseInt(so.debut.substr(0,2)))
      const dateFin = new Date(parseInt(so.fin.substr(6,4)),parseInt(so.fin.substr(3,2))-1,parseInt(so.fin.substr(0,2)))
      if ( !bFirst ) {
        ret += ";"
      } else {
        bFirst=false
      }
      ret += (dateDebut.getDate() +"-"+dateFin.getDate())
    })
    return ret
  }
  

  private _buildSessionDtos(): SessionDto[] {

    this.editedPartenairesSessions.forEach(sDto => {
      sDto.monthSessions.forEach((libelleMonth, month) => {
        let value = this.sessionForm.get(sDto.lieuOrganisme.getLieu() + "_" + month).value;
        sDto.monthSessions[month].sessions = this._parseSession(value, month);
      })
    });

    console.log("Building session Dto " + JSON.stringify(this.editedPartenairesSessions));
    return [...this.editedPartenairesSessions];
  }

  private _parseSession(s: string, month: number): Session[] {
    console.log("Parsing : " + s + " month =" + month)
    const ret = new Array();
    if (s) {
      s.split(";").forEach(s => {
        const session = new Session();
        let days = s.split("-");
        session.debut = this._formatDate(parseInt(days[0]), month + 1, this.currentYear);
        let computedYear = this.currentYear;
        if (parseInt(days[0]) >= parseInt(days[1])) {
          if (month + 1 >= 12) {
            computedYear++;
          }
          month = (month + 1) % 12;
        }
        session.fin = this._formatDate(parseInt(days[1]), month + 1, computedYear);
        ret.push(session);
      });
    }

    console.log(JSON.stringify(ret));
    return ret
  }

  private _formatDate(day: number, month: number, year: number): string {
    return (day < 10 ? "0" : "") + day + "/"
      + (month < 10 ? "0" : "") + (month) + "/"
      + year;

  }
  private _addDuree(debut: string, month: number): string {
    const dateDebut = new Date(this.currentYear, month, parseInt(debut))
    let dateFin = new Date(dateDebut.getTime() + (1000 * 60 * 60 * 24)*(this.formation.duree-1));
    return "" + dateFin.getDate()
  }

  private _checkDay(day: string, month: number): boolean {

    const dateDebut = new Date(this.currentYear, month, parseInt(day))
    return dateDebut.getMonth() == month &&
      /^\+?(0|[1-9]\d*)$/.test(day);
  }

  private _errorMsg(msg: string) {
    this.errorMsg = msg;
    setTimeout(() => {
      this.errorMsg = "";
    }, 3000);
  }


}
