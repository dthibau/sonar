import { Component, OnInit } from '@angular/core';
import { OffreService } from '../offre.service';
import { Invendus } from '../offre.model';

@Component({
  selector: 'app-invendus',
  templateUrl: './invendus.component.html',
  styleUrls: ['./invendus.component.scss']
})
export class InvendusComponent implements OnInit {

  invendus: Invendus
  searchText: string
  filterMetadata = { count: 0 };
  

  constructor(private offreService: OffreService) { 
  }

  ngOnInit() {
    this.offreService.getInvendus().subscribe(
      (invendus: Invendus) => this.invendus = { ...invendus }
    )
  }

}
