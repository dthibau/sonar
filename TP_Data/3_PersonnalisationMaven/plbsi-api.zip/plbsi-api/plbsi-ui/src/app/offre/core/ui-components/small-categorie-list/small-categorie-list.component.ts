import { Component, Input, OnInit, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Categorie } from 'src/app/offre/offre.model';

@Component({
  selector: 'app-small-categorie-list',
  templateUrl: './small-categorie-list.component.html',
  styleUrls: ['./small-categorie-list.component.scss']
})
export class SmallCategorieListComponent implements OnInit {

  @Input() categories: Categorie[]
  @Input() title: string
  @Input() icon1: string
  @Input() icon2: string
  @Input() icon3: string
  @Input() alt1: string
  @Input() alt2: string
  @Input() alt3: string

  @Output() action1: EventEmitter<number> = new EventEmitter();
  @Output() action2: EventEmitter<number> = new EventEmitter();
  @Output() action3: EventEmitter<number> = new EventEmitter();


  cols: number;
  constructor() { }

  ngOnInit() {
    this.cols = 2;
    if ( this.icon1 !== null ) {
      this.cols++;
    }
    if ( this.icon2 !== null ) {
      this.cols++;
    }
    if ( this.icon3 !== null ) {
      this.cols++;
    }
  }

  // Returning false, to prevent browser navigation
  icon1Clicked(id: number) : boolean {
    this.action1.emit(id);
    return false;
  }
  icon2Clicked(id: number) : boolean {
    this.action2.emit(id);
    return false;
  }
  icon3Clicked(id: number) : boolean {
    this.action3.emit(id);
    return false;
  }

  isFirst(id: number): boolean {
    return this.categories[0].getId() == id;
  }

  isLast(id: number): boolean {
    return this.categories[this.categories.length-1].getId() == id;
  }
}
