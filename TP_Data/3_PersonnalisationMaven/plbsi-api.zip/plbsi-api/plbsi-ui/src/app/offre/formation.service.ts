import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { SERVER_API_URL } from '../app.constants';
import { CoreService } from '../core/core.service';
import { Categorie, Formation, FormationFilter, LieuOrganisme, MinimalFormation, PageFormation, PartenaireLieu, SessionDto, SessionOrganismes, UpdateFormationResponse } from './offre.model';

@Injectable({
  providedIn: 'root'
})
export class FormationService {

  constructor(private http: HttpClient, private coreService: CoreService) { }

  getFormations(formationFilter: FormationFilter): Observable<PageFormation> {
    let urlString = "";
    let sep = "?"
    if (formationFilter.q) {
      urlString += (sep + "q=" + formationFilter.q)
      sep = "&"
    }
    if (formationFilter.moreResult) {
      urlString += (sep + "moreResult=" + formationFilter.moreResult)
      sep = "&"
    }
    if (formationFilter.categorieId && formationFilter.categorieId != -1) {
      urlString += (sep + "categorieId=" + formationFilter.categorieId)
      sep = "&"
    } else if (formationFilter.filiereId && formationFilter.filiereId != -1) {
      urlString += (sep + "filiereId=" + formationFilter.filiereId)
      sep = "&"
    }
    if (formationFilter.excluPLB) {
      urlString += (sep + "excluPLB=true")
      sep = "&"
    } else if (formationFilter.partenaireId && formationFilter.partenaireId != -1) {
      urlString += (sep + "partenaireId=" + formationFilter.partenaireId)
      sep = "&"
    }
    if (formationFilter.sortColumn) {
      urlString += (sep + "sortColumn=" + formationFilter.sortColumn)
      sep = "&"
    }
    if (formationFilter.sortOrder) {
      urlString += (sep + "sortOrder=" + formationFilter.sortOrder)
      sep = "&"
    }
    if (formationFilter.page) {
      urlString += (sep + "page=" + formationFilter.page)
      sep = "&"
    }
    if (formationFilter.size) {
      urlString += (sep + "size=" + formationFilter.size)
      sep = "&"
    }
    if (formationFilter.archived) {
      urlString += (sep + "archived=true")
    }
    console.log("urlString " + urlString);
    return this.http.get<PageFormation>(`${SERVER_API_URL}/offre/formations${urlString}`).pipe(
      map((res: PageFormation) => this._convertResult(res)
      ));
  }

  getSelectables() : Observable<MinimalFormation[]> {
    return this.http.get<MinimalFormation[]>(`${SERVER_API_URL}/offre/formations/selectables`);
  }
  createFormation(formation: Formation) : Observable<Formation> {
    return this.http.post<Formation>(`${SERVER_API_URL}/offre/formations/`,formation).pipe(
      map((res: Formation) => this._convertFormation(res)
      ));
  }
  getFormation(id: number): Observable<Formation> {
    return this.http.get<Formation>(`${SERVER_API_URL}/offre/formations/${id}`).pipe(
      map((res: Formation) => this._convertFormation(res)
      ));
  }
  getFormationsFromCategorie(categorieId: number): Observable<Formation[]> {
    return this.http.get<Formation[]>(`${SERVER_API_URL}/offre/formations/categorie/${categorieId}`).pipe(
      map((res: Formation[]) => this._convertFormationArray(res)
    ));
  }

  sortFormations(categorieId: number, formations: Formation[]) {
    return this.http.put<void>(`${SERVER_API_URL}/offre/formations/sort/${categorieId}`,formations);
  }
  updateCategorie(idCategorie: number, idFormation: number) : Observable<UpdateFormationResponse>{
    return this.http.put<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations/categorie/${idCategorie}/${idFormation}`,'');
  }
  addCategorieSecondaire(idCategorie: number, idFormation: number) : Observable<UpdateFormationResponse>{
    return this.http.post<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations/secondaire/${idCategorie}/${idFormation}`,'');
  }
  removeCategorieSecondaire(idCategorie: number, idFormation: number) : Observable<UpdateFormationResponse>{
    return this.http.delete<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations/secondaire/${idCategorie}/${idFormation}`);
  }
  addFormationAssociee(idAssociee: number, idFormation: number) : Observable<UpdateFormationResponse>{
    return this.http.post<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations/associee/${idAssociee}/${idFormation}`,'');
  }
  removeFormationAssociee(idAssociee: number, idFormation: number) : Observable<UpdateFormationResponse>{
    return this.http.delete<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations/associee/${idAssociee}/${idFormation}`);
  }

  addFormationMutualisee(idMutualisee: number, idFormation: number) : Observable<UpdateFormationResponse>{
    return this.http.post<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations/mutualisee/${idMutualisee}/${idFormation}`,'');
  }
  removeFormationMutualisee(idMutualisee: number, idFormation: number) : Observable<UpdateFormationResponse>{
    return this.http.delete<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations/mutualisee/${idMutualisee}/${idFormation}`);
  }


  referenceExist(reference : string): Observable<Boolean> {
    return this.http.get<Boolean>(`${SERVER_API_URL}/offre/formations/reference/exists/${reference}`)
  }

  getLieuxPossible(id: number): Observable<PartenaireLieu[]> {
    return this.http.get<PartenaireLieu[]>(`${SERVER_API_URL}/offre/lieux/formation/${id}`);

  }

  patchFormation(formation: Formation): Observable<UpdateFormationResponse> {
    return this.http.patch<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations`, formation)
  }
  patchStatut(formation: Formation): Observable<UpdateFormationResponse> {
    return this.http.patch<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations/statut`, formation)
  }

  updateSessions(year: number, formation: Formation, sessionsDtos: SessionDto[]): Observable<UpdateFormationResponse> {
    return this.http.patch<UpdateFormationResponse>(`${SERVER_API_URL}/offre/formations/sessions/${formation.idFormation}/${year}`, sessionsDtos).pipe(
      map((res: UpdateFormationResponse) => this._convertUpdateFormationResponse(res)
      ));
  }

  getSessions(year: number, formation: Formation): Observable<SessionDto[]> {
    return this.http.get<SessionDto[]>(`${SERVER_API_URL}/offre/formations/sessions/${formation.idFormation}/${year}`).pipe(
      map((res: SessionDto[]) => this._convertSessionDtos(res)
      ));
  }

  updateBloc(bloc: string, idFormation: number, content: string) : Observable<void> {
    return this.http.put<void>(`${SERVER_API_URL}/offre/formations/bloc/${bloc}/${idFormation}`, content)

  }

  _convertResult(res: PageFormation): PageFormation {
    let ret: PageFormation = Object.assign(new PageFormation(), res);
    let formations: Formation[] = new Array()
    res.content.forEach(f => {
      const c = this._convertFormation(f);
      formations.push(c);
    });
    ret.content = formations;
    return ret;
  }

  _convertFormationArray(res: Formation[]): Formation[] {
    let ret = new Array();
    res.forEach(f => ret.push(this._convertFormation(f)))

    return ret;
  }
  _convertFormation(res: Formation): Formation {
    let ret: Formation = Object.assign(new Formation(), res);

    if (res.nextSessionsByOrganismes) {
      let nextSessionsByOrganismes: SessionOrganismes[] = new Array()

      res.nextSessionsByOrganismes.forEach(sos => {
        const c = Object.assign(new SessionOrganismes(), sos);
        nextSessionsByOrganismes.push(c);
      })
      ret.nextSessionsByOrganismes = nextSessionsByOrganismes;
    }
    if ( res.categorie ) {
      const c = Object.assign(new Categorie(), res.categorie);
      ret.categorie = c;
    }
    return ret;
  }

  _convertUpdateFormationResponse(res: UpdateFormationResponse) {
    let ret: UpdateFormationResponse = Object.assign(new UpdateFormationResponse(), res);
    if ( res.formation ) {
      ret.formation = this._convertFormation(res.formation);
    }
    return ret;
  }

  _convertSessionDtos(res: SessionDto[]): SessionDto[] {
    let ret = new Array()

    res.forEach(res_dto => {
      const sessionDto = Object.assign(new Formation(), res_dto)
      if (res_dto.lieuOrganisme) {
        const lieuOrganisme = Object.assign(new LieuOrganisme(), res_dto.lieuOrganisme)
        sessionDto.lieuOrganisme = lieuOrganisme
      }
      ret.push(sessionDto)
    });
    return ret;
  }
}
