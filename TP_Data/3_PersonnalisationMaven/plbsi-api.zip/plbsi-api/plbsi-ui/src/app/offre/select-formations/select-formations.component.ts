import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormationService } from '../formation.service';
import { MinimalFormation } from '../offre.model';

@Component({
  selector: 'app-select-formations',
  templateUrl: './select-formations.component.html',
  styleUrls: ['./select-formations.component.scss']
})
export class SelectFormationsComponent implements OnInit {

  @Input() 
  label: string

  @Input() 
  formations: MinimalFormation[]

  @Output() added: EventEmitter<any> = new EventEmitter();
  @Output() updated: EventEmitter<any> = new EventEmitter();
  @Output() deleted: EventEmitter<any> = new EventEmitter();

  allFormations: MinimalFormation[]

  selectForm: FormGroup;

  constructor(private formationService: FormationService,
    private fb: FormBuilder) { }

  ngOnInit() {
    this.selectForm = this.fb.group({})
    this.formationService.getSelectables().subscribe(res => {
      this.allFormations = res;
      this.formations.forEach((f, i) => {
        console.log("Init selectFormations :" + f.idFormation)
        this.selectForm.addControl(
          'f_' + i, new FormControl(f.idFormation, [Validators.required])
        )
      })
    })
  }

  addFormation() : boolean {
    this.selectForm.addControl(
      'f_' + this.formations.length, new FormControl('-1', [Validators.required])
    )
    this.added.emit();
    return false
  }
  updateFormation(index: number) : boolean {
    let idFormation = this.selectForm.get('f_' + index).value;
    this.updated.emit({'index': index, 'idFormation':idFormation});
    return false
  }
  deleteFormation(index: number) : boolean {
    this.selectForm.removeControl('f_' + index)
    this.deleted.emit(index);
    return false
  }
}
