import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProprieteFormComponent } from './propriete-form.component';

describe('ProprieteFormComponent', () => {
  let component: ProprieteFormComponent;
  let fixture: ComponentFixture<ProprieteFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProprieteFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProprieteFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
