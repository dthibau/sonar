import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OffreComponent } from './offre.component';
import { InvendusComponent } from './invendus/invendus.component';
import { MainNavigationComponent } from '../core/main-navigation.component';
import { FilieresComponent } from './filieres/filieres.component';
import { FiliereDetailComponent } from './filiere-detail/filiere-detail.component';
import { CategoriesComponent } from './categories/categories.component';
import { CategorieDetailComponent } from './categorie-detail/categorie-detail.component';
import { FormationsComponent } from './formations/formations.component';
import { FormationComponent } from './formation/formation.component';
import { CreateFormationComponent } from './create-formation/create-formation.component';


const offreRoutes: Routes = [
  { path: 'offre', redirectTo: 'offre/formations', pathMatch: 'full' },
  {
    path: 'offre', component: MainNavigationComponent, children: [
      { path: 'formations', component: OffreComponent, children: [{ path: '', component: FormationsComponent }] },
      { path: 'formation/:id', component: OffreComponent, children: [{ path: '', component: FormationComponent }] },
      { path: 'formation', component: OffreComponent, children: [{ path: '', component: CreateFormationComponent }] },
      { path: 'filieres', component: OffreComponent, children: [{ path: '', component: FilieresComponent }] },
      { path: 'filiere/:id', component: OffreComponent, children: [{ path: '', component: FiliereDetailComponent }] },
      { path: 'filiere', component: OffreComponent, children: [{ path: '', component: FiliereDetailComponent }] },     
      { path: 'categories', component: OffreComponent, children: [{ path: '', component: CategoriesComponent }] },
      { path: 'categorie/:id', component: OffreComponent, children: [{ path: '', component: CategorieDetailComponent }] },
      { path: 'categorie', component: OffreComponent, children: [{ path: '', component: CategorieDetailComponent }] },     
      { path: 'invendus', component: OffreComponent, children: [{ path: '', component: InvendusComponent }] }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(offreRoutes)],
  exports: [RouterModule]
})
export class OffreRoutingModule { }
