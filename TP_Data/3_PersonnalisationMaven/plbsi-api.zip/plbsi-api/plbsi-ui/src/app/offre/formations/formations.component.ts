import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AlertService } from 'src/app/app-common/alert.service';
import { ROLE_AC_MANAGER, ROLE_COMMERCIAL, ROLE_DISPATCHER, ROLE_INTERVENANTS_MANAGER, ROLE_MANAGER, ROLE_TB_MANAGER } from 'src/app/app.constants';
import { Account } from 'src/app/core/core.model';
import { CoreService } from 'src/app/core/core.service';
import { FormationService } from '../formation.service';
import { Categorie, Filiere, Formation, FormationFilter, FormationPager, MonthSessions, PageFormation, Partenaire, Session, SessionDto, UpdateFormationResponse } from '../offre.model';
import { OffreService } from '../offre.service';

@Component({
  selector: 'app-formations',
  templateUrl: './formations.component.html',
  styleUrls: ['./formations.component.scss']
})
export class FormationsComponent implements OnInit {

  result: PageFormation
  formationFilter: FormationFilter
  filieres: Filiere[]
  categories: Categorie[]
  partenaires: Partenaire[]
  editedFormation: Formation
  selectedFormation: Formation
  months = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];
  editedPartenairesSessions:Map<string,Array<string>>
  currentYear = new Date().getFullYear()

  ROLE_MANAGER = ROLE_MANAGER
  ROLE_COMMERCIAL = ROLE_COMMERCIAL
  ROLE_DISPATCHER = ROLE_DISPATCHER
  ROLE_INTERVENANTS_MANAGER = ROLE_INTERVENANTS_MANAGER
  ROLE_TB_MANAGER = ROLE_TB_MANAGER
  ROLE_AC_MANAGER = ROLE_AC_MANAGER

  pager: FormationPager;

  constructor(private formationService: FormationService, private offreService: OffreService
    , public coreService: CoreService, private alertService: AlertService) { }

  ngOnInit() {
    this.initFilter()

    this.pager = new FormationPager()
    this.search()
    this.offreService.getFilieres().subscribe((res: Filiere[]) => this.filieres = res)
    this.offreService.getCategories().subscribe((res: Categorie[]) => this.categories = res)
    this.offreService.getPartenaires().subscribe((res: Partenaire[]) => this.partenaires = res);
  }

  // Recherche par mot-clé, le tri par défaut est la pertinence
  fullTextSearch() {
    this.formationFilter.page = 0;
    this.formationFilter.sortColumn = null;
    this.formationFilter.sortOrder = null;
    this.search()
  }
  search() {
    console.log("Search")
    this.formationService.getFormations(this.formationFilter).subscribe(
      (res: PageFormation) => {
        this.result = res
        this.updatePager()
      }
    )
  }
  changeFiliere() {
    this.formationFilter.page = 0;
    this.formationFilter.categorieId = -1;
    this.search();
    if (this.formationFilter.filiereId != -1)
      this.offreService.getCategoriesFromFiliere(this.formationFilter.filiereId).subscribe((res: Categorie[]) => this.categories = res)
    else
      this.offreService.getCategories().subscribe((res: Categorie[]) => this.categories = res)
  }
  changeCriteria(): boolean {
    this.formationFilter.page = 0;
    this.search()
    return false;
  }
  clearFilter(): boolean {
    this.initFilter()
    this.formationFilter.page = 0;
    this.search()
    this.offreService.getCategories().subscribe((res: Categorie[]) => this.categories = res)
    return false
  }

  changePage(page: number): boolean {
    this.formationFilter.page = page - 1;
    this.search()
    return false;
  }
  updatePager(): void {
    if (this.result.noPage > 9) {
      this.pager.previousPages = true;
    } else {
      this.pager.previousPages = false;
    }
    if (this.result.noPage + 9 < this.result.totalPages) {
      this.pager.nextPages = true;
    } else {
      this.pager.nextPages = false;
    }
    this.pager.minPage = Math.floor((this.result.noPage + 1) / 10) * 10 + 1;
    this.pager.maxPage = this.pager.minPage + 9 < this.result.totalPages ? this.pager.minPage + 9 : this.result.totalPages;
  }
  isOrder(column: string): string {
    return column == this.formationFilter.sortColumn ? this.formationFilter.sortOrder : "";
  }
  setOrder(column: string): boolean {
    let isorder = this.isOrder(column);
    console.log(column + "/" + isorder + "*")
    if (isorder == 'asc') {
      this.formationFilter.sortOrder = 'desc'
    } else if (isorder == 'desc') {
      this.formationFilter.sortOrder = 'asc'
    } else {
      this.formationFilter.sortColumn = column;
      this.formationFilter.sortOrder = 'asc'
    }
    this.search()
    return false;
  }
  sessionEditable(formation: Formation) : boolean {
    return (this.coreService.hasRole(ROLE_MANAGER) || (formation.type != "rouge" 
    && !formation.plbInter && formation.mutualisees.length ==0)) && formation.prix > 0
  }
  select(id: number) {
    this.editedFormation = new Formation();
    this.formationService.getFormation(id).subscribe(
      (res: Formation) => {
        this.selectedFormation = res
        this.editedFormation.idFormation = this.selectedFormation.idFormation;
        this.editedFormation.statut = this.selectedFormation.statut
        this.editedFormation.currentManager = this.selectedFormation.currentManager ? this.selectedFormation.currentManager : new Account()
      }
      )
    }

    updated(ufr : UpdateFormationResponse) {
        this.search();  // Refreshing list
        this.alertService.success("Super ! " + ufr.message);
    }

  
  
  private initFilter() {
    this.formationFilter = new FormationFilter()
    this.formationFilter.sortColumn = "statut"
    this.formationFilter.sortOrder = "desc"
    this.formationFilter.filiereId = -1
    this.formationFilter.categorieId = -1
    this.formationFilter.excluPLB = false
    this.formationFilter.partenaireId = -1
  }



  
}
