import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Alert } from './alert';

@Injectable({
  providedIn: 'root'
})
export class AlertService {

  alertId: number; // unique id for each alert. Starts from 0.
  alerts: Alert[];
  timeout = 5000; // default timeout in milliseconds

  constructor() {
    this.alerts = [];
  }

  error(msg) {
    this.addAlert(new Alert( 'danger', msg));
  }
  info(msg) {
    this.addAlert(new Alert( 'info', msg));
  }
  warn(msg) {
    this.addAlert(new Alert( 'warning', msg));
  }
  success(msg) {
    this.addAlert(new Alert( 'success', msg));
  }

  private addAlert(alert: Alert ) {
    console.log('AddAlert ' + alert.msg);
    alert.id = this.alertId++;
    this.alerts.push(alert);
    setTimeout(() => {
      const index = this.alerts.map(a => a.id ).indexOf(alert.id);
      this.alerts.splice(index, 1);
    }, 3000);
  }

  public get(): Alert[] {
    return this.alerts;
  }


}
