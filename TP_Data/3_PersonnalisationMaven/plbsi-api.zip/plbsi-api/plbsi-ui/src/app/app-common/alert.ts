export declare type AlertType = 'success' | 'danger' | 'warning' | 'info';

export class Alert {
    id?: number;
    msg: string;
    type: AlertType;

    constructor(
        type: AlertType,
        msg: string
        ) {
            this.msg = msg;
            this.type = type;
    }

    public close(alerts: Alert[]) {
        const index = alerts.map(a => a.id ).indexOf(this.id);
        alerts.splice(index, 1);
    }
}
