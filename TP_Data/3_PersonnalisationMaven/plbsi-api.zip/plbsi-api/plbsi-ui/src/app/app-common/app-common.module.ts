import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlertComponent } from './alert.component';
import { NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';



@NgModule({
  declarations: [
    AlertComponent
  ],
  imports: [
    CommonModule,
    NgbAlertModule
  ],
  exports: [
    AlertComponent
  ]

})
export class AppCommonModule { }
