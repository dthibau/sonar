// These constants are injected via webpack environment variables.
// You can add more variables in webpack.common.js or in profile specific webpack.<dev|prod>.js files.
// If you change the values in the webpack config files, you need to re run webpack to update the application

import { environment } from 'src/environments/environment';

/* export const VERSION = process.env.VERSION;
export const DEBUG_INFO_ENABLED: boolean = !!process.env.DEBUG_INFO_ENABLED;
export const SERVER_API_URL = process.env.SERVER_API_URL;
export const BUILD_TIMESTAMP = process.env.BUILD_TIMESTAMP; */


export const SERVER_API_URL = environment.SERVER_API_URL+'/api';
export const WEB_URL = environment.WEB_URL;

export const ROLE_MANAGER = "MANAGER"
export const ROLE_COMMERCIAL = "COMMERCIAL"
export const ROLE_DISPATCHER = "DISPATCHER"
export const ROLE_INTERVENANTS_MANAGER = "INTERVENANTS_MANAGER"
export const ROLE_TB_MANAGER = "TB_MANAGER"
export const ROLE_AC_MANAGER = "AC_MANAGER"


export const ROLES = [ROLE_MANAGER, ROLE_COMMERCIAL, ROLE_DISPATCHER, ROLE_INTERVENANTS_MANAGER, ROLE_TB_MANAGER, ROLE_AC_MANAGER]

/*
* Contrat pour la barre de boutons
*/
export declare interface ApplyForm {
    /**
     * Une méthode appelée par le bouton "Appliquer"
     */
    applyForm(): void;
    /**
     * Une méthode appelée par le bouton "Supprimer"
     */
    remove(): void;
    /**
     * Une méthode appelée par activer/désactiver le bouton "Supprimer"
     */
     isRemoveEnabled(): boolean;

}
export const OBJECTIFS = new Map([
  ["Fondamental", "Acquérir les bases"],
  ["Intermédiaire", "Se perfectionner"],
  ["Avancé", "Devenir expert"]
]);
export const CKMODEL = {
    editorData: '<p>Hello, world!</p>',
    config: {
      fontColor: {
        colors: [
          {
            color: '#484849',
            label: 'Gris PLB'
          },
          {
            color: '#006BB5',
            label: 'Bleu PLB'
          }

        ]
      },
      fontBackgroundColor: {
        colors: [
          {
            color: '#484849',
            label: 'Gris PLB'
          },
          {
            color: '#006BB5',
            label: 'Bleu PLB'
          },
          {
            color: 'hsl(0, 75%, 60%)',
            label: 'Red'
          },
          {
            color: 'hsl(30, 75%, 60%)',
            label: 'Orange'
          },
          {
            color: 'hsl(60, 75%, 60%)',
            label: 'Yellow'
          },
          {
            color: 'hsl(90, 75%, 60%)',
            label: 'Light green'
          },
          {
            color: 'hsl(120, 75%, 60%)',
            label: 'Green'
          },

          // ...
        ]
      },
      toolbar: {
        items: ['removeFormat', 'heading', '|', 'alignment', 'bold', 'italic', 'underline', 'blockquote', 'strikethrough', 'code','subscript', 'superscript',  
          '|', 'outdent', 'indent',
          '|', 'fontSize', 'fontColor', 'fontBackgroundColor',
          '|', 'bulletedList', 'numberedList', '|', 'link',
          '|', 'insertImage', 'imageUpload', 'imageTextAlternative', 'mediaEmbed',
          '|', 'insertTable', 'tableColumn', 'tableRow', 'mergeTableCells',
          '|', 'undo', 'redo',
          '|', 'sourceEditing']
      },
      blockToolbar: [
        'paragraph', 
        '|',
        'bulletedList', 'numberedList',
        '|',
        'blockQuote', 'uploadImage'
    ],
      autosave: {
        // The minimum amount of time the Autosave plugin is waiting after the last data change.
        waitingTime: 2000,
        save: (value) => { }
      },
      language: 'fr',
      link: {
        decorators: {
          openInNewTab: {
            mode: 'manual',
            label: 'Ouvrir dans un nouvel onglet',
            attributes: {
              target: '_blank',
              rel: 'noopener noreferrer'
            }
          }
        }
      },
      image: {
        // Configure the available styles.
        styles: [
          'alignLeft', 'alignCenter', 'alignRight'
        ],

        // You need to configure the image toolbar, too, so it shows the new style buttons.
        toolbar: [
          'imageStyle:alignLeft', 'imageStyle:alignCenter', 'imageStyle:alignRight',
          '|',
          'imageTextAlternative'
        ]
      },
      heading: {
        options: [
          { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
          {
            model: 'heading1',
            view: {
              name: 'h2',
              classes: ['paragraphe-title', 'puce-title', 'puce-chevron']
            },
            title: 'Titre contenu (h2)',
            class: 'ck-titre-contenu',
            converterPriority: 'highest'
          },
          {
            model: 'heading2',
            view: {
              name: 'h2',
              classes: 'paragraphe-sub-title'
            },
            title: 'Titre contenu sobre (h2)',
            class: 'ck-titre-sobre',
            converterPriority: 'high'
          },
          {
            model: 'heading3',
            view: {
              name: 'h3',
              classes: ['paragraphe-sub-title', 'txt-bleu']
            },
            title: 'Sous-titre contenu (h3)',
            class: 'ck-sous-titre-contenu',
            converterPriority: 'highest'
          },
          {
            model: 'heading4',
            view: {
              name: 'h3',
              classes: ['paragraphe-sub-title', 'mb-1']
            },
            title: 'Sous-titre contenu sobre (h3)',
            class: 'ck-sous-titre-sobre'
          },
          {
            model: 'paragraph2',
            view: {
              name: 'p',
              classes: 'txt-initial'
            },
            title: 'Contenu',
            class: 'ck-contenu',
            converterPriority: 'high'
          },
          {
            model: 'div1',
            view: {
              name: 'div',
              classes: ['alert-warning', 'transparent', 'mb-2']
            },
            title: 'Attention sans fond',
            class: 'ck-attention-ss-fond',
            converterPriority: 'highest'
          },
          {
            model: 'div2',
            view: {
              name: 'div',
              classes: ['alert-warning', 'box', 'box-grey', 'box-alert']
            },
            title: 'Attention fond gris',
            class: 'ck-attention-fond',
            converterPriority: 'highest'
          },
          {
            model: 'div3',
            view: {
              name: 'div',
              classes: ['alert-ok', 'transparent', 'mb-2']
            },
            title: 'À savoir sans fond',
            class: 'ck-asavoir-sans-fond',
            converterPriority: 'highest'
          },
          {
            model: 'div4',
            view: {
              name: 'div',
              classes: ['alert-ok', 'box', 'box-grey', 'box-alert']
            },
            title: 'À savoir fond gris',
            class: 'ck-asavoir-fond',
            converterPriority: 'highest'
          },
          {
            model: 'div5',
            view: {
              name: 'div',
              classes: ['alert-eye', 'transparent', 'mb-2']
            },
            title: 'À voir sans fond',
            class: 'ck-avoir-ss-fond'
          },
          {
            model: 'div6',
            view: {
              name: 'div',
              classes: ['alert-eye', 'box', 'box-grey', 'box-alert']
            },
            title: 'À voir fond gris',
            class: 'ck-avoir-fond'
          },
          {
            model: 'pdf',
            view: {
              name: 'i',
              classes: ['icon-pdf']
            },
            title: 'Téléchargement PDF',
            class: 'ck-pdf'
          }
        ]
      }
    }
  };
