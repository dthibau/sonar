export const environment = {
  production: true,
  SERVER_API_URL: '',
  WEB_URL: 'https://www.plb.fr'
};
