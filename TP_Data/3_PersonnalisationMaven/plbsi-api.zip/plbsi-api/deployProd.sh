#!/bin/bash

if [ -z "$1" ]
  then
    echo "Pleaaase ! Indiquer un tag "
    exit 1
fi

# Pre-requis 
# /etc/init.d/plbsi-api est un lien symbolique vers /usr/local/bin/plbsi-api.jar

# Bakup n-1
cp /usr/local/bin/plbsi-api.jar ../plbsi-api.jar.n-1

# Retreive release from nexus
#curl -sSL -X GET -G "http://plbsi-rec.plb.fr:8081/service/rest/v1/search/assets" \
#  -d repository=maven-releases \
#  -d maven.groupId=com.plb \
#  -d maven.artifactId=plbsi-api \
#  -d maven.baseVersion=0.0.4 \
#  -d maven.extension=jar \
#  | grep -Po '"downloadUrl" : "\K.+(?=",)' \
#  | xargs curl -fsSL -o my-artifact.jar

# En plus simple 
wget "http://plbsi-rec.plb.fr:8081/repository/maven-releases/com/plb/plbsi/$1/plbsi-$1.jar"



sudo cp ./plbsi-$1.jar /usr/local/bin/plbsi.jar
sudo /etc/init.d/plbsi restart --spring.profiles.active=prod
